﻿namespace SkeletonProjJesse
{
    partial class frmShipmentsTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblIDDisclaimer = new System.Windows.Forms.Label();
            this.lblShipmentQuantity = new System.Windows.Forms.Label();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.tbxShipmentID = new System.Windows.Forms.TextBox();
            this.lblShipmentID = new System.Windows.Forms.Label();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.tbxShipmentQuantity = new System.Windows.Forms.TextBox();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.lblProductID = new System.Windows.Forms.Label();
            this.tbxProductID = new System.Windows.Forms.TextBox();
            this.lblShipmentDate = new System.Windows.Forms.Label();
            this.tbxShipmentDate = new System.Windows.Forms.TextBox();
            this.lblShipmentSupplierName = new System.Windows.Forms.Label();
            this.tbxShipmentSupplierName = new System.Windows.Forms.TextBox();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblIDDisclaimer
            // 
            this.lblIDDisclaimer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblIDDisclaimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIDDisclaimer.Location = new System.Drawing.Point(11, 177);
            this.lblIDDisclaimer.Name = "lblIDDisclaimer";
            this.lblIDDisclaimer.Size = new System.Drawing.Size(323, 20);
            this.lblIDDisclaimer.TabIndex = 9;
            this.lblIDDisclaimer.Text = "Product ID must exist in database prior to insertion!";
            this.lblIDDisclaimer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblShipmentQuantity
            // 
            this.lblShipmentQuantity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblShipmentQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShipmentQuantity.Location = new System.Drawing.Point(11, 141);
            this.lblShipmentQuantity.Name = "lblShipmentQuantity";
            this.lblShipmentQuantity.Size = new System.Drawing.Size(193, 26);
            this.lblShipmentQuantity.TabIndex = 7;
            this.lblShipmentQuantity.Text = "Shipment Quantity:";
            this.lblShipmentQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(343, 234);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 15;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(257, 234);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 14;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(171, 234);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 13;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(85, 234);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 12;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // tbxShipmentID
            // 
            this.tbxShipmentID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxShipmentID.Location = new System.Drawing.Point(210, 39);
            this.tbxShipmentID.Name = "tbxShipmentID";
            this.tbxShipmentID.ReadOnly = true;
            this.tbxShipmentID.Size = new System.Drawing.Size(73, 26);
            this.tbxShipmentID.TabIndex = 2;
            // 
            // lblShipmentID
            // 
            this.lblShipmentID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblShipmentID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShipmentID.Location = new System.Drawing.Point(11, 39);
            this.lblShipmentID.Name = "lblShipmentID";
            this.lblShipmentID.Size = new System.Drawing.Size(193, 26);
            this.lblShipmentID.TabIndex = 1;
            this.lblShipmentID.Text = "Shipment ID:";
            this.lblShipmentID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(180, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(180, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(180, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(180, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // tbxShipmentQuantity
            // 
            this.tbxShipmentQuantity.Location = new System.Drawing.Point(210, 141);
            this.tbxShipmentQuantity.Name = "tbxShipmentQuantity";
            this.tbxShipmentQuantity.Size = new System.Drawing.Size(282, 26);
            this.tbxShipmentQuantity.TabIndex = 8;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(502, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // lblProductID
            // 
            this.lblProductID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblProductID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductID.Location = new System.Drawing.Point(11, 199);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(193, 26);
            this.lblProductID.TabIndex = 10;
            this.lblProductID.Text = "Product ID:";
            this.lblProductID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxProductID
            // 
            this.tbxProductID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxProductID.Location = new System.Drawing.Point(210, 199);
            this.tbxProductID.MaxLength = 7;
            this.tbxProductID.Name = "tbxProductID";
            this.tbxProductID.Size = new System.Drawing.Size(124, 26);
            this.tbxProductID.TabIndex = 11;
            // 
            // lblShipmentDate
            // 
            this.lblShipmentDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblShipmentDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShipmentDate.Location = new System.Drawing.Point(11, 107);
            this.lblShipmentDate.Name = "lblShipmentDate";
            this.lblShipmentDate.Size = new System.Drawing.Size(193, 26);
            this.lblShipmentDate.TabIndex = 5;
            this.lblShipmentDate.Text = "Shipment Date (mm/dd/yyyy):";
            this.lblShipmentDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxShipmentDate
            // 
            this.tbxShipmentDate.Location = new System.Drawing.Point(210, 107);
            this.tbxShipmentDate.MaxLength = 10;
            this.tbxShipmentDate.Name = "tbxShipmentDate";
            this.tbxShipmentDate.Size = new System.Drawing.Size(282, 26);
            this.tbxShipmentDate.TabIndex = 6;
            // 
            // lblShipmentSupplierName
            // 
            this.lblShipmentSupplierName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblShipmentSupplierName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblShipmentSupplierName.Location = new System.Drawing.Point(11, 73);
            this.lblShipmentSupplierName.Name = "lblShipmentSupplierName";
            this.lblShipmentSupplierName.Size = new System.Drawing.Size(193, 26);
            this.lblShipmentSupplierName.TabIndex = 3;
            this.lblShipmentSupplierName.Text = "Shipment Supplier Name:";
            this.lblShipmentSupplierName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxShipmentSupplierName
            // 
            this.tbxShipmentSupplierName.Location = new System.Drawing.Point(210, 73);
            this.tbxShipmentSupplierName.MaxLength = 60;
            this.tbxShipmentSupplierName.Name = "tbxShipmentSupplierName";
            this.tbxShipmentSupplierName.Size = new System.Drawing.Size(282, 26);
            this.tbxShipmentSupplierName.TabIndex = 4;
            // 
            // frmShipmentsTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(502, 279);
            this.Controls.Add(this.lblIDDisclaimer);
            this.Controls.Add(this.lblShipmentQuantity);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.tbxShipmentID);
            this.Controls.Add(this.lblShipmentID);
            this.Controls.Add(this.tbxShipmentQuantity);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.tbxProductID);
            this.Controls.Add(this.lblShipmentDate);
            this.Controls.Add(this.tbxShipmentDate);
            this.Controls.Add(this.lblShipmentSupplierName);
            this.Controls.Add(this.tbxShipmentSupplierName);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmShipmentsTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts Admin | Shipments";
            this.Load += new System.EventHandler(this.frmShipments_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblIDDisclaimer;
        private System.Windows.Forms.Label lblShipmentQuantity;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.TextBox tbxShipmentID;
        private System.Windows.Forms.Label lblShipmentID;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.TextBox tbxShipmentQuantity;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.TextBox tbxProductID;
        private System.Windows.Forms.Label lblShipmentDate;
        private System.Windows.Forms.TextBox tbxShipmentDate;
        private System.Windows.Forms.Label lblShipmentSupplierName;
        private System.Windows.Forms.TextBox tbxShipmentSupplierName;
    }
}
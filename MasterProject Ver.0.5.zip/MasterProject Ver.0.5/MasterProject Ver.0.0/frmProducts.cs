﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace SkeletonProjJesse
{
    public partial class frmProducts : Form
    {
        //Form level declaration of the total cost
        decimal totalCost = 0;
        int totalItems = 0;

        //Parallel arrays for cart management
        List<decimal> itemCosts = new List<decimal>();
        List<string> itemNames = new List<string>();
        List<string> itemIDs = new List<string>();

        public frmProducts()
        {
            InitializeComponent();
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();

            string sqlStatement = "";

            //If the user is an admin, load ingredients for the store to buy and set elements on form accordingly
            if (UserInfo.hasAdminPermission)
            {
                sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Ingredient'";

                gbxOrderSummary.Text = "Resupply Summary";
                lblItems.Text = "Stock:";
                lblCart.Text = "Stock List:";
                cbxDineIn.Visible = false;
                tbxDriverTip.Visible = false;
                lblDriverTip.Visible = false;
                btnCheckout.Text = "&Confirm";
                this.Text = "Gobblin' Ghouls and Ghosts Admin | Resupply Stock | " + UserInfo.firstName + " " + UserInfo.lastName;
                
                //Admin resupply has different filtering options
                cbxFilterItems.Items.Clear();
                cbxFilterItems.Items.Add("All");
                cbxFilterItems.Items.Add("Ingredients");
            }
            else
            {
                sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType != 'Ingredient'";

                gbxOrderSummary.Text = "Order Summary";
                lblItems.Text = "Menu Items:";
                lblCart.Text = "Your cart:";
                cbxDineIn.Visible = true;
                tbxDriverTip.Visible = true;
                lblDriverTip.Visible = true;
                btnCheckout.Text = "&Checkout";
                this.Text = "Gobblin' Ghouls and Ghosts! | Place Your Order! | " + UserInfo.firstName + " " + UserInfo.lastName;
            }

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();

            //dgvProducts.Columns["ProductDescription"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;


        }
  

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            //The standard tax for dining will be 2% (delivery will be 3%)
            decimal tax = totalCost * 0.2m;

            if (!UserInfo.isLoggedIn)
            {
                DialogResult dialogResult = MessageBox.Show("So sorry, but only logged in users can place orders online.\nWould you like to create an account?", "Sign up?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    frmSignup frmSignup = new frmSignup();
                    frmSignup.ShowDialog();
                    this.Close();
                }
            }
            else if (!UserInfo.isVerified)
            {
                DialogResult dialogResult = MessageBox.Show("Hello, " + UserInfo.firstName + ".\nIt seems your email address isn't verified." + "\nWould you like to verify your account?", "Account not verified!", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    frmConfirmEmail frmConfirmEmail = new frmConfirmEmail();
                    frmConfirmEmail.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                //If the user is an admin placing a resupply order, change it up a bit
                if (UserInfo.hasAdminPermission)
                {
                    if (totalCost == 0)
                    {
                        MessageBox.Show("You must have at least one item to confirm the resupply order.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);               
                    }
                    else
                    {
                        DialogResult dialogResult = MessageBox.Show("You have selected " + totalItems.ToString() + " item(s) totalling " + totalCost.ToString("C2") + ".\nConfirm?", "Confirm Resupply", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                        if (dialogResult == DialogResult.Yes)
                        {
                            List<decimal> uniqueItemCosts = new List<decimal>();
                            List<string> uniqueItemNames = new List<string>();
                            List<string> uniqueItemIDs = new List<string>();

                            string item = "";
                            for (int x = 0; x < lbxCart.Items.Count; x++)
                            {
                                if(x == 0)
                                {
                                    uniqueItemNames.Add(itemNames[x]);
                                    uniqueItemIDs.Add(itemIDs[x]);
                                    uniqueItemCosts.Add(itemCosts[x]);
                                }
                                else
                                {
                                    //If the element we're looking at isn't in our list, add it
                                    if(!uniqueItemNames.Contains(itemNames[x]))
                                    {
                                        uniqueItemNames.Add(itemNames[x]);
                                        uniqueItemIDs.Add(itemIDs[x]);
                                        uniqueItemCosts.Add(itemCosts[x]);
                                    }
                                }                         
                            }

                            //We now know our unique items
                            //Use another for loop to total them up
                            for (int x = 0; x < uniqueItemNames.Count; x++)
                            {
                                int matches = 0;
                                for(int y = 0; y < itemNames.Count; y++)
                                {
                                    if (itemNames[y] == uniqueItemNames[x])
                                        matches++;
                                }
                                ProgOps.RecordResupply(uniqueItemIDs[x], UserInfo.StaffID, uniqueItemCosts[x] * matches, matches);
                            }


                            MessageBox.Show("The resupply request has been sent to the proper suppliers!\nThey should arrive in a few weeks.", "Resupply Notice", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lbxCart.Items.Clear();
                            totalCost = 0;
                            totalItems = 0;
                            tbxDriverTip.Text = "0";
                            lblOutputTotalCost.Text = totalCost.ToString("C2");
                            lblOutputTotalItems.Text = totalItems.ToString();
                        }
                    }
                }
                else
                {
                    if (totalCost == 0)
                    {
                        MessageBox.Show("You must have at least one item in your cart to confirm your order.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                    else
                    {
                        DialogResult dialogResult;

                        //If there will be a delivery, the textbox will be different
                        if (cbxDineIn.Checked)
                        {
                            //Show normal one for just dining in
                            dialogResult = MessageBox.Show("Your order of " + totalItems.ToString() + " item(s) totalling " + totalCost.ToString("C2") + " will now be placed." +
                                "\nTax: " + tax.ToString("C2") +
                                "\nAdjusted Cost: " + (totalCost + tax).ToString("C2") +
                                "\nConfirm?", "Confirm Purchase", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        }
                        else
                        {
                            //Tax is 8.25 
                            tax = totalCost * 0.0825m;

                            dialogResult = MessageBox.Show("Your order of " + totalItems.ToString() + " item(s) totalling " + totalCost.ToString("C2") + " will now be placed." +
                                    "\nDelivery Tax: " + tax.ToString("C2") +
                                    "\nDriver Tip: $" + tbxDriverTip.Text +
                                    "\nAdjusted Cost: " + (totalCost + tax + int.Parse(tbxDriverTip.Text)).ToString("C2") +
                                    "\nConfirm?", "Confirm Purchase", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                        }


                        if (dialogResult == DialogResult.Yes)
                        {
                            if (cbxDineIn.Checked)
                            {
                                string transactionType = "";
                                if (totalItems > 1)
                                    transactionType = "Bulk Purchase";
                                else
                                    transactionType = "Single Item Purchase";

                                ProgOps.RecordTransaction(transactionType, totalCost + tax, "In-Store", false);
                                MessageBox.Show("You have within the next 3 hours to pick up your items.\nHave a nice day!", "Thank you for your purchase, " + UserInfo.firstName + "!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lbxCart.Items.Clear();
                                totalCost = 0;
                                totalItems = 0;
                                lblOutputTotalCost.Text = totalCost.ToString("C2");
                                lblOutputTotalItems.Text = totalItems.ToString();

                            }
                            else
                            {
                                string transactionType = "";
                                if (totalItems > 1)
                                    transactionType = "Bulk Purchase";
                                else
                                    transactionType = "Single Item Purchase";

                                ProgOps.RecordTransaction(transactionType, totalCost + tax + int.Parse(tbxDriverTip.Text), "Delivery", true);
                                MessageBox.Show("Your order will be delivered to you address " + UserInfo.address + " in " + UserInfo.city + ", " + UserInfo.state + " in the next 30-60 minutes!.\nHave a nice day!", "Thank you for your purchase, " + UserInfo.firstName + "!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                                lbxCart.Items.Clear();
                                totalCost = 0;
                                totalItems = 0;
                                lblOutputTotalCost.Text = totalCost.ToString("C2");
                                lblOutputTotalItems.Text = totalItems.ToString();
                            }
                        }
                    }
                }
            }
        }

        private void cbxFilterItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sqlStatement = "";

            switch (cbxFilterItems.Items[cbxFilterItems.SelectedIndex].ToString())
            {
                case "All":
                    {
                        if(UserInfo.hasAdminPermission)
                            sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Ingredient'";
                        else
                            sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType != 'Ingredient'";

                        break;
                    }
                case "Appetizers":
                    {

                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Appetizers'";

                        break;
                    }
                case "Entrees":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Entrees'";
                        break;
                    }
                case "Desserts":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Desserts'";
                        break;
                    }
                case "Kiddy":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Kiddy'";
                        break;
                    }
                case "Ingredients":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Ingredient'";
                        break;
                    }
            }

            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();
        }

        private void dgvProducts_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //Variable to hold the cost of the product's selected row
                //Purely for display purposes but is also functional
                //Decimal is used because it is the C# equivalent to money
                decimal cost = Convert.ToDecimal(dgvProducts.CurrentRow.Cells[dgvProducts.Columns[4].Index].Value);
                string item = dgvProducts.CurrentRow.Cells[dgvProducts.Columns[1].Index].Value.ToString();
                string id = dgvProducts.CurrentRow.Cells[dgvProducts.Columns[0].Index].Value.ToString();
                int quantity;

                if (e.ColumnIndex != -1 && e.RowIndex != -1)
                {
                    if (int.TryParse(tbxQuantity.Text.Trim(), out quantity) && quantity > 0)
                    {
                        if (dgvProducts.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null && dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductImage" || dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductID" || dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductName")
                        {
                            DialogResult dialogResult;

                            if (int.Parse(tbxQuantity.Text) > 1)
                            {
                                dialogResult = MessageBox.Show("You have selected " + item +
                                    "\nThe cost is " + cost.ToString("C2") +
                                    "\nQuantity: " + quantity +
                                    "\nAdjusted cost: " + (cost * quantity).ToString("C2") +
                                    "\nAdd to cart?", "Product Selection", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            }
                            else
                            {
                                dialogResult = MessageBox.Show("You have selected " + item +
                                    "\nThe cost is " + cost.ToString("C2") +
                                    "\nQuantity: " + quantity +
                                    "\nAdd to cart?", "Product Selection", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                            }
                            if (dialogResult == DialogResult.Yes)
                            {
                                MessageBox.Show("Item(s) added to cart!\nRemove your order by selecting it in the list box and pressing the Remove button as you wish!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                for (int x = 0; x < quantity; x++)
                                {
                                    itemCosts.Add(cost);
                                    itemNames.Add(item);
                                    itemIDs.Add(id);
                                    totalItems += 1;
                                    totalCost += cost;

                                    lbxCart.Items.Add(item + "\t" + cost.ToString("C2"));

                                }

                                lblOutputTotalItems.Text = totalItems.ToString();
                                lblOutputTotalCost.Text = totalCost.ToString("C2");


                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter only a number that is greater than 0 into the Quantity box!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("The cell you've selected is invalid!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Take the index where the user has selected and store it in a variable
            int index = lbxCart.SelectedIndex;

            //Make sure has selected an index
            if (lbxCart.SelectedIndex != -1)
            {
                //Remove from the list box
                lbxCart.Items.RemoveAt(index);

                //Update the two variables
                totalItems -= 1;
                totalCost -= itemCosts[index];

                //Update the labels
                lblOutputTotalItems.Text = totalItems.ToString();
                lblOutputTotalCost.Text = totalCost.ToString("C2");

                //Update the lists
                itemCosts.RemoveAt(index);
                itemNames.RemoveAt(index);
                itemIDs.RemoveAt(index);
            }
            else
            {
                MessageBox.Show("You must select an item to remove before removing!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void cbxPickup_CheckedChanged(object sender, EventArgs e)
        {
            if(cbxDineIn.Checked)
            {
                lblDriverTip.Visible = false;
                tbxDriverTip.Visible = false;
            }
            else
            {
                lblDriverTip.Visible = true;
                tbxDriverTip.Visible = true;
            }
        }
    }
}


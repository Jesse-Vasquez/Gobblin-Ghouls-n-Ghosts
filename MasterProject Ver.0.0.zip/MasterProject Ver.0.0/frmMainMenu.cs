﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkeletonProjJesse
{
    public partial class frmMainMenu : Form
    {
        public frmMainMenu()
        {
            InitializeComponent();
        }


        private void frmMain_Load(object sender, EventArgs e)
        {

        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            Application.Exit();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult;
            dialogResult = MessageBox.Show("Close this form and return to log in screen?", "Close form?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            

            if (dialogResult == DialogResult.Yes)
            {
                //Close the form
                this.Close();
            }
        }

        private void mnuShopping_Click(object sender, EventArgs e)
        {
            frmProducts products = new frmProducts();
            products.ShowDialog();
        }

        private void mnuAbout_Click(object sender, EventArgs e)
        {
            frmAbout about = new frmAbout();
            about.ShowDialog();
        }

        private void frmCustomersTable_Click(object sender, EventArgs e)
        {
            frmCustomersTable frmCustomers = new frmCustomersTable();
            frmCustomers.ShowDialog();
        }

        private void frmDeliveryTable_Click(object sender, EventArgs e)
        {
            frmDeliveryTable frmDeliveryTable = new frmDeliveryTable();
            frmDeliveryTable.ShowDialog();
        }

        private void frmOnlineUsersTable_Click(object sender, EventArgs e)
        {
            frmOnlineUsersTable frmOnlineUsersTable = new frmOnlineUsersTable();
            frmOnlineUsersTable.ShowDialog();
        }

        private void frmProductsTable_Click(object sender, EventArgs e)
        {
            frmProductsTable frmProductsTable = new frmProductsTable();
            frmProductsTable.ShowDialog();
        }

        private void frmResupplyTable_Click(object sender, EventArgs e)
        {
            frmResupplyTable frmResupplyTable = new frmResupplyTable();
            frmResupplyTable.ShowDialog();
        }

        private void frmShipmentsTable_Click(object sender, EventArgs e)
        {
            frmShipmentsTable frmShipmentsTable = new frmShipmentsTable();
            frmShipmentsTable.ShowDialog();
        }

        private void frmStaffTable_Click(object sender, EventArgs e)
        {
            frmStaffTable frmStaffTable = new frmStaffTable();
            frmStaffTable.ShowDialog();
        }

        private void frmTransactionsTable_Click(object sender, EventArgs e)
        {
            frmTransactionsTable frmTransactionsTable = new frmTransactionsTable();
            frmTransactionsTable.ShowDialog();
        }
    }
}

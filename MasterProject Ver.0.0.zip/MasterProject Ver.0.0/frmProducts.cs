﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace SkeletonProjJesse
{
    public partial class frmProducts : Form
    {
        //Form level declaration of the total cost
        decimal totalCost = 0;
        int totalItems = 0;

        //Parallel arrays for cart management
        List<decimal> itemCosts = new List<decimal>();
        List<string> itemNames = new List<string>();

        public frmProducts()
        {
            InitializeComponent();
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();
            string sqlStatement = "SELECT * FROM group6fa212330.Products";

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();

            this.Text += UserInfo.firstName + " " + UserInfo.lastName;

            //dgvProducts.Columns["ProductDescription"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;


        }

        private void lbxCart_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblCart_Click(object sender, EventArgs e)
        {

        }

        private void btnAdd_Click(object sender, EventArgs e)
        {

        }

        private void btnRemove_Click(object sender, EventArgs e)
        {

        }

        private void dgvProducts_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                //Variable to hold the cost of the product's selected row
                //Purely for display purposes but is also functional
                //Decimal is used because it is the C# equivalent to money
                decimal cost = Convert.ToDecimal(dgvProducts.CurrentRow.Cells[dgvProducts.Columns[4].Index].Value);
                string item = dgvProducts.CurrentRow.Cells[dgvProducts.Columns[1].Index].Value.ToString();
                int quantity;

                MessageBox.Show("TEST");
                if (e.ColumnIndex != -1 && e.RowIndex != -1)
                {
                    if (int.TryParse(tbxQuantity.Text.Trim(), out quantity) && quantity > 0)
                    {
                        if (dgvProducts.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null && dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductImage" || dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductID" || dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductName")
                        {
                            DialogResult dialogResult = MessageBox.Show("You have selected " + item +
                                "\nThe cost is " + cost.ToString("C2") +
                                "\nQuantity: " + quantity +
                                "\nAdjusted cost: " + (cost * quantity).ToString("C2") +
                                "\nAdd to cart?", "Product Selection", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                            if (dialogResult == DialogResult.Yes)
                            {
                                MessageBox.Show("Item(s) added to cart!\nRemove your order by selecting it in the list box and pressing the Remove button as you wish!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                for (int x = 0; x < quantity; x++)
                                {
                                    itemCosts.Add(cost);
                                    itemNames.Add(item);

                                    totalItems += 1;
                                    totalCost += cost;

                                    lbxCart.Items.Add(item + "\t" + cost.ToString("C2"));

                                }

                                lblOutputTotalItems.Text = totalItems.ToString();
                                lblOutputTotalCost.Text = totalCost.ToString("C2");


                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter only a number that is greater than 0 into the Quantity box!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("The cell you've selected is invalid!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnCheckout_Click(object sender, EventArgs e)
        {

        }

        private void cbxFilterItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sqlStatement = "";

            switch (cbxFilterItems.Items[cbxFilterItems.SelectedIndex].ToString())
            {
                case "All":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products";

                        break;
                    }
                case "Appetizers":
                    {

                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Appetizers'";

                        break;
                    }
                case "Entrees":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Entrees'";
                        break;
                    }
                case "Desserts":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Desserts'";
                        break;
                    }
                case "Kiddy":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Kiddy'";
                        break;
                    }
            }

            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();
        }

        private void gbxOrderSummary_Enter(object sender, EventArgs e)
        {

        }

        private void btnConfirmOrder_Click(object sender, EventArgs e)
        {

        }
    }
}


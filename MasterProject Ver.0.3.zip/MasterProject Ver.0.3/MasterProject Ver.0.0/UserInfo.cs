﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SkeletonProjJesse
{
    class UserInfo
    {
        //These variables are for the Customer
        public static int ID = 0;
        public static bool isVerified = true;
        public static string StaffID = "";
        public static string lastName = "";
        public static string firstName = "Guest";
        public static string city = "";
        public static string state = "";
        public static string address = "";

        //These two booleans determine the layout of the form
        public static bool isLoggedIn = false;
        public static bool hasAdminPermission = false;

        //This variable is for keeping track of where the user is
        //This will be used for if they enter the Products form
        //If the user enters the form via the gaming, merch, or trinkets menu item
        //This variable will know what queryy to run
        public static string formEntering = "";

        //Clear/Reset data
        public static void ClearData()
        {
            ID = 0;
            StaffID = "";
            lastName = "";
            firstName = "Guest";
            city = "";
            state = "";
            address = "";
            isLoggedIn = false;
            isVerified = true;
            hasAdminPermission = false;
        }
    }
}

﻿namespace VasquezJesse_ACS_Final
{
    partial class frmInsertIntoTransactions
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInsertIntoTransactions));
            this.lblTransactionType = new System.Windows.Forms.Label();
            this.tbxTransactionType = new System.Windows.Forms.TextBox();
            this.lblTransactionDate = new System.Windows.Forms.Label();
            this.tbxTransactionDate = new System.Windows.Forms.TextBox();
            this.lblTransactionAmount = new System.Windows.Forms.Label();
            this.tbxTransactionAmount = new System.Windows.Forms.TextBox();
            this.lblTransactionPickup = new System.Windows.Forms.Label();
            this.tbxTransactionPickup = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.tbxCustomerID = new System.Windows.Forms.TextBox();
            this.tbxTransactionID = new System.Windows.Forms.TextBox();
            this.lblTransactionID = new System.Windows.Forms.Label();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.lblIDDisclaimer = new System.Windows.Forms.Label();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblTransactionType
            // 
            this.lblTransactionType.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTransactionType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTransactionType.Location = new System.Drawing.Point(8, 74);
            this.lblTransactionType.Name = "lblTransactionType";
            this.lblTransactionType.Size = new System.Drawing.Size(206, 26);
            this.lblTransactionType.TabIndex = 3;
            this.lblTransactionType.Text = "Transaction Type:";
            this.lblTransactionType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxTransactionType
            // 
            this.tbxTransactionType.Location = new System.Drawing.Point(220, 74);
            this.tbxTransactionType.Name = "tbxTransactionType";
            this.tbxTransactionType.Size = new System.Drawing.Size(282, 26);
            this.tbxTransactionType.TabIndex = 4;
            // 
            // lblTransactionDate
            // 
            this.lblTransactionDate.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTransactionDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTransactionDate.Location = new System.Drawing.Point(8, 108);
            this.lblTransactionDate.Name = "lblTransactionDate";
            this.lblTransactionDate.Size = new System.Drawing.Size(206, 26);
            this.lblTransactionDate.TabIndex = 5;
            this.lblTransactionDate.Text = "Transaction Date (mm/dd/yyyy):";
            this.lblTransactionDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxTransactionDate
            // 
            this.tbxTransactionDate.Location = new System.Drawing.Point(220, 108);
            this.tbxTransactionDate.Name = "tbxTransactionDate";
            this.tbxTransactionDate.Size = new System.Drawing.Size(282, 26);
            this.tbxTransactionDate.TabIndex = 6;
            // 
            // lblTransactionAmount
            // 
            this.lblTransactionAmount.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTransactionAmount.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTransactionAmount.Location = new System.Drawing.Point(8, 142);
            this.lblTransactionAmount.Name = "lblTransactionAmount";
            this.lblTransactionAmount.Size = new System.Drawing.Size(206, 26);
            this.lblTransactionAmount.TabIndex = 7;
            this.lblTransactionAmount.Text = "Transaction Amount:";
            this.lblTransactionAmount.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxTransactionAmount
            // 
            this.tbxTransactionAmount.Location = new System.Drawing.Point(220, 142);
            this.tbxTransactionAmount.Name = "tbxTransactionAmount";
            this.tbxTransactionAmount.Size = new System.Drawing.Size(282, 26);
            this.tbxTransactionAmount.TabIndex = 8;
            // 
            // lblTransactionPickup
            // 
            this.lblTransactionPickup.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTransactionPickup.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTransactionPickup.Location = new System.Drawing.Point(8, 176);
            this.lblTransactionPickup.Name = "lblTransactionPickup";
            this.lblTransactionPickup.Size = new System.Drawing.Size(206, 26);
            this.lblTransactionPickup.TabIndex = 9;
            this.lblTransactionPickup.Text = "Transaction Pickup:";
            this.lblTransactionPickup.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxTransactionPickup
            // 
            this.tbxTransactionPickup.Location = new System.Drawing.Point(220, 176);
            this.tbxTransactionPickup.Name = "tbxTransactionPickup";
            this.tbxTransactionPickup.Size = new System.Drawing.Size(282, 26);
            this.tbxTransactionPickup.TabIndex = 10;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCustomerID.Location = new System.Drawing.Point(8, 229);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(206, 26);
            this.lblCustomerID.TabIndex = 12;
            this.lblCustomerID.Text = "Customer ID:";
            this.lblCustomerID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCustomerID
            // 
            this.tbxCustomerID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxCustomerID.Location = new System.Drawing.Point(220, 229);
            this.tbxCustomerID.Name = "tbxCustomerID";
            this.tbxCustomerID.Size = new System.Drawing.Size(125, 26);
            this.tbxCustomerID.TabIndex = 13;
            // 
            // tbxTransactionID
            // 
            this.tbxTransactionID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxTransactionID.Location = new System.Drawing.Point(220, 40);
            this.tbxTransactionID.Name = "tbxTransactionID";
            this.tbxTransactionID.ReadOnly = true;
            this.tbxTransactionID.Size = new System.Drawing.Size(73, 26);
            this.tbxTransactionID.TabIndex = 2;
            // 
            // lblTransactionID
            // 
            this.lblTransactionID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTransactionID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTransactionID.Location = new System.Drawing.Point(8, 40);
            this.lblTransactionID.Name = "lblTransactionID";
            this.lblTransactionID.Size = new System.Drawing.Size(206, 26);
            this.lblTransactionID.TabIndex = 1;
            this.lblTransactionID.Text = "Transaction ID:";
            this.lblTransactionID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(347, 262);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 17;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(261, 262);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 16;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(175, 262);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 15;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(89, 262);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 14;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // lblIDDisclaimer
            // 
            this.lblIDDisclaimer.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblIDDisclaimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIDDisclaimer.Location = new System.Drawing.Point(8, 207);
            this.lblIDDisclaimer.Name = "lblIDDisclaimer";
            this.lblIDDisclaimer.Size = new System.Drawing.Size(337, 20);
            this.lblIDDisclaimer.TabIndex = 11;
            this.lblIDDisclaimer.Text = "Customer ID must exist in database prior to insertion!";
            this.lblIDDisclaimer.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(510, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(180, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(180, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(180, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(180, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // frmInsertIntoTransactions
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(510, 306);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.lblIDDisclaimer);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.tbxTransactionID);
            this.Controls.Add(this.lblTransactionID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.tbxCustomerID);
            this.Controls.Add(this.lblTransactionPickup);
            this.Controls.Add(this.tbxTransactionPickup);
            this.Controls.Add(this.lblTransactionAmount);
            this.Controls.Add(this.tbxTransactionAmount);
            this.Controls.Add(this.lblTransactionDate);
            this.Controls.Add(this.tbxTransactionDate);
            this.Controls.Add(this.lblTransactionType);
            this.Controls.Add(this.tbxTransactionType);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmInsertIntoTransactions";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Admin | Insert Into Transactions";
            this.Load += new System.EventHandler(this.frmInsertIntoTransactions_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.Label lblTransactionType;
        private System.Windows.Forms.TextBox tbxTransactionType;
        private System.Windows.Forms.Label lblTransactionDate;
        private System.Windows.Forms.TextBox tbxTransactionDate;
        private System.Windows.Forms.Label lblTransactionAmount;
        private System.Windows.Forms.TextBox tbxTransactionAmount;
        private System.Windows.Forms.Label lblTransactionPickup;
        private System.Windows.Forms.TextBox tbxTransactionPickup;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.TextBox tbxCustomerID;
        private System.Windows.Forms.TextBox tbxTransactionID;
        private System.Windows.Forms.Label lblTransactionID;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Label lblIDDisclaimer;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
    }
}
﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using CrystalDecisions.CrystalReports.Engine;

namespace SkeletonProjJesse
{
    public partial class frmTransactionsTable : Form
    {
        //To flip through the records
        CurrencyManager manager;

        //To keep track of which record we were at last
        int lastLocation = 0;

        public frmTransactionsTable()
        {
            InitializeComponent();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void frmTransactionsTable_Load(object sender, EventArgs e)
        {
            //By default, it will be in insert mode
            AppState("Insert");
        }

        private void mnuInsert_Click(object sender, EventArgs e)
        {
            //Call the AppState function and passing it what the user wants to do
            ProgOps.DTTransactionsTable.Clear();

            AppState("Insert");
        }

        private void mnuDelete_Click(object sender, EventArgs e)
        {
            //Display the database to the text boxes
            ProgOps.DisplayTransactionsTable(tbxTransactionID, tbxTransactionType, tbxTransactionDate, tbxTransactionAmount, tbxTransactionPickup, tbxCustomerID);
            manager = (CurrencyManager)this.BindingContext[ProgOps.DTTransactionsTable];

            //Call the AppState function and passing it what the user wants to do
            AppState("Delete");
        }

        private void mnuEdit_Click(object sender, EventArgs e)
        {
            {
                //Display the contents of the database to the text boxes
                ProgOps.DisplayTransactionsTable(tbxTransactionID, tbxTransactionType, tbxTransactionDate, tbxTransactionAmount, tbxTransactionPickup, tbxCustomerID);
                manager = (CurrencyManager)this.BindingContext[ProgOps.DTTransactionsTable];
                //Call the AppState function and passing it what the user wants to do
                AppState("Edit");
            }
        }

        private void mnuClearAll_Click(object sender, EventArgs e)
        {
            //Clear all text boxes
            tbxTransactionID.Text = "";
            tbxTransactionType.Text = "";
            tbxTransactionDate.Text = "";
            tbxTransactionAmount.Text = "";
            tbxTransactionAmount.Text = "";
            tbxCustomerID.Text = "";
        }

        private void mnuAction_Click(object sender, EventArgs e)
        {
            //The action button changes text depending on what mode the user is in, so switch on the text
            //The text property still contains the accelerator key, so replace it with an empty string value
            switch (mnuAction.Text.Replace("&", ""))
            {
                case "Save Record":
                    {
                        //Check to see if all the text boxes have content, if they don't
                        if (tbxTransactionType.Text.Trim().Equals(String.Empty) || tbxTransactionDate.Text.Trim().Equals(String.Empty) || tbxTransactionAmount.Text.Trim().Equals(String.Empty) || tbxTransactionPickup.Text.Trim().Equals(String.Empty))
                        {
                            //Send error message
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            try
                            {
                                //Show confirmation before performing the insert
                                if (MessageBox.Show("Record will now be added, confirm?", "Insert Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    //ProgOps handles the actual insert, pass the textBoxes
                                    //ProgOps.InsertIntoCustomers(tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress);                                
                                    List<string> columnNames = new List<string> { "TransactionType", "TransactionDate", "TransactionAmount", "TransactionPickup", "CustomerID" };
                                    List<string> columnValues = new List<string> { tbxTransactionType.Text, tbxTransactionDate.Text, tbxTransactionAmount.Text, tbxTransactionPickup.Text, tbxCustomerID.Text };

                                    ProgOps.InsertIntoTable(columnNames, columnValues, "Transactions");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "Error inserting record!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        break;
                    }
                case "Delete Record":
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            ProgOps.DeleteFromTable(int.Parse(tbxTransactionID.Text), "TransactionID", "Transactions");
                            manager.RemoveAt(manager.Position);
                        }
                        break;
                    }
                case "Edit Record":
                    {
                        if (tbxTransactionType.Text.Trim().Equals(String.Empty) || tbxTransactionDate.Text.Trim().Equals(String.Empty) || tbxTransactionAmount.Text.Trim().Equals(String.Empty) || tbxTransactionPickup.Text.Trim().Equals(String.Empty))
                        {
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            if (MessageBox.Show("Record will now be update, confirm?", "Edit Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                List<string> columnNames = new List<string> { "TransactionType", "TransactionDate", "TransactionAmount", "TransactionPickup", "CustomerID" };
                                List<string> columnValues = new List<string> { tbxTransactionType.Text, tbxTransactionDate.Text, tbxTransactionAmount.Text, tbxTransactionPickup.Text, tbxCustomerID.Text };

                                ProgOps.UpdateTable(int.Parse(tbxTransactionID.Text), "TransactionID", columnNames, columnValues, "Transactions");

                                ProgOps.DisplayTransactionsTable(tbxTransactionID, tbxTransactionType, tbxTransactionDate, tbxTransactionAmount, tbxTransactionPickup, tbxCustomerID);
                                manager = (CurrencyManager)this.BindingContext[ProgOps.DTTransactionsTable];
                                manager.Position = lastLocation;
                            }
                        }
                        break;
                    }
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            manager.Position = 0;
            lastLocation = manager.Position;
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (manager.Position == 0)
            {
                SystemSounds.Beep.Play();
            }
            manager.Position--;
            lastLocation = manager.Position;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (manager.Position == manager.Count - 1)
            {
                SystemSounds.Beep.Play();
            }
            manager.Position++;
            lastLocation = manager.Position;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            manager.Position = manager.Count - 1;
            lastLocation = manager.Position;
        }

        public void AppState(string state)
        {
            //No matter what mode it is now in, focus on the first text box
            tbxTransactionType.Focus();

            switch (state)
            {
                case "Insert": //Insert mode
                    {
                        //Set menu and button properties
                        mnuClearAll.Enabled = true;
                        btnFirst.Enabled = false;
                        btnLast.Enabled = false;
                        btnPrevious.Enabled = false;
                        btnNext.Enabled = false;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Insert Into Transactions";
                        mnuAction.Text = "&Save Record";
                        tbxTransactionID.Text = "";
                        tbxTransactionType.Text = "";
                        tbxTransactionDate.Text = "";
                        tbxTransactionAmount.Text = "";
                        tbxTransactionAmount.Text = "";
                        tbxCustomerID.Text = "";

                        //Set the textBox properties
                        tbxTransactionID.Enabled = false;
                        tbxTransactionType.ReadOnly = false;
                        tbxTransactionDate.ReadOnly = false;
                        tbxTransactionAmount.ReadOnly = false;
                        tbxTransactionAmount.ReadOnly = false;
                        tbxCustomerID.ReadOnly = false;
                        break;
                    }
                case "Delete": //Delete mode
                    {
                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Delete From Transactions";
                        mnuAction.Text = "&Delete Record";

                        //Set the textBox properties
                        tbxTransactionID.Enabled = true;
                        tbxTransactionType.ReadOnly = true;
                        tbxTransactionDate.ReadOnly = true;
                        tbxTransactionAmount.ReadOnly = true;
                        tbxTransactionAmount.ReadOnly = true;
                        tbxCustomerID.ReadOnly = true;
                        break;
                    }
                case "Edit": //Edit mode
                    {
                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Edit Transactions";
                        mnuAction.Text = "&Edit Record";

                        //Set the textBox properties
                        tbxTransactionID.Enabled = true;
                        tbxTransactionType.ReadOnly = false;
                        tbxTransactionDate.ReadOnly = false;
                        tbxTransactionAmount.ReadOnly = false;
                        tbxTransactionAmount.ReadOnly = false;
                        tbxCustomerID.ReadOnly = false;
                        break;
                    }
                default:
                    break;
            }
        }

        private void mnuPrintData_Click(object sender, EventArgs e)
        {
            //This is used just for shorter code
            string path = Application.StartupPath;

            //Create an object of the frmViewer so we can use crvViewer (Set to public in form)
            frmViewer viewer = new frmViewer();

            //Create CrystalReport 
            ReportDocument customersReport = new ReportDocument();

            //Soft coding, to get exact file location
            //Removing the last nine characters from the string and appending the specific report in the folder
            customersReport.Load(path.Remove(path.Length - 9, 9) + @"Crystal Reports\crptTransaction.rpt");

            viewer.crvViewer.ReportSource = customersReport;

            //Show form with the crvViewer on it
            viewer.crvViewer.Refresh();

            viewer.Show();
        }
    }
}

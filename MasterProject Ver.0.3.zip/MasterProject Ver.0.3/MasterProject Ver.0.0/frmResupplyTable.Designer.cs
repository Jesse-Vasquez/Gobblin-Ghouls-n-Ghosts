﻿namespace SkeletonProjJesse
{
    partial class frmResupplyTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmResupplyTable));
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrintData = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.tbxResupplyCost = new System.Windows.Forms.TextBox();
            this.tbxResupplyDate = new System.Windows.Forms.TextBox();
            this.tbxResupplyID = new System.Windows.Forms.TextBox();
            this.lblResupplyCost = new System.Windows.Forms.Label();
            this.lblResupplyDate = new System.Windows.Forms.Label();
            this.lblResupplyID = new System.Windows.Forms.Label();
            this.tbxStaffID = new System.Windows.Forms.TextBox();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.tbxProductID = new System.Windows.Forms.TextBox();
            this.lblProductID = new System.Windows.Forms.Label();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(321, 201);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 14;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(235, 201);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 13;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(63, 201);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 11;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(149, 201);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 12;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose,
            this.mnuPrintData});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(139, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuPrintData
            // 
            this.mnuPrintData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuPrintData.Name = "mnuPrintData";
            this.mnuPrintData.Size = new System.Drawing.Size(139, 24);
            this.mnuPrintData.Text = "&Print Data";
            this.mnuPrintData.Click += new System.EventHandler(this.mnuPrintData_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(117, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(117, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(117, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(422, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // tbxResupplyCost
            // 
            this.tbxResupplyCost.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxResupplyCost.Location = new System.Drawing.Point(128, 102);
            this.tbxResupplyCost.MaxLength = 500;
            this.tbxResupplyCost.Multiline = true;
            this.tbxResupplyCost.Name = "tbxResupplyCost";
            this.tbxResupplyCost.Size = new System.Drawing.Size(117, 26);
            this.tbxResupplyCost.TabIndex = 6;
            // 
            // tbxResupplyDate
            // 
            this.tbxResupplyDate.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxResupplyDate.Location = new System.Drawing.Point(128, 70);
            this.tbxResupplyDate.MaxLength = 100;
            this.tbxResupplyDate.Name = "tbxResupplyDate";
            this.tbxResupplyDate.Size = new System.Drawing.Size(282, 26);
            this.tbxResupplyDate.TabIndex = 4;
            // 
            // tbxResupplyID
            // 
            this.tbxResupplyID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxResupplyID.Location = new System.Drawing.Point(128, 38);
            this.tbxResupplyID.MaxLength = 16;
            this.tbxResupplyID.Name = "tbxResupplyID";
            this.tbxResupplyID.Size = new System.Drawing.Size(200, 26);
            this.tbxResupplyID.TabIndex = 2;
            // 
            // lblResupplyCost
            // 
            this.lblResupplyCost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblResupplyCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResupplyCost.Location = new System.Drawing.Point(12, 102);
            this.lblResupplyCost.Name = "lblResupplyCost";
            this.lblResupplyCost.Size = new System.Drawing.Size(110, 26);
            this.lblResupplyCost.TabIndex = 5;
            this.lblResupplyCost.Text = "Resupply Cost:";
            this.lblResupplyCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblResupplyDate
            // 
            this.lblResupplyDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblResupplyDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResupplyDate.Location = new System.Drawing.Point(12, 70);
            this.lblResupplyDate.Name = "lblResupplyDate";
            this.lblResupplyDate.Size = new System.Drawing.Size(110, 26);
            this.lblResupplyDate.TabIndex = 3;
            this.lblResupplyDate.Text = "Resupply Date:";
            this.lblResupplyDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblResupplyID
            // 
            this.lblResupplyID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblResupplyID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblResupplyID.Location = new System.Drawing.Point(12, 38);
            this.lblResupplyID.Name = "lblResupplyID";
            this.lblResupplyID.Size = new System.Drawing.Size(110, 26);
            this.lblResupplyID.TabIndex = 1;
            this.lblResupplyID.Text = "Resupply ID:";
            this.lblResupplyID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxStaffID
            // 
            this.tbxStaffID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxStaffID.Location = new System.Drawing.Point(128, 134);
            this.tbxStaffID.MaxLength = 5;
            this.tbxStaffID.Name = "tbxStaffID";
            this.tbxStaffID.Size = new System.Drawing.Size(111, 26);
            this.tbxStaffID.TabIndex = 8;
            // 
            // lblStaffID
            // 
            this.lblStaffID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblStaffID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffID.Location = new System.Drawing.Point(12, 134);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(110, 26);
            this.lblStaffID.TabIndex = 7;
            this.lblStaffID.Text = "Staff ID:";
            this.lblStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxProductID
            // 
            this.tbxProductID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxProductID.Location = new System.Drawing.Point(128, 166);
            this.tbxProductID.MaxLength = 7;
            this.tbxProductID.Name = "tbxProductID";
            this.tbxProductID.Size = new System.Drawing.Size(111, 26);
            this.tbxProductID.TabIndex = 10;
            // 
            // lblProductID
            // 
            this.lblProductID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblProductID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductID.Location = new System.Drawing.Point(12, 166);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(110, 26);
            this.lblProductID.TabIndex = 9;
            this.lblProductID.Text = "Product ID:";
            this.lblProductID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmResupplyTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(422, 249);
            this.Controls.Add(this.tbxProductID);
            this.Controls.Add(this.lblProductID);
            this.Controls.Add(this.tbxStaffID);
            this.Controls.Add(this.lblStaffID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.tbxResupplyCost);
            this.Controls.Add(this.tbxResupplyDate);
            this.Controls.Add(this.tbxResupplyID);
            this.Controls.Add(this.lblResupplyCost);
            this.Controls.Add(this.lblResupplyDate);
            this.Controls.Add(this.lblResupplyID);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmResupplyTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts Admin | Resupply";
            this.Load += new System.EventHandler(this.frmResupplyTable_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.TextBox tbxResupplyCost;
        private System.Windows.Forms.TextBox tbxResupplyDate;
        private System.Windows.Forms.TextBox tbxResupplyID;
        private System.Windows.Forms.Label lblResupplyCost;
        private System.Windows.Forms.Label lblResupplyDate;
        private System.Windows.Forms.Label lblResupplyID;
        private System.Windows.Forms.TextBox tbxStaffID;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.TextBox tbxProductID;
        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.ToolStripMenuItem mnuPrintData;
    }
}
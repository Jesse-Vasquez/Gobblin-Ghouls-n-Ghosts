﻿namespace SkeletonProjJesse
{
    partial class frmBillingInformation
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmBillingInformation));
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrintData = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.tbxBillingID = new System.Windows.Forms.TextBox();
            this.lblBillingID = new System.Windows.Forms.Label();
            this.tbxBillingCardExpirationDate = new System.Windows.Forms.TextBox();
            this.lblBillingCardExpirationDate = new System.Windows.Forms.Label();
            this.tbxBillingCardCVV = new System.Windows.Forms.TextBox();
            this.lblBillingCardCVV = new System.Windows.Forms.Label();
            this.tbxBillingCardNumber = new System.Windows.Forms.TextBox();
            this.lblBillingCardNumber = new System.Windows.Forms.Label();
            this.lblBillingCardName = new System.Windows.Forms.Label();
            this.tbxBillingCardName = new System.Windows.Forms.TextBox();
            this.lblIDDisclaimer = new System.Windows.Forms.Label();
            this.lblUserID = new System.Windows.Forms.Label();
            this.tbxUserID = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.tbxCustomerID = new System.Windows.Forms.TextBox();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Padding = new System.Windows.Forms.Padding(9, 3, 0, 3);
            this.mnuMain.Size = new System.Drawing.Size(421, 29);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose,
            this.mnuPrintData});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(139, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuPrintData
            // 
            this.mnuPrintData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuPrintData.Name = "mnuPrintData";
            this.mnuPrintData.Size = new System.Drawing.Size(139, 24);
            this.mnuPrintData.Text = "&Print Data";
            this.mnuPrintData.Click += new System.EventHandler(this.mnuPrintData_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(117, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(117, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(117, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(301, 265);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 19;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(215, 265);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 18;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(129, 265);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 17;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(43, 265);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 16;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // tbxBillingID
            // 
            this.tbxBillingID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxBillingID.Location = new System.Drawing.Point(128, 38);
            this.tbxBillingID.Name = "tbxBillingID";
            this.tbxBillingID.ReadOnly = true;
            this.tbxBillingID.Size = new System.Drawing.Size(92, 26);
            this.tbxBillingID.TabIndex = 2;
            // 
            // lblBillingID
            // 
            this.lblBillingID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblBillingID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBillingID.Location = new System.Drawing.Point(10, 38);
            this.lblBillingID.Name = "lblBillingID";
            this.lblBillingID.Size = new System.Drawing.Size(112, 26);
            this.lblBillingID.TabIndex = 1;
            this.lblBillingID.Text = "Billing ID:";
            this.lblBillingID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxBillingCardExpirationDate
            // 
            this.tbxBillingCardExpirationDate.Location = new System.Drawing.Point(128, 166);
            this.tbxBillingCardExpirationDate.MaxLength = 5;
            this.tbxBillingCardExpirationDate.Name = "tbxBillingCardExpirationDate";
            this.tbxBillingCardExpirationDate.Size = new System.Drawing.Size(92, 26);
            this.tbxBillingCardExpirationDate.TabIndex = 10;
            // 
            // lblBillingCardExpirationDate
            // 
            this.lblBillingCardExpirationDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblBillingCardExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBillingCardExpirationDate.Location = new System.Drawing.Point(10, 166);
            this.lblBillingCardExpirationDate.Name = "lblBillingCardExpirationDate";
            this.lblBillingCardExpirationDate.Size = new System.Drawing.Size(112, 26);
            this.lblBillingCardExpirationDate.TabIndex = 9;
            this.lblBillingCardExpirationDate.Text = "Expiration Date:";
            this.lblBillingCardExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxBillingCardCVV
            // 
            this.tbxBillingCardCVV.Location = new System.Drawing.Point(128, 134);
            this.tbxBillingCardCVV.MaxLength = 3;
            this.tbxBillingCardCVV.Name = "tbxBillingCardCVV";
            this.tbxBillingCardCVV.Size = new System.Drawing.Size(92, 26);
            this.tbxBillingCardCVV.TabIndex = 8;
            // 
            // lblBillingCardCVV
            // 
            this.lblBillingCardCVV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblBillingCardCVV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBillingCardCVV.Location = new System.Drawing.Point(10, 134);
            this.lblBillingCardCVV.Name = "lblBillingCardCVV";
            this.lblBillingCardCVV.Size = new System.Drawing.Size(112, 26);
            this.lblBillingCardCVV.TabIndex = 7;
            this.lblBillingCardCVV.Text = "CVV:";
            this.lblBillingCardCVV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxBillingCardNumber
            // 
            this.tbxBillingCardNumber.Location = new System.Drawing.Point(128, 102);
            this.tbxBillingCardNumber.MaxLength = 16;
            this.tbxBillingCardNumber.Name = "tbxBillingCardNumber";
            this.tbxBillingCardNumber.Size = new System.Drawing.Size(282, 26);
            this.tbxBillingCardNumber.TabIndex = 6;
            // 
            // lblBillingCardNumber
            // 
            this.lblBillingCardNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblBillingCardNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBillingCardNumber.Location = new System.Drawing.Point(10, 102);
            this.lblBillingCardNumber.Name = "lblBillingCardNumber";
            this.lblBillingCardNumber.Size = new System.Drawing.Size(112, 26);
            this.lblBillingCardNumber.TabIndex = 5;
            this.lblBillingCardNumber.Text = "Card Number:";
            this.lblBillingCardNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblBillingCardName
            // 
            this.lblBillingCardName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblBillingCardName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblBillingCardName.Location = new System.Drawing.Point(10, 70);
            this.lblBillingCardName.Name = "lblBillingCardName";
            this.lblBillingCardName.Size = new System.Drawing.Size(112, 26);
            this.lblBillingCardName.TabIndex = 3;
            this.lblBillingCardName.Text = "Name on Card:";
            this.lblBillingCardName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxBillingCardName
            // 
            this.tbxBillingCardName.Location = new System.Drawing.Point(128, 70);
            this.tbxBillingCardName.MaxLength = 100;
            this.tbxBillingCardName.Name = "tbxBillingCardName";
            this.tbxBillingCardName.Size = new System.Drawing.Size(282, 26);
            this.tbxBillingCardName.TabIndex = 4;
            // 
            // lblIDDisclaimer
            // 
            this.lblIDDisclaimer.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblIDDisclaimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIDDisclaimer.Location = new System.Drawing.Point(207, 198);
            this.lblIDDisclaimer.Name = "lblIDDisclaimer";
            this.lblIDDisclaimer.Size = new System.Drawing.Size(162, 59);
            this.lblIDDisclaimer.TabIndex = 15;
            this.lblIDDisclaimer.Text = "Customer and User ID\'s must exist in database prior to insertion here!";
            // 
            // lblUserID
            // 
            this.lblUserID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUserID.Location = new System.Drawing.Point(10, 230);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(112, 26);
            this.lblUserID.TabIndex = 13;
            this.lblUserID.Text = "User ID:";
            this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxUserID
            // 
            this.tbxUserID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxUserID.Location = new System.Drawing.Point(128, 230);
            this.tbxUserID.Name = "tbxUserID";
            this.tbxUserID.Size = new System.Drawing.Size(73, 26);
            this.tbxUserID.TabIndex = 14;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCustomerID.Location = new System.Drawing.Point(10, 198);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(112, 26);
            this.lblCustomerID.TabIndex = 11;
            this.lblCustomerID.Text = "Customer ID:";
            this.lblCustomerID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCustomerID
            // 
            this.tbxCustomerID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxCustomerID.Location = new System.Drawing.Point(128, 198);
            this.tbxCustomerID.MaxLength = 5;
            this.tbxCustomerID.Name = "tbxCustomerID";
            this.tbxCustomerID.Size = new System.Drawing.Size(73, 26);
            this.tbxCustomerID.TabIndex = 12;
            // 
            // frmBillingInformation
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(421, 314);
            this.Controls.Add(this.lblIDDisclaimer);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.tbxUserID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.tbxCustomerID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.tbxBillingID);
            this.Controls.Add(this.lblBillingID);
            this.Controls.Add(this.tbxBillingCardExpirationDate);
            this.Controls.Add(this.lblBillingCardExpirationDate);
            this.Controls.Add(this.tbxBillingCardCVV);
            this.Controls.Add(this.lblBillingCardCVV);
            this.Controls.Add(this.tbxBillingCardNumber);
            this.Controls.Add(this.lblBillingCardNumber);
            this.Controls.Add(this.lblBillingCardName);
            this.Controls.Add(this.tbxBillingCardName);
            this.Controls.Add(this.mnuMain);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmBillingInformation";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts Admin | Insert Into BillingInformation";
            this.Load += new System.EventHandler(this.frmBillingInformation_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.TextBox tbxBillingID;
        private System.Windows.Forms.Label lblBillingID;
        private System.Windows.Forms.TextBox tbxBillingCardExpirationDate;
        private System.Windows.Forms.Label lblBillingCardExpirationDate;
        private System.Windows.Forms.TextBox tbxBillingCardCVV;
        private System.Windows.Forms.Label lblBillingCardCVV;
        private System.Windows.Forms.TextBox tbxBillingCardNumber;
        private System.Windows.Forms.Label lblBillingCardNumber;
        private System.Windows.Forms.Label lblBillingCardName;
        private System.Windows.Forms.TextBox tbxBillingCardName;
        private System.Windows.Forms.Label lblIDDisclaimer;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.TextBox tbxUserID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.TextBox tbxCustomerID;
        private System.Windows.Forms.ToolStripMenuItem mnuPrintData;
    }
}
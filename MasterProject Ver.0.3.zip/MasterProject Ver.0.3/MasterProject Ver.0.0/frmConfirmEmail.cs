﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Configuration;
using System.Net.Mail;

namespace SkeletonProjJesse
{
    public partial class frmConfirmEmail : Form
    {
        public frmConfirmEmail()
        {
            InitializeComponent();
        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            //Check to see if the user is entering the correct email
            if(ProgOps.VerifyEmail(tbxEmailAddress, UserInfo.ID))
            {
                //Configuration manager uses keys from App.config
                try
                {
                    MessageBox.Show(Application.StartupPath);
                    //All ConfigurationManager stuff are set as keys in App.config
                    using (MailMessage mail = new MailMessage(new MailAddress(ConfigurationManager.AppSettings["FromEmail"], ConfigurationManager.AppSettings["DisplayName"]), new MailAddress(tbxEmailAddress.Text)))
                    {

                        //Write the subject and body (The body is HTML because it's more customizable)
                        mail.Subject = "Email verified!";
                        mail.Body = "<p><strong>BOO!</strong></p>" +
                                    "<p> Thank you for confirming your email, now you can log back in and use our service to the fullest! </p>" +
                                    "<p><strong> Have a Spooktacular day...</strong></p>" +
                                    "<p><strong> Sincerely,</strong></p>" +
                                    "<p><strong> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; The Gobblin&apos; Ghouls and Ghosts Team&nbsp;</strong></p>";

                        //Attachment that loads the company logo
                        Attachment attachment;
                        attachment = new Attachment(@"Logo.png");
                        mail.Attachments.Add(attachment);

                        //Set the variable for HTML body
                        mail.IsBodyHtml = true;

                        //Smtp client to set things for email
                        SmtpClient client = new SmtpClient();

                        client.Host = ConfigurationManager.AppSettings["Host"];
                        client.EnableSsl = true;
                        NetworkCredential credentials = new NetworkCredential(ConfigurationManager.AppSettings["FromEmail"], ConfigurationManager.AppSettings["Password"]);
                        client.UseDefaultCredentials = true;
                        client.Credentials = credentials;
                        client.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
                        client.Send(mail);

                        //Show message box showing it went well
                        MessageBox.Show("Thank you! Please check your email for confirmation!", "Gobblin Ghouls and Ghosts! | Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                        //Close the form after all that
                        this.Close();
                        
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message, "Error in confirming email!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
            }
        }

    }

}

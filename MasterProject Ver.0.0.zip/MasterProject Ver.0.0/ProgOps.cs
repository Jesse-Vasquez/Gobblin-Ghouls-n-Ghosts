﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
namespace SkeletonProjJesse
{
    class ProgOps
    {
        //Connection string
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2330fa21;User ID=group6fa212330;Password=6134295;";
        //Build a connection to database
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);
        //Add the command object
        private static SqlCommand _sqlDatabaseCommand;
        //Add the data adapter
        private static SqlDataAdapter _daDatabase = new SqlDataAdapter();
        //String for the USE statement
        const string BASE_QUERY = "USE inew2330fa21;";

        private static byte[] image = null;
        //To read the database items
        private static SqlDataReader _drReader;

        //DataTable Objects for all tables
        private static DataTable _dtCustomersTable = new DataTable();
        private static DataTable _dtOnlineUsersTable = new DataTable();
        private static DataTable _dtProductsTable = new DataTable();
        private static DataTable _dtShipmentsTable = new DataTable();
        private static DataTable _dtStaffTable = new DataTable();
        private static DataTable _dtTransactionsTable = new DataTable();
        private static DataTable _dtDeliveriesTable = new DataTable();
        private static DataTable _dtResupplyTable = new DataTable();

        //Getters for the data tables
        public static DataTable DTCustomersTable
        {
            get { return _dtCustomersTable; }
        }
        public static DataTable DTOnlineUsersTable
        {
            get { return _dtOnlineUsersTable; }
        }
        public static DataTable DTProductsTable
        {
            get { return _dtProductsTable; }
        }
        public static DataTable DTShipmentsTable
        {
            get { return _dtShipmentsTable; }
        }
        public static DataTable DTStaffTable
        {
            get { return _dtStaffTable; }
        }
        public static DataTable DTTransactionsTable
        {
            get { return _dtTransactionsTable; }
        }

        public static DataTable DTDeliveriesTable
        {
            get { return _dtDeliveriesTable; }
        }

        public static DataTable DTResupplyTable
        {
            get { return _dtResupplyTable; }
        }

        //method to open database
        public static void OpenDatabase()
        {
            //open the connection to database if it already isn't
            if(_cntDatabase.State != ConnectionState.Open)
                _cntDatabase.Open();
            //message stating that connection to database was succesful
            MessageBox.Show("Hello and welcome! Please log in if you're a returning user or sign up! You can also continue and browse as a guest!", "Gobblin' Ghouls and Ghosts! | Hello!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //MessageBox.Show("Connection to database has been established!", "Database Connection Opened", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //method to close database and dispose of the connection object
        public static void CloseDisposeDatabase()
        {
            //close connection
            _cntDatabase.Close();
            //message stating that connection to database was succesful
            MessageBox.Show("Come back soon!", "Gobblin' Ghouls and Ghosts! | Farewell!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //MessageBox.Show("Database connection has been closed and disposed successfully!", "Database Connection Closed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //dispose of the connection object and command, adapter and table objects
            _cntDatabase.Dispose();

            //Check if the command is null because this may not have been initialized if the program is opened and closed
            if(_sqlDatabaseCommand != null)
                _sqlDatabaseCommand.Dispose();

            _daDatabase.Dispose();
            _dtProductsTable.Dispose();
        }

        public static void EstablishDatabase(string sqlStatement, DataTable resultsTable)
        {
            try
            {
                //Build SQL statement
                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + sqlStatement, _cntDatabase);
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                _daDatabase.Fill(resultsTable);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error in establishing the database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayProductsTable(TextBox tbxProductID, TextBox tbxProductName, TextBox tbxProductDescription, TextBox tbxProductType, TextBox tbxProductCost, PictureBox pbxProductImage, string imgLocation)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT ProductID, ProductName, ProductDescription, ProductType, ProductCost, ProductImage FROM group6fa212330.Products";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtProductsTable = new DataTable();
                _daDatabase.Fill(_dtProductsTable);

                //Bind controls to textboxe
                tbxProductID.DataBindings.Clear();
                tbxProductName.DataBindings.Clear();
                tbxProductDescription.DataBindings.Clear();
                tbxProductType.DataBindings.Clear();
                tbxProductCost.DataBindings.Clear();

                tbxProductID.DataBindings.Add("Text", _dtProductsTable, "ProductID");
                tbxProductName.DataBindings.Add("Text", _dtProductsTable, "ProductName");
                tbxProductDescription.DataBindings.Add("Text", _dtProductsTable, "ProductDescription");
                tbxProductType.DataBindings.Add("Text", _dtProductsTable, "ProductType");
                tbxProductCost.DataBindings.Add("Text", _dtProductsTable, "ProductCost");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Products Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayCustomersTable(TextBox tbxCustomerID, TextBox tbxCustomerLastName, TextBox tbxCustomerFirstName, TextBox tbxCustomerCity, TextBox tbxCustomerState, TextBox tbxCustomerAddress)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT CustomerID, CustomerLastName, CustomerFirstName, CustomerCity, CustomerState, CustomerAddress FROM group6fa212330.Customers";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtCustomersTable = new DataTable();
                _daDatabase.Fill(_dtCustomersTable);

                //Bind controls to textboxe
                tbxCustomerID.DataBindings.Clear();
                tbxCustomerLastName.DataBindings.Clear();
                tbxCustomerFirstName.DataBindings.Clear();
                tbxCustomerCity.DataBindings.Clear();
                tbxCustomerState.DataBindings.Clear();
                tbxCustomerAddress.DataBindings.Clear();

                tbxCustomerID.DataBindings.Add("Text", _dtCustomersTable, "CustomerID");
                tbxCustomerLastName.DataBindings.Add("Text", _dtCustomersTable, "CustomerLastName");
                tbxCustomerFirstName.DataBindings.Add("Text", _dtCustomersTable, "CustomerFirstName");
                tbxCustomerCity.DataBindings.Add("Text", _dtCustomersTable, "CustomerCity");
                tbxCustomerState.DataBindings.Add("Text", _dtCustomersTable, "CustomerState");
                tbxCustomerAddress.DataBindings.Add("Text", _dtCustomersTable, "CustomerAddress");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Customers Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayDeliveriesTable(TextBox tbxDeliveryID, TextBox tbxDeliveryShippedDate, TextBox tbxDeliveryDeliveredDate, TextBox tbxTransactionID)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT DeliveryID, DeliveryShippedDate, DeliveryDeliveredDate, TransactionID FROM group6fa212330.Deliveries";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtCustomersTable = new DataTable();
                _daDatabase.Fill(_dtCustomersTable);

                //Bind controls to textboxe
                tbxDeliveryID.DataBindings.Clear();
                tbxDeliveryShippedDate.DataBindings.Clear();
                tbxDeliveryDeliveredDate.DataBindings.Clear();
                tbxTransactionID.DataBindings.Clear();

                tbxDeliveryID.DataBindings.Add("Text", _dtCustomersTable, "DeliveryID");
                tbxDeliveryShippedDate.DataBindings.Add("Text", _dtCustomersTable, "DeliveryShippedDate");
                tbxDeliveryDeliveredDate.DataBindings.Add("Text", _dtCustomersTable, "DeliveryDeliveredDate");
                tbxTransactionID.DataBindings.Add("Text", _dtCustomersTable, "TransactionID");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Customers Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayOnlineUsersTable(TextBox tbxUserID, TextBox tbxUserName, TextBox tbxUserPassword, TextBox tbxUserEmail, TextBox tbxUserEmailVerified, TextBox tbxStaffID, TextBox tbxCustomerID)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT UserID, UserName, UserPassword, UserEmail, UserEmailVerified, StaffID, CustomerID FROM group6fa212330.OnlineUsers";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtOnlineUsersTable = new DataTable();
                _daDatabase.Fill(_dtOnlineUsersTable);

                //Bind controls to textboxe
                tbxUserID.DataBindings.Clear();
                tbxUserName.DataBindings.Clear();
                tbxUserPassword.DataBindings.Clear();
                tbxUserEmail.DataBindings.Clear();
                tbxUserEmailVerified.DataBindings.Clear();
                tbxStaffID.DataBindings.Clear();
                tbxCustomerID.DataBindings.Clear();

                tbxUserID.DataBindings.Add("Text", _dtOnlineUsersTable, "UserID");
                tbxUserName.DataBindings.Add("Text", _dtOnlineUsersTable, "UserName");
                tbxUserPassword.DataBindings.Add("Text", _dtOnlineUsersTable, "UserPassword");
                tbxUserEmail.DataBindings.Add("Text", _dtOnlineUsersTable, "UserEmail");
                tbxUserEmailVerified.DataBindings.Add("Text", _dtOnlineUsersTable, "UserEmailVerified");
                tbxStaffID.DataBindings.Add("Text", _dtOnlineUsersTable, "StaffID");
                tbxCustomerID.DataBindings.Add("Text", _dtOnlineUsersTable, "CustomerID");

            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display OnlineUsers Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayStaffTable(TextBox tbxStaffID, TextBox tbxStaffRole, TextBox tbxStaffLastName, TextBox tbxStaffFirstName, TextBox tbxStaffDateJoined, TextBox tbxStaffPaymentRate, TextBox tbxStaffSalary, TextBox tbxCustomerID)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT StaffID, StaffRole, StaffLastName, StaffFirstName, StaffDateJoined, StaffPaymentRate, StaffSalary, CustomerID FROM group6fa212330.Staff";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtStaffTable = new DataTable();
                _daDatabase.Fill(_dtStaffTable);

                //Bind controls to textboxe
                tbxStaffID.DataBindings.Clear();
                tbxStaffRole.DataBindings.Clear();
                tbxStaffLastName.DataBindings.Clear();
                tbxStaffFirstName.DataBindings.Clear();
                tbxStaffDateJoined.DataBindings.Clear();
                tbxStaffPaymentRate.DataBindings.Clear();
                tbxStaffSalary.DataBindings.Clear();
                tbxCustomerID.DataBindings.Clear();

                tbxStaffID.DataBindings.Add("Text", _dtStaffTable, "StaffID");
                tbxStaffRole.DataBindings.Add("Text", _dtStaffTable, "StaffRole");
                tbxStaffLastName.DataBindings.Add("Text", _dtStaffTable, "StaffLastName");
                tbxStaffFirstName.DataBindings.Add("Text", _dtStaffTable, "StaffFirstName");
                tbxStaffDateJoined.DataBindings.Add("Text", _dtStaffTable, "StaffDateJoined");
                tbxStaffPaymentRate.DataBindings.Add("Text", _dtStaffTable, "StaffPaymentRate");
                tbxStaffSalary.DataBindings.Add("Text", _dtStaffTable, "StaffSalary");
                tbxCustomerID.DataBindings.Add("Text", _dtStaffTable, "CustomerID");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Staff Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayShipmentsTable(TextBox tbxShipmentID, TextBox tbxShipmentSupplierName, TextBox tbxShipmentDate, TextBox tbxShipmentQuantity, TextBox tbxProductID)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT ShipmentID, ShipmentSupplierName, ShipmentQuantity, ShipmentDate, ProductID FROM group6fa212330.Shipments";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtShipmentsTable = new DataTable();
                _daDatabase.Fill(_dtShipmentsTable);

                //Bind controls to textboxe
                tbxShipmentID.DataBindings.Clear();
                tbxShipmentSupplierName.DataBindings.Clear();
                tbxShipmentDate.DataBindings.Clear();
                tbxShipmentQuantity.DataBindings.Clear();
                tbxProductID.DataBindings.Clear();

                tbxShipmentID.DataBindings.Add("Text", _dtShipmentsTable, "ShipmentID");
                tbxShipmentSupplierName.DataBindings.Add("Text", _dtShipmentsTable, "ShipmentSupplierName");
                tbxShipmentDate.DataBindings.Add("Text", _dtShipmentsTable, "ShipmentDate");
                tbxShipmentQuantity.DataBindings.Add("Text", _dtShipmentsTable, "ShipmentQuantity");
                tbxProductID.DataBindings.Add("Text", _dtShipmentsTable, "ProductID");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Shipments Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayResupplyTable(TextBox tbxResupplyID, TextBox tbxResupplyDate, TextBox tbxResupplyCost, TextBox tbxStaffID, TextBox tbxProductID)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT ResupplyID, ResupplyDate, ResupplyCost, StaffID, ProductID FROM group6fa212330.Resupply";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtResupplyTable = new DataTable();
                _daDatabase.Fill(_dtResupplyTable);

                //Bind controls to textboxe
                tbxResupplyID.DataBindings.Clear();
                tbxResupplyDate.DataBindings.Clear();
                tbxResupplyCost.DataBindings.Clear();
                tbxStaffID.DataBindings.Clear();
                tbxProductID.DataBindings.Clear();

                tbxResupplyID.DataBindings.Add("Text", _dtResupplyTable, "ResupplyID");
                tbxResupplyDate.DataBindings.Add("Text", _dtResupplyTable, "ResupplyDate");
                tbxResupplyCost.DataBindings.Add("Text", _dtResupplyTable, "ResupplyCost");
                tbxStaffID.DataBindings.Add("Text", _dtResupplyTable, "StaffID");
                tbxProductID.DataBindings.Add("Text", _dtResupplyTable, "ProductID");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Resupply Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisplayTransactionsTable(TextBox tbxTransactionID, TextBox tbxTransactionType, TextBox tbxTransactionDate, TextBox tbxTransactionAmount, TextBox tbxTransactionPickup, TextBox tbxCustomerID)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT TransactionID, TransactionType, TransactionDate, TransactionAmount, TransactionPickup, CustomerID FROM group6fa212330.Transactions";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                //Establish data adapter
                _daDatabase = new SqlDataAdapter();
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                //Fill data table
                _dtTransactionsTable = new DataTable();
                _daDatabase.Fill(_dtTransactionsTable);

                //Bind controls to textboxe
                tbxTransactionID.DataBindings.Clear();
                tbxTransactionType.DataBindings.Clear();
                tbxTransactionDate.DataBindings.Clear();
                tbxTransactionAmount.DataBindings.Clear();
                tbxTransactionPickup.DataBindings.Clear();
                tbxCustomerID.DataBindings.Clear();

                tbxTransactionID.DataBindings.Add("Text", _dtTransactionsTable, "TransactionID");
                tbxTransactionType.DataBindings.Add("Text", _dtTransactionsTable, "TransactionType");
                tbxTransactionDate.DataBindings.Add("Text", _dtTransactionsTable, "TransactionDate");
                tbxTransactionAmount.DataBindings.Add("Text", _dtTransactionsTable, "TransactionAmount");
                tbxTransactionPickup.DataBindings.Add("Text", _dtTransactionsTable, "TransactionPickup");
                tbxCustomerID.DataBindings.Add("Text", _dtTransactionsTable, "CustomerID");
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Unable to display Transactions Table!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void UpdateImage(PictureBox pbxProductImage, string id)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();
                //String to build query 
                string sqlStatement = BASE_QUERY + "SELECT ProductID, ProductName, ProductDescription, ProductType, ProductCost, ProductImage FROM group6fa212330.Products WHERE ProductID = '" + id + "'";

                //Establish command object 
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                if (_drReader != null)
                    _drReader.Close();

                _drReader = _sqlDatabaseCommand.ExecuteReader();
                _drReader.Read();
                if (_drReader.HasRows)
                {
                    byte[] image = (byte[])(_drReader[5]);
                    if (image == null)
                        pbxProductImage.Image = null;
                    else
                    {
                        MemoryStream msStream = new MemoryStream(image);
                        pbxProductImage.Image = System.Drawing.Image.FromStream(msStream);
                    }
                }

                _drReader.Close();

            }
            catch (Exception ex)
            {
                if (_drReader != null)
                    _drReader.Close();
                MessageBox.Show(ex.Message, "Unable to update product image!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void InsertIntoProducts(TextBox tbxProductID, TextBox tbxProductName, TextBox tbxProductDescription, TextBox tbxProductType, TextBox tbxProductCost, string imageLocation)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();
                //byte[] image = null;
                //                                            Path, mode,          and access
                FileStream fsStream = new FileStream(imageLocation, FileMode.Open, FileAccess.Read);
                BinaryReader brReader = new BinaryReader(fsStream);
                image = brReader.ReadBytes((int)fsStream.Length);

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "INSERT INTO group6fa212330.Products(ProductID, ProductName, ProductDescription, ProductType, ProductCost, ProductImage)VALUES(@ProductID, @ProductName, @ProductDescription, @ProductType, @ProductCost, @img)";
                //sqlStatement = BASE_QUERY + "INSERT INTO Products(ProductID, ProductName, ProductDescription, ProductType, ProductCost, ProductManufactor, ProductImage)VALUES('" + tbxProductID.Text + "', '" + tbxProductName.Text + "', '" + tbxProductDescription.Text + "', '" + tbxProductType.Text + "', '" + tbxProductCost.Text + "', '" + tbxProductManufactor.Text + "', '@img';)";

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ProductID", tbxProductID.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ProductName", tbxProductName.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ProductDescription", tbxProductDescription.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ProductType", tbxProductType.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ProductCost", tbxProductCost.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@img", image);
                _sqlDatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("The record has been successfully added to the Products Table!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error inserting into the Products Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Delete function where the ID is an int
        public static void DeleteFromTable(int id, string idName, string tableName)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "DELETE FROM group6fa212330." + tableName + " WHERE " + idName + " = '" + id + "'";

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                _sqlDatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("The record has been successfully been deleted from the " + tableName + " Table!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error deleting from the " + tableName + " Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Overload for Delete function where the ID is a VARCHAR
        public static void DeleteFromTable(string id, string idName, string tableName)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "DELETE FROM group6fa212330." + tableName + " WHERE " + idName + " = '" + id + "'";

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                _sqlDatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("The record has been successfully been deleted from the " + tableName + " Table!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error deleting from the " + tableName + " Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Update function
        public static void UpdateTable(int id, string idName, List<string> columnNames, List<string> columnValues, string tableName)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "UPDATE group6fa212330." + tableName + " SET ";

                for (int x = 0; x < columnNames.Count; x++)
                {
                    //If there is no value in the text box, the value should NULL
                    if (columnValues[x].Trim().Equals(""))
                    {
                        //Make the item at that index NULL
                        columnValues[x] = "NULL";

                        //If this is not the last iteration of the for loop, there needs to be a comma
                        //There is no '' for NULL values
                        if (x < columnNames.Count - 1)
                            sqlStatement += columnNames[x] + " = " + " " + columnValues[x] + ", ";
                        else
                            sqlStatement += columnNames[x] + " = " + " " + columnValues[x] + " ";

                        //Continue to next element
                        continue;
                    }

                    //If this is not the last iteration of the for loop, there needs to be a comma
                    if (x < columnNames.Count - 1)
                        sqlStatement += columnNames[x] + " = " + " '" + columnValues[x] + "', ";
                    else
                        sqlStatement += columnNames[x] + " = " + " '" + columnValues[x] + "' ";

                    // MessageBox.Show(sqlStatement);

                }

                sqlStatement += "WHERE " + idName + " = '" + id + "'";

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                _sqlDatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("The record has been successfully updated!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error deleting from the " + tableName + " Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Overloaded Update function for a table where you can change the ID
        //The old ID needs to be passed in or else the UPDATE query won't know where exactly to update with the new ID
        public static void UpdateTable(string id, string idName, List<string> columnNames, List<string> columnValues, string tableName, string oldStaffID = "")
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "UPDATE " + tableName + " SET ";

                for (int x = 0; x < columnNames.Count; x++)
                {
                    //If there is no value in the text box, the value should NULL
                    if (columnValues[x].Trim().Equals(""))
                    {
                        //Make the item at that index NULL
                        columnValues[x] = "NULL";

                        //If this is not the last iteration of the for loop, there needs to be a comma
                        //There is no '' for NULL values
                        if (x < columnNames.Count - 1)
                            sqlStatement += columnNames[x] + " = " + " " + columnValues[x] + ", ";
                        else
                            sqlStatement += columnNames[x] + " = " + " " + columnValues[x] + " ";

                        //Continue to next element
                        continue;
                    }

                    //If this is not the last iteration of the for loop, there needs to be a comma
                    if (x < columnNames.Count - 1)
                        sqlStatement += columnNames[x] + " = " + " '" + columnValues[x] + "', ";
                    else
                        sqlStatement += columnNames[x] + " = " + " '" + columnValues[x] + "' ";

                    // MessageBox.Show(sqlStatement);

                }

                //If an old ID is not passed in
                if (oldStaffID == "")
                    sqlStatement += "WHERE " + idName + " = '" + id + "'"; //Perform the normal condition for the query
                else
                    sqlStatement += "WHERE " + idName + " = '" + oldStaffID + "'"; //Specify the special condition if an old ID is passed in

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                _sqlDatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("The record has been successfully updated!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                //_daDatabase.Fill(resultsTable);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error deleting from the " + tableName + " Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
        public static void UpdateProductsTable(string ID, TextBox tbxProductName, TextBox tbxProductDescription, TextBox tbxProductType, TextBox tbxProductCost, string imageLocation)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                byte[] img = null;
                FileStream fs = new FileStream(imageLocation, FileMode.Open, FileAccess.Read);
                BinaryReader br = new BinaryReader(fs);
                img = br.ReadBytes((int)fs.Length);


                string sqlStatement = "UPDATE group6fa212330.Products SET ProductID=@ID, ProductName=@Name, ProductDescription=@Description, ProductType=@Type, ProductCost=@Cost, ProductImage=@img WHERE ProductID=@ID ";

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                _sqlDatabaseCommand.Parameters.AddWithValue("@ID", ID);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Name", tbxProductName.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Description", tbxProductDescription.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Type", tbxProductType.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Cost", tbxProductCost.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@img", img);
                _sqlDatabaseCommand.ExecuteNonQuery();

                MessageBox.Show("The record has been successfully added to the Products Table!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error updating the Products Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        //Dynamic insert function
        public static void InsertIntoTable(List<string> columnNames, List<string> columnValues, string tableName)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "INSERT INTO group6fa212330." + tableName + "(";
                //         string sqlStatement = BASE_QUERY + "INSERT INTO Customers(CustomerLastName, CustomerFirstName, CustomerCity, CustomerState, CustomerAddress)VALUES(@LastName, @FirstName, @City, @State, @Address)";

                for (int x = 0; x < columnNames.Count; x++)
                {

                    if (x < columnNames.Count - 1)
                        sqlStatement += columnNames[x] + ", ";
                    else
                        sqlStatement += columnNames[x] + ")VALUES(";

                }

                for (int x = 0; x < columnValues.Count; x++)
                {
                    if (columnValues[x].Trim().Equals(""))
                    {
                        columnValues[x] = "NULL";

                        if (x < columnNames.Count - 1)
                            sqlStatement += "" + columnValues[x] + ", ";
                        else
                            sqlStatement += "" + columnValues[x] + ")";
                        continue;
                    }

                    if (x < columnNames.Count - 1)
                        sqlStatement += "'" + columnValues[x] + "', ";
                    else
                        sqlStatement += "'" + columnValues[x] + "')";

                }
                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);

                _sqlDatabaseCommand.ExecuteNonQuery();
                MessageBox.Show("The record has been successfully updated!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error inserting into the " + tableName + " Table", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void CreateNewUser(TextBox tbxFirstName, TextBox tbxLastName, TextBox tbxCity, TextBox tbxState, TextBox tbxAddress, TextBox tbxUsername, TextBox tbxPassword, TextBox tbxEmail)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "INSERT INTO group6fa212330.Customers(CustomerLastName, CustomerFirstName, CustomerCity, CustomerState, CustomerAddress) VALUES(@LastName, @FirstName, @City, @State, @Address)";


                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);
                _sqlDatabaseCommand.Parameters.AddWithValue("@LastName", tbxLastName.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@FirstName", tbxFirstName.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@City", tbxCity.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@State", tbxState.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Address", tbxAddress.Text);
                _sqlDatabaseCommand.ExecuteNonQuery();

                string productID = String.Empty;

                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + "SELECT TOP(1)CustomerID FROM group6fa212330.Customers ORDER BY CustomerID DESC", _cntDatabase);
                _drReader = _sqlDatabaseCommand.ExecuteReader();

                if (_drReader.Read())
                {
                    productID = _drReader.GetValue(0).ToString();
                }

                _drReader.Close();

                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + "INSERT INTO group6fa212330.OnlineUsers(UserName, UserPassword, UserEmail, UserEmailVerified, CustomerID) VALUES(@Username, @Password, @Email, @EmailVerified, @ID)", _cntDatabase);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Username", tbxUsername.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Password", tbxPassword.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Email", tbxEmail.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@EmailVerified", 0);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ID", productID);
                _sqlDatabaseCommand.ExecuteNonQuery();

                MessageBox.Show("Account created. Thank you for signing up with us!", "Gobblin' Ghouls and Ghosts! | Thank you!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                if (_drReader != null)
                    _drReader.Close();
                MessageBox.Show(ex.Message, "Error in creating account!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static bool CheckLogin(TextBox tbxUsername, TextBox tbxPassword)
        {
            try
            {
                //makes sure the connection is established
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + "IF (SELECT CustomerID FROM group6fa212330.OnlineUsers WHERE UserName = @Username) IS NULL " +
                    "SELECT * FROM group6fa212330.OnlineUsers AS OU JOIN Staff AS S ON OU.StaffID = S.StaffID " +
                    "WHERE OU.UserName = @Username " +
                    "ELSE " +
                    "SELECT * FROM group6fa212330.OnlineUsers AS OU JOIN group6fa212330.Customers AS C ON OU.CustomerID = C.CustomerID " +
                    "WHERE OU.UserName = @Username", _cntDatabase);

                _sqlDatabaseCommand.Parameters.AddWithValue("@Username", tbxUsername.Text);

                _drReader = _sqlDatabaseCommand.ExecuteReader();

                string username = "", password = "";

                if (_drReader.Read())
                {
                    username = _drReader.GetValue(1).ToString();
                    password = _drReader.GetValue(2).ToString();

                    if (_drReader.GetName(7).ToString() == "StaffID")
                    {
                        UserInfo.StaffID = _drReader["StaffID"].ToString();
                        UserInfo.lastName = _drReader["StaffLastName"].ToString();
                        UserInfo.firstName = _drReader["StaffFirstName"].ToString();
                        UserInfo.hasAdminPermission = true;
                    }
                    else
                    {
                        UserInfo.ID = Convert.ToInt32(_drReader["CustomerID"]);
                        UserInfo.lastName = _drReader["CustomerLastName"].ToString();
                        UserInfo.firstName = _drReader["CustomerFirstName"].ToString();
                        UserInfo.city = _drReader["CustomerCity"].ToString();
                        UserInfo.state = _drReader["CustomerState"].ToString();
                        UserInfo.address = _drReader["CustomerAddress"].ToString();
                        UserInfo.hasAdminPermission = false;
                    }
                }

                _drReader.Close();

                if (tbxPassword.Text == password && tbxUsername.Text == username)
                    return true;
                else
                    return false;
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                if (_drReader != null)
                    _drReader.Close();
                MessageBox.Show(ex.Message, "Error checking log in!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }

        public static void DisposeDatabase()
        {
            //Dispose of the objects for reuse
            _sqlDatabaseCommand.Dispose();
            _daDatabase.Dispose();
        }
    }
}

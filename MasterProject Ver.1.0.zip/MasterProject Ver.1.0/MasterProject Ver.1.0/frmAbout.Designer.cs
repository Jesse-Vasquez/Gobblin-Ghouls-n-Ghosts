﻿
namespace SkeletonProjJesse
{
    partial class frmAbout
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAbout));
            this.mnuAbout = new System.Windows.Forms.MenuStrip();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.pbxRat = new System.Windows.Forms.PictureBox();
            this.lblAbout = new System.Windows.Forms.Label();
            this.lblDetails = new System.Windows.Forms.Label();
            this.lblContributors = new System.Windows.Forms.Label();
            this.mnuAbout.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRat)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuAbout
            // 
            this.mnuAbout.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuAbout.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuAbout.Location = new System.Drawing.Point(0, 0);
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(465, 27);
            this.mnuAbout.TabIndex = 0;
            this.mnuAbout.Text = "menuStrip1";
            // 
            // mnuClose
            // 
            this.mnuClose.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(56, 23);
            this.mnuClose.Text = "Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // pbxRat
            // 
            this.pbxRat.BackColor = System.Drawing.Color.Transparent;
            this.pbxRat.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxRat.BackgroundImage")));
            this.pbxRat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxRat.Location = new System.Drawing.Point(12, 137);
            this.pbxRat.Name = "pbxRat";
            this.pbxRat.Size = new System.Drawing.Size(124, 68);
            this.pbxRat.TabIndex = 4;
            this.pbxRat.TabStop = false;
            // 
            // lblAbout
            // 
            this.lblAbout.AutoSize = true;
            this.lblAbout.BackColor = System.Drawing.Color.Transparent;
            this.lblAbout.Font = new System.Drawing.Font("Microsoft Sans Serif", 24F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblAbout.Location = new System.Drawing.Point(18, 38);
            this.lblAbout.Name = "lblAbout";
            this.lblAbout.Size = new System.Drawing.Size(429, 37);
            this.lblAbout.TabIndex = 1;
            this.lblAbout.Text = "Gobblin\' Ghouls and Ghosts!";
            // 
            // lblDetails
            // 
            this.lblDetails.AutoSize = true;
            this.lblDetails.BackColor = System.Drawing.Color.Transparent;
            this.lblDetails.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDetails.Location = new System.Drawing.Point(181, 86);
            this.lblDetails.Name = "lblDetails";
            this.lblDetails.Size = new System.Drawing.Size(101, 60);
            this.lblDetails.TabIndex = 2;
            this.lblDetails.Text = "Version 1.0\r\n\r\nCreated by:";
            // 
            // lblContributors
            // 
            this.lblContributors.AutoSize = true;
            this.lblContributors.BackColor = System.Drawing.Color.Transparent;
            this.lblContributors.Font = new System.Drawing.Font("Microsoft Sans Serif", 8.999999F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblContributors.Location = new System.Drawing.Point(181, 157);
            this.lblContributors.Name = "lblContributors";
            this.lblContributors.Size = new System.Drawing.Size(102, 45);
            this.lblContributors.TabIndex = 3;
            this.lblContributors.Text = "Jesse Vasquez\r\nJozef Gertz\r\nShane Kelley ";
            // 
            // frmAbout
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(465, 217);
            this.Controls.Add(this.lblContributors);
            this.Controls.Add(this.lblDetails);
            this.Controls.Add(this.lblAbout);
            this.Controls.Add(this.pbxRat);
            this.Controls.Add(this.mnuAbout);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MaximizeBox = false;
            this.Name = "frmAbout";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts! | About";
            this.Load += new System.EventHandler(this.frmAbout_Load);
            this.mnuAbout.ResumeLayout(false);
            this.mnuAbout.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxRat)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.MenuStrip mnuAbout;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.PictureBox pbxRat;
        private System.Windows.Forms.Label lblAbout;
        private System.Windows.Forms.Label lblDetails;
        private System.Windows.Forms.Label lblContributors;
    }
}
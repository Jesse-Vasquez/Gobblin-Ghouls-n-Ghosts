﻿namespace SkeletonProjJesse
{
    partial class frmConfirmEmail
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmConfirmEmail));
            this.lblInstructions = new System.Windows.Forms.Label();
            this.lblEmailAddress = new System.Windows.Forms.Label();
            this.tbxEmailAddress = new System.Windows.Forms.TextBox();
            this.pbxBat = new System.Windows.Forms.PictureBox();
            this.pbxPumpkin = new System.Windows.Forms.PictureBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnClose = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxBat)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPumpkin)).BeginInit();
            this.SuspendLayout();
            // 
            // lblInstructions
            // 
            this.lblInstructions.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblInstructions.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInstructions.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblInstructions.Location = new System.Drawing.Point(9, 9);
            this.lblInstructions.Name = "lblInstructions";
            this.lblInstructions.Size = new System.Drawing.Size(426, 71);
            this.lblInstructions.TabIndex = 0;
            this.lblInstructions.Text = "To be able to use our service to the fullest, please enter your email address. An" +
    " email will be sent and you will be able to make online purchases!";
            // 
            // lblEmailAddress
            // 
            this.lblEmailAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblEmailAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEmailAddress.Location = new System.Drawing.Point(28, 87);
            this.lblEmailAddress.Name = "lblEmailAddress";
            this.lblEmailAddress.Size = new System.Drawing.Size(104, 26);
            this.lblEmailAddress.TabIndex = 1;
            this.lblEmailAddress.Text = "Email Address:";
            this.lblEmailAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxEmailAddress
            // 
            this.tbxEmailAddress.Location = new System.Drawing.Point(138, 87);
            this.tbxEmailAddress.MaxLength = 50;
            this.tbxEmailAddress.Name = "tbxEmailAddress";
            this.tbxEmailAddress.Size = new System.Drawing.Size(279, 26);
            this.tbxEmailAddress.TabIndex = 2;
            // 
            // pbxBat
            // 
            this.pbxBat.BackColor = System.Drawing.Color.Transparent;
            this.pbxBat.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxBat.Image = global::SkeletonProjJesse.Properties.Resources.Bat;
            this.pbxBat.Location = new System.Drawing.Point(316, 124);
            this.pbxBat.Name = "pbxBat";
            this.pbxBat.Size = new System.Drawing.Size(131, 94);
            this.pbxBat.SizeMode = System.Windows.Forms.PictureBoxSizeMode.Zoom;
            this.pbxBat.TabIndex = 22;
            this.pbxBat.TabStop = false;
            // 
            // pbxPumpkin
            // 
            this.pbxPumpkin.BackColor = System.Drawing.Color.Transparent;
            this.pbxPumpkin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPumpkin.BackgroundImage")));
            this.pbxPumpkin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPumpkin.Location = new System.Drawing.Point(12, 124);
            this.pbxPumpkin.Name = "pbxPumpkin";
            this.pbxPumpkin.Size = new System.Drawing.Size(131, 94);
            this.pbxPumpkin.TabIndex = 23;
            this.pbxPumpkin.TabStop = false;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(181, 126);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(82, 37);
            this.btnConfirm.TabIndex = 5;
            this.btnConfirm.Text = "&Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnClose
            // 
            this.btnClose.Location = new System.Drawing.Point(181, 172);
            this.btnClose.Name = "btnClose";
            this.btnClose.Size = new System.Drawing.Size(82, 37);
            this.btnClose.TabIndex = 6;
            this.btnClose.Text = "&Close";
            this.btnClose.UseVisualStyleBackColor = true;
            this.btnClose.Click += new System.EventHandler(this.btnClose_Click);
            // 
            // frmConfirmEmail
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(445, 224);
            this.Controls.Add(this.btnClose);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.pbxPumpkin);
            this.Controls.Add(this.pbxBat);
            this.Controls.Add(this.lblEmailAddress);
            this.Controls.Add(this.tbxEmailAddress);
            this.Controls.Add(this.lblInstructions);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmConfirmEmail";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts! | Confirm Email";
            ((System.ComponentModel.ISupportInitialize)(this.pbxBat)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPumpkin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblInstructions;
        private System.Windows.Forms.Label lblEmailAddress;
        private System.Windows.Forms.TextBox tbxEmailAddress;
        private System.Windows.Forms.PictureBox pbxBat;
        private System.Windows.Forms.PictureBox pbxPumpkin;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnClose;
    }
}
﻿
namespace SkeletonProjJesse
{
    partial class frmMainMenu
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmMainMenu));
            this.pbxWitch = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShopping = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmin = new System.Windows.Forms.ToolStripMenuItem();
            this.frmCustomersTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmDeliveryTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmOnlineUsersTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmProductsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmResupplyTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmShipmentsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmStaffTable = new System.Windows.Forms.ToolStripMenuItem();
            this.frmTransactionsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // pbxWitch
            // 
            this.pbxWitch.BackColor = System.Drawing.Color.Transparent;
            this.pbxWitch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxWitch.BackgroundImage")));
            this.pbxWitch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxWitch.Location = new System.Drawing.Point(467, 82);
            this.pbxWitch.Name = "pbxWitch";
            this.pbxWitch.Size = new System.Drawing.Size(224, 234);
            this.pbxWitch.TabIndex = 0;
            this.pbxWitch.TabStop = false;
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Transparent;
            this.pictureBox1.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pictureBox1.BackgroundImage")));
            this.pictureBox1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pictureBox1.Location = new System.Drawing.Point(0, 27);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(401, 431);
            this.pictureBox1.TabIndex = 1;
            this.pictureBox1.TabStop = false;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuShopping,
            this.mnuAdmin,
            this.mnuAbout});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(703, 27);
            this.mnuMain.TabIndex = 2;
            this.mnuMain.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(113, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuShopping
            // 
            this.mnuShopping.Name = "mnuShopping";
            this.mnuShopping.Size = new System.Drawing.Size(78, 23);
            this.mnuShopping.Text = "Shopping";
            this.mnuShopping.Click += new System.EventHandler(this.mnuShopping_Click);
            // 
            // mnuAdmin
            // 
            this.mnuAdmin.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.frmCustomersTable,
            this.frmDeliveryTable,
            this.frmOnlineUsersTable,
            this.frmProductsTable,
            this.frmResupplyTable,
            this.frmShipmentsTable,
            this.frmStaffTable,
            this.frmTransactionsTable});
            this.mnuAdmin.Name = "mnuAdmin";
            this.mnuAdmin.Size = new System.Drawing.Size(61, 23);
            this.mnuAdmin.Text = "Admin";
            // 
            // frmCustomersTable
            // 
            this.frmCustomersTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmCustomersTable.Name = "frmCustomersTable";
            this.frmCustomersTable.Size = new System.Drawing.Size(190, 24);
            this.frmCustomersTable.Text = "Customers Table";
            this.frmCustomersTable.Click += new System.EventHandler(this.frmCustomersTable_Click);
            // 
            // frmDeliveryTable
            // 
            this.frmDeliveryTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmDeliveryTable.Name = "frmDeliveryTable";
            this.frmDeliveryTable.Size = new System.Drawing.Size(190, 24);
            this.frmDeliveryTable.Text = "Delivery Table";
            this.frmDeliveryTable.Click += new System.EventHandler(this.frmDeliveryTable_Click);
            // 
            // frmOnlineUsersTable
            // 
            this.frmOnlineUsersTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmOnlineUsersTable.Name = "frmOnlineUsersTable";
            this.frmOnlineUsersTable.Size = new System.Drawing.Size(190, 24);
            this.frmOnlineUsersTable.Text = "OnlineUsers Table";
            this.frmOnlineUsersTable.Click += new System.EventHandler(this.frmOnlineUsersTable_Click);
            // 
            // frmProductsTable
            // 
            this.frmProductsTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmProductsTable.Name = "frmProductsTable";
            this.frmProductsTable.Size = new System.Drawing.Size(190, 24);
            this.frmProductsTable.Text = "Products Table";
            this.frmProductsTable.Click += new System.EventHandler(this.frmProductsTable_Click);
            // 
            // frmResupplyTable
            // 
            this.frmResupplyTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmResupplyTable.Name = "frmResupplyTable";
            this.frmResupplyTable.Size = new System.Drawing.Size(190, 24);
            this.frmResupplyTable.Text = "Resupply Table";
            this.frmResupplyTable.Click += new System.EventHandler(this.frmResupplyTable_Click);
            // 
            // frmShipmentsTable
            // 
            this.frmShipmentsTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmShipmentsTable.Name = "frmShipmentsTable";
            this.frmShipmentsTable.Size = new System.Drawing.Size(190, 24);
            this.frmShipmentsTable.Text = "Shipments Table";
            this.frmShipmentsTable.Click += new System.EventHandler(this.frmShipmentsTable_Click);
            // 
            // frmStaffTable
            // 
            this.frmStaffTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmStaffTable.Name = "frmStaffTable";
            this.frmStaffTable.Size = new System.Drawing.Size(190, 24);
            this.frmStaffTable.Text = "Staff Table";
            this.frmStaffTable.Click += new System.EventHandler(this.frmStaffTable_Click);
            // 
            // frmTransactionsTable
            // 
            this.frmTransactionsTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.frmTransactionsTable.Name = "frmTransactionsTable";
            this.frmTransactionsTable.Size = new System.Drawing.Size(190, 24);
            this.frmTransactionsTable.Text = "Transactions Table";
            this.frmTransactionsTable.Click += new System.EventHandler(this.frmTransactionsTable_Click);
            // 
            // mnuAbout
            // 
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(59, 23);
            this.mnuAbout.Text = "About";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // frmMainMenu
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(703, 411);
            this.Controls.Add(this.pictureBox1);
            this.Controls.Add(this.pbxWitch);
            this.Controls.Add(this.mnuMain);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.MainMenuStrip = this.mnuMain;
            this.MaximizeBox = false;
            this.Name = "frmMainMenu";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts! | Main Menu";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMainMenu_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxWitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pbxWitch;
        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmin;
        private System.Windows.Forms.ToolStripMenuItem mnuShopping;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem frmCustomersTable;
        private System.Windows.Forms.ToolStripMenuItem frmDeliveryTable;
        private System.Windows.Forms.ToolStripMenuItem frmOnlineUsersTable;
        private System.Windows.Forms.ToolStripMenuItem frmProductsTable;
        private System.Windows.Forms.ToolStripMenuItem frmResupplyTable;
        private System.Windows.Forms.ToolStripMenuItem frmShipmentsTable;
        private System.Windows.Forms.ToolStripMenuItem frmStaffTable;
        private System.Windows.Forms.ToolStripMenuItem frmTransactionsTable;
    }
}


﻿namespace SkeletonProjJesse
{
    partial class frmSignup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.gbxOnlineInformation = new System.Windows.Forms.GroupBox();
            this.tbxEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.tbxUsername = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.tbxConfirmPassword = new System.Windows.Forms.TextBox();
            this.tbxAddress = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.tbxState = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.tbxCity = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.tbxLastName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.gbxUserInformation = new System.Windows.Forms.GroupBox();
            this.tbxFirstName = new System.Windows.Forms.TextBox();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.gbxBillingInformation = new System.Windows.Forms.GroupBox();
            this.tbxCardNumber = new System.Windows.Forms.TextBox();
            this.lblCardNumber = new System.Windows.Forms.Label();
            this.tbxNameOnCard = new System.Windows.Forms.TextBox();
            this.lblNameOnCard = new System.Windows.Forms.Label();
            this.tbxCardCVV = new System.Windows.Forms.TextBox();
            this.lblCardCVV = new System.Windows.Forms.Label();
            this.tbxCardExpirationDate = new System.Windows.Forms.TextBox();
            this.lblCardExpirationDate = new System.Windows.Forms.Label();
            this.gbxOnlineInformation.SuspendLayout();
            this.gbxUserInformation.SuspendLayout();
            this.gbxBillingInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(254, 636);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 44);
            this.btnCancel.TabIndex = 5;
            this.btnCancel.Text = "Ca&ncel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(144, 636);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(4);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(90, 44);
            this.btnConfirm.TabIndex = 4;
            this.btnConfirm.Text = "&Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // gbxOnlineInformation
            // 
            this.gbxOnlineInformation.BackColor = System.Drawing.Color.Transparent;
            this.gbxOnlineInformation.Controls.Add(this.tbxEmail);
            this.gbxOnlineInformation.Controls.Add(this.lblEmail);
            this.gbxOnlineInformation.Controls.Add(this.tbxUsername);
            this.gbxOnlineInformation.Controls.Add(this.lblUsername);
            this.gbxOnlineInformation.Controls.Add(this.tbxPassword);
            this.gbxOnlineInformation.Controls.Add(this.lblPassword);
            this.gbxOnlineInformation.Controls.Add(this.lblConfirmPassword);
            this.gbxOnlineInformation.Controls.Add(this.tbxConfirmPassword);
            this.gbxOnlineInformation.ForeColor = System.Drawing.Color.Black;
            this.gbxOnlineInformation.Location = new System.Drawing.Point(10, 262);
            this.gbxOnlineInformation.Margin = new System.Windows.Forms.Padding(4);
            this.gbxOnlineInformation.Name = "gbxOnlineInformation";
            this.gbxOnlineInformation.Padding = new System.Windows.Forms.Padding(4);
            this.gbxOnlineInformation.Size = new System.Drawing.Size(468, 178);
            this.gbxOnlineInformation.TabIndex = 2;
            this.gbxOnlineInformation.TabStop = false;
            this.gbxOnlineInformation.Text = "Online Information";
            // 
            // tbxEmail
            // 
            this.tbxEmail.Location = new System.Drawing.Point(155, 66);
            this.tbxEmail.Margin = new System.Windows.Forms.Padding(4);
            this.tbxEmail.MaxLength = 60;
            this.tbxEmail.Name = "tbxEmail";
            this.tbxEmail.Size = new System.Drawing.Size(297, 26);
            this.tbxEmail.TabIndex = 3;
            // 
            // lblEmail
            // 
            this.lblEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEmail.Location = new System.Drawing.Point(10, 66);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(137, 26);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "Email:";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxUsername
            // 
            this.tbxUsername.Location = new System.Drawing.Point(155, 29);
            this.tbxUsername.Margin = new System.Windows.Forms.Padding(4);
            this.tbxUsername.MaxLength = 60;
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(297, 26);
            this.tbxUsername.TabIndex = 1;
            // 
            // lblUsername
            // 
            this.lblUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsername.Location = new System.Drawing.Point(10, 29);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(137, 26);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Username:";
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(155, 103);
            this.tbxPassword.Margin = new System.Windows.Forms.Padding(4);
            this.tbxPassword.MaxLength = 60;
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(297, 26);
            this.tbxPassword.TabIndex = 5;
            // 
            // lblPassword
            // 
            this.lblPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPassword.Location = new System.Drawing.Point(10, 103);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(137, 26);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password:";
            this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblConfirmPassword.Location = new System.Drawing.Point(9, 140);
            this.lblConfirmPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(137, 26);
            this.lblConfirmPassword.TabIndex = 6;
            this.lblConfirmPassword.Text = "Confirm Password:";
            this.lblConfirmPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxConfirmPassword
            // 
            this.tbxConfirmPassword.Location = new System.Drawing.Point(155, 140);
            this.tbxConfirmPassword.Margin = new System.Windows.Forms.Padding(4);
            this.tbxConfirmPassword.MaxLength = 60;
            this.tbxConfirmPassword.Name = "tbxConfirmPassword";
            this.tbxConfirmPassword.Size = new System.Drawing.Size(297, 26);
            this.tbxConfirmPassword.TabIndex = 7;
            // 
            // tbxAddress
            // 
            this.tbxAddress.Location = new System.Drawing.Point(123, 173);
            this.tbxAddress.Margin = new System.Windows.Forms.Padding(4);
            this.tbxAddress.MaxLength = 80;
            this.tbxAddress.Name = "tbxAddress";
            this.tbxAddress.Size = new System.Drawing.Size(314, 26);
            this.tbxAddress.TabIndex = 9;
            // 
            // lblState
            // 
            this.lblState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblState.Location = new System.Drawing.Point(10, 137);
            this.lblState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(105, 26);
            this.lblState.TabIndex = 6;
            this.lblState.Text = "State:";
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAddress
            // 
            this.lblAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAddress.Location = new System.Drawing.Point(10, 173);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(105, 26);
            this.lblAddress.TabIndex = 8;
            this.lblAddress.Text = "Address:";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxState
            // 
            this.tbxState.Location = new System.Drawing.Point(123, 137);
            this.tbxState.Margin = new System.Windows.Forms.Padding(4);
            this.tbxState.MaxLength = 2;
            this.tbxState.Name = "tbxState";
            this.tbxState.Size = new System.Drawing.Size(64, 26);
            this.tbxState.TabIndex = 7;
            this.tbxState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblCity
            // 
            this.lblCity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCity.Location = new System.Drawing.Point(10, 101);
            this.lblCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(105, 26);
            this.lblCity.TabIndex = 4;
            this.lblCity.Text = "City:";
            this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCity
            // 
            this.tbxCity.Location = new System.Drawing.Point(123, 101);
            this.tbxCity.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCity.MaxLength = 50;
            this.tbxCity.Name = "tbxCity";
            this.tbxCity.Size = new System.Drawing.Size(314, 26);
            this.tbxCity.TabIndex = 5;
            // 
            // lblLastName
            // 
            this.lblLastName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLastName.Location = new System.Drawing.Point(10, 65);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(105, 26);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            this.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxLastName
            // 
            this.tbxLastName.Location = new System.Drawing.Point(123, 65);
            this.tbxLastName.Margin = new System.Windows.Forms.Padding(4);
            this.tbxLastName.MaxLength = 40;
            this.tbxLastName.Name = "tbxLastName";
            this.tbxLastName.Size = new System.Drawing.Size(314, 26);
            this.tbxLastName.TabIndex = 3;
            // 
            // lblFirstName
            // 
            this.lblFirstName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFirstName.Location = new System.Drawing.Point(10, 29);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(105, 26);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            this.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gbxUserInformation
            // 
            this.gbxUserInformation.BackColor = System.Drawing.Color.Transparent;
            this.gbxUserInformation.Controls.Add(this.tbxAddress);
            this.gbxUserInformation.Controls.Add(this.lblState);
            this.gbxUserInformation.Controls.Add(this.lblAddress);
            this.gbxUserInformation.Controls.Add(this.tbxState);
            this.gbxUserInformation.Controls.Add(this.lblCity);
            this.gbxUserInformation.Controls.Add(this.tbxCity);
            this.gbxUserInformation.Controls.Add(this.lblLastName);
            this.gbxUserInformation.Controls.Add(this.tbxLastName);
            this.gbxUserInformation.Controls.Add(this.lblFirstName);
            this.gbxUserInformation.Controls.Add(this.tbxFirstName);
            this.gbxUserInformation.ForeColor = System.Drawing.Color.Black;
            this.gbxUserInformation.Location = new System.Drawing.Point(20, 44);
            this.gbxUserInformation.Margin = new System.Windows.Forms.Padding(4);
            this.gbxUserInformation.Name = "gbxUserInformation";
            this.gbxUserInformation.Padding = new System.Windows.Forms.Padding(4);
            this.gbxUserInformation.Size = new System.Drawing.Size(449, 213);
            this.gbxUserInformation.TabIndex = 1;
            this.gbxUserInformation.TabStop = false;
            this.gbxUserInformation.Text = "User Information";
            // 
            // tbxFirstName
            // 
            this.tbxFirstName.Location = new System.Drawing.Point(123, 29);
            this.tbxFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.tbxFirstName.MaxLength = 40;
            this.tbxFirstName.Name = "tbxFirstName";
            this.tbxFirstName.Size = new System.Drawing.Size(314, 26);
            this.tbxFirstName.TabIndex = 1;
            // 
            // lblPrompt
            // 
            this.lblPrompt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblPrompt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPrompt.Location = new System.Drawing.Point(11, 11);
            this.lblPrompt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(468, 29);
            this.lblPrompt.TabIndex = 0;
            this.lblPrompt.Text = "Fill in the form below to get set up!";
            this.lblPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbxBillingInformation
            // 
            this.gbxBillingInformation.BackColor = System.Drawing.Color.Transparent;
            this.gbxBillingInformation.Controls.Add(this.tbxCardExpirationDate);
            this.gbxBillingInformation.Controls.Add(this.lblCardExpirationDate);
            this.gbxBillingInformation.Controls.Add(this.tbxCardNumber);
            this.gbxBillingInformation.Controls.Add(this.lblCardNumber);
            this.gbxBillingInformation.Controls.Add(this.tbxNameOnCard);
            this.gbxBillingInformation.Controls.Add(this.lblNameOnCard);
            this.gbxBillingInformation.Controls.Add(this.tbxCardCVV);
            this.gbxBillingInformation.Controls.Add(this.lblCardCVV);
            this.gbxBillingInformation.ForeColor = System.Drawing.Color.Black;
            this.gbxBillingInformation.Location = new System.Drawing.Point(10, 449);
            this.gbxBillingInformation.Margin = new System.Windows.Forms.Padding(4);
            this.gbxBillingInformation.Name = "gbxBillingInformation";
            this.gbxBillingInformation.Padding = new System.Windows.Forms.Padding(4);
            this.gbxBillingInformation.Size = new System.Drawing.Size(468, 181);
            this.gbxBillingInformation.TabIndex = 3;
            this.gbxBillingInformation.TabStop = false;
            this.gbxBillingInformation.Text = "Billing Information";
            // 
            // tbxCardNumber
            // 
            this.tbxCardNumber.Location = new System.Drawing.Point(155, 61);
            this.tbxCardNumber.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCardNumber.MaxLength = 16;
            this.tbxCardNumber.Name = "tbxCardNumber";
            this.tbxCardNumber.Size = new System.Drawing.Size(297, 26);
            this.tbxCardNumber.TabIndex = 3;
            // 
            // lblCardNumber
            // 
            this.lblCardNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCardNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardNumber.Location = new System.Drawing.Point(10, 61);
            this.lblCardNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCardNumber.Name = "lblCardNumber";
            this.lblCardNumber.Size = new System.Drawing.Size(137, 26);
            this.lblCardNumber.TabIndex = 2;
            this.lblCardNumber.Text = "Card Number:";
            this.lblCardNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxNameOnCard
            // 
            this.tbxNameOnCard.Location = new System.Drawing.Point(155, 25);
            this.tbxNameOnCard.Margin = new System.Windows.Forms.Padding(4);
            this.tbxNameOnCard.MaxLength = 100;
            this.tbxNameOnCard.Name = "tbxNameOnCard";
            this.tbxNameOnCard.Size = new System.Drawing.Size(297, 26);
            this.tbxNameOnCard.TabIndex = 1;
            // 
            // lblNameOnCard
            // 
            this.lblNameOnCard.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblNameOnCard.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblNameOnCard.Location = new System.Drawing.Point(10, 25);
            this.lblNameOnCard.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNameOnCard.Name = "lblNameOnCard";
            this.lblNameOnCard.Size = new System.Drawing.Size(137, 26);
            this.lblNameOnCard.TabIndex = 0;
            this.lblNameOnCard.Text = "Name On Card:";
            this.lblNameOnCard.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCardCVV
            // 
            this.tbxCardCVV.Location = new System.Drawing.Point(155, 97);
            this.tbxCardCVV.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCardCVV.MaxLength = 3;
            this.tbxCardCVV.Name = "tbxCardCVV";
            this.tbxCardCVV.Size = new System.Drawing.Size(84, 26);
            this.tbxCardCVV.TabIndex = 5;
            // 
            // lblCardCVV
            // 
            this.lblCardCVV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCardCVV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardCVV.Location = new System.Drawing.Point(10, 97);
            this.lblCardCVV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCardCVV.Name = "lblCardCVV";
            this.lblCardCVV.Size = new System.Drawing.Size(137, 26);
            this.lblCardCVV.TabIndex = 4;
            this.lblCardCVV.Text = "Card CVV :";
            this.lblCardCVV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCardExpirationDate
            // 
            this.tbxCardExpirationDate.Location = new System.Drawing.Point(155, 131);
            this.tbxCardExpirationDate.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCardExpirationDate.MaxLength = 5;
            this.tbxCardExpirationDate.Name = "tbxCardExpirationDate";
            this.tbxCardExpirationDate.Size = new System.Drawing.Size(84, 26);
            this.tbxCardExpirationDate.TabIndex = 15;
            // 
            // lblCardExpirationDate
            // 
            this.lblCardExpirationDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCardExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCardExpirationDate.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCardExpirationDate.Location = new System.Drawing.Point(10, 131);
            this.lblCardExpirationDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCardExpirationDate.Name = "lblCardExpirationDate";
            this.lblCardExpirationDate.Size = new System.Drawing.Size(137, 39);
            this.lblCardExpirationDate.TabIndex = 14;
            this.lblCardExpirationDate.Text = "Expiration date: (DD/MM)";
            this.lblCardExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmSignup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(489, 687);
            this.Controls.Add(this.gbxBillingInformation);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.gbxOnlineInformation);
            this.Controls.Add(this.gbxUserInformation);
            this.Controls.Add(this.lblPrompt);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmSignup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts Admin | Sign Up!";
            this.Load += new System.EventHandler(this.frmSignup_Load);
            this.gbxOnlineInformation.ResumeLayout(false);
            this.gbxOnlineInformation.PerformLayout();
            this.gbxUserInformation.ResumeLayout(false);
            this.gbxUserInformation.PerformLayout();
            this.gbxBillingInformation.ResumeLayout(false);
            this.gbxBillingInformation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.GroupBox gbxOnlineInformation;
        private System.Windows.Forms.TextBox tbxEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.TextBox tbxUsername;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox tbxConfirmPassword;
        private System.Windows.Forms.TextBox tbxAddress;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox tbxState;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox tbxCity;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox tbxLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.GroupBox gbxUserInformation;
        private System.Windows.Forms.TextBox tbxFirstName;
        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.GroupBox gbxBillingInformation;
        private System.Windows.Forms.TextBox tbxCardNumber;
        private System.Windows.Forms.Label lblCardNumber;
        private System.Windows.Forms.TextBox tbxNameOnCard;
        private System.Windows.Forms.Label lblNameOnCard;
        private System.Windows.Forms.TextBox tbxCardCVV;
        private System.Windows.Forms.Label lblCardCVV;
        private System.Windows.Forms.TextBox tbxCardExpirationDate;
        private System.Windows.Forms.Label lblCardExpirationDate;
    }
}
﻿namespace SkeletonProjJesse
{
    partial class frmSignup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.gbxOnlineInformation = new System.Windows.Forms.GroupBox();
            this.tbxEmail = new System.Windows.Forms.TextBox();
            this.tbxUsername = new System.Windows.Forms.TextBox();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.tbxConfirmPassword = new System.Windows.Forms.TextBox();
            this.tbxAddress = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.tbxState = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.tbxCity = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.tbxLastName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.gbxUserInformation = new System.Windows.Forms.GroupBox();
            this.tbxFirstName = new System.Windows.Forms.TextBox();
            this.lblPrompt = new System.Windows.Forms.Label();
            this.gbxBilling = new System.Windows.Forms.GroupBox();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblUsername = new System.Windows.Forms.Label();
            this.lblEmail = new System.Windows.Forms.Label();
            this.lblCCNumber = new System.Windows.Forms.Label();
            this.lblCCName = new System.Windows.Forms.Label();
            this.lblCCV = new System.Windows.Forms.Label();
            this.lblExpirationDate = new System.Windows.Forms.Label();
            this.tbxCardName = new System.Windows.Forms.TextBox();
            this.tbxCardNumber = new System.Windows.Forms.TextBox();
            this.tbxCVV = new System.Windows.Forms.TextBox();
            this.tbxExpirationDate = new System.Windows.Forms.TextBox();
            this.gbxOnlineInformation.SuspendLayout();
            this.gbxUserInformation.SuspendLayout();
            this.gbxBilling.SuspendLayout();
            this.SuspendLayout();
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(254, 667);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(90, 44);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Ca&ncel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(144, 667);
            this.btnConfirm.Margin = new System.Windows.Forms.Padding(4);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(90, 44);
            this.btnConfirm.TabIndex = 3;
            this.btnConfirm.Text = "&Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // gbxOnlineInformation
            // 
            this.gbxOnlineInformation.BackColor = System.Drawing.Color.Transparent;
            this.gbxOnlineInformation.Controls.Add(this.tbxEmail);
            this.gbxOnlineInformation.Controls.Add(this.lblEmail);
            this.gbxOnlineInformation.Controls.Add(this.tbxUsername);
            this.gbxOnlineInformation.Controls.Add(this.lblUsername);
            this.gbxOnlineInformation.Controls.Add(this.tbxPassword);
            this.gbxOnlineInformation.Controls.Add(this.lblPassword);
            this.gbxOnlineInformation.Controls.Add(this.lblConfirmPassword);
            this.gbxOnlineInformation.Controls.Add(this.tbxConfirmPassword);
            this.gbxOnlineInformation.ForeColor = System.Drawing.Color.Black;
            this.gbxOnlineInformation.Location = new System.Drawing.Point(10, 287);
            this.gbxOnlineInformation.Margin = new System.Windows.Forms.Padding(4);
            this.gbxOnlineInformation.Name = "gbxOnlineInformation";
            this.gbxOnlineInformation.Padding = new System.Windows.Forms.Padding(4);
            this.gbxOnlineInformation.Size = new System.Drawing.Size(468, 184);
            this.gbxOnlineInformation.TabIndex = 2;
            this.gbxOnlineInformation.TabStop = false;
            this.gbxOnlineInformation.Text = "Online Information";
            // 
            // tbxEmail
            // 
            this.tbxEmail.Location = new System.Drawing.Point(154, 66);
            this.tbxEmail.Margin = new System.Windows.Forms.Padding(4);
            this.tbxEmail.MaxLength = 60;
            this.tbxEmail.Name = "tbxEmail";
            this.tbxEmail.Size = new System.Drawing.Size(297, 26);
            this.tbxEmail.TabIndex = 3;
            // 
            // tbxUsername
            // 
            this.tbxUsername.Location = new System.Drawing.Point(154, 27);
            this.tbxUsername.Margin = new System.Windows.Forms.Padding(4);
            this.tbxUsername.MaxLength = 60;
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(297, 26);
            this.tbxUsername.TabIndex = 1;
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(154, 105);
            this.tbxPassword.Margin = new System.Windows.Forms.Padding(4);
            this.tbxPassword.MaxLength = 60;
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(297, 26);
            this.tbxPassword.TabIndex = 5;
            // 
            // tbxConfirmPassword
            // 
            this.tbxConfirmPassword.Location = new System.Drawing.Point(154, 144);
            this.tbxConfirmPassword.Margin = new System.Windows.Forms.Padding(4);
            this.tbxConfirmPassword.MaxLength = 60;
            this.tbxConfirmPassword.Name = "tbxConfirmPassword";
            this.tbxConfirmPassword.Size = new System.Drawing.Size(297, 26);
            this.tbxConfirmPassword.TabIndex = 7;
            // 
            // tbxAddress
            // 
            this.tbxAddress.Location = new System.Drawing.Point(122, 188);
            this.tbxAddress.Margin = new System.Windows.Forms.Padding(4);
            this.tbxAddress.MaxLength = 80;
            this.tbxAddress.Name = "tbxAddress";
            this.tbxAddress.Size = new System.Drawing.Size(314, 26);
            this.tbxAddress.TabIndex = 9;
            // 
            // lblState
            // 
            this.lblState.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblState.Location = new System.Drawing.Point(9, 146);
            this.lblState.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(105, 26);
            this.lblState.TabIndex = 6;
            this.lblState.Text = "State:";
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAddress
            // 
            this.lblAddress.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAddress.Location = new System.Drawing.Point(9, 184);
            this.lblAddress.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(105, 26);
            this.lblAddress.TabIndex = 8;
            this.lblAddress.Text = "Address:";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxState
            // 
            this.tbxState.Location = new System.Drawing.Point(122, 149);
            this.tbxState.Margin = new System.Windows.Forms.Padding(4);
            this.tbxState.MaxLength = 2;
            this.tbxState.Name = "tbxState";
            this.tbxState.Size = new System.Drawing.Size(64, 26);
            this.tbxState.TabIndex = 7;
            this.tbxState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblCity
            // 
            this.lblCity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCity.Location = new System.Drawing.Point(9, 108);
            this.lblCity.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(105, 26);
            this.lblCity.TabIndex = 4;
            this.lblCity.Text = "City:";
            this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCity
            // 
            this.tbxCity.Location = new System.Drawing.Point(122, 110);
            this.tbxCity.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCity.MaxLength = 50;
            this.tbxCity.Name = "tbxCity";
            this.tbxCity.Size = new System.Drawing.Size(314, 26);
            this.tbxCity.TabIndex = 5;
            // 
            // lblLastName
            // 
            this.lblLastName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLastName.Location = new System.Drawing.Point(9, 70);
            this.lblLastName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(105, 26);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            this.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxLastName
            // 
            this.tbxLastName.Location = new System.Drawing.Point(122, 71);
            this.tbxLastName.Margin = new System.Windows.Forms.Padding(4);
            this.tbxLastName.MaxLength = 40;
            this.tbxLastName.Name = "tbxLastName";
            this.tbxLastName.Size = new System.Drawing.Size(314, 26);
            this.tbxLastName.TabIndex = 3;
            // 
            // lblFirstName
            // 
            this.lblFirstName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFirstName.Location = new System.Drawing.Point(9, 32);
            this.lblFirstName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(105, 26);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            this.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // gbxUserInformation
            // 
            this.gbxUserInformation.BackColor = System.Drawing.Color.Transparent;
            this.gbxUserInformation.Controls.Add(this.tbxAddress);
            this.gbxUserInformation.Controls.Add(this.lblState);
            this.gbxUserInformation.Controls.Add(this.lblAddress);
            this.gbxUserInformation.Controls.Add(this.tbxState);
            this.gbxUserInformation.Controls.Add(this.lblCity);
            this.gbxUserInformation.Controls.Add(this.tbxCity);
            this.gbxUserInformation.Controls.Add(this.lblLastName);
            this.gbxUserInformation.Controls.Add(this.tbxLastName);
            this.gbxUserInformation.Controls.Add(this.lblFirstName);
            this.gbxUserInformation.Controls.Add(this.tbxFirstName);
            this.gbxUserInformation.ForeColor = System.Drawing.Color.Black;
            this.gbxUserInformation.Location = new System.Drawing.Point(20, 49);
            this.gbxUserInformation.Margin = new System.Windows.Forms.Padding(4);
            this.gbxUserInformation.Name = "gbxUserInformation";
            this.gbxUserInformation.Padding = new System.Windows.Forms.Padding(4);
            this.gbxUserInformation.Size = new System.Drawing.Size(449, 230);
            this.gbxUserInformation.TabIndex = 1;
            this.gbxUserInformation.TabStop = false;
            this.gbxUserInformation.Text = "User Information";
            // 
            // tbxFirstName
            // 
            this.tbxFirstName.Location = new System.Drawing.Point(122, 32);
            this.tbxFirstName.Margin = new System.Windows.Forms.Padding(4);
            this.tbxFirstName.MaxLength = 40;
            this.tbxFirstName.Name = "tbxFirstName";
            this.tbxFirstName.Size = new System.Drawing.Size(314, 26);
            this.tbxFirstName.TabIndex = 1;
            // 
            // lblPrompt
            // 
            this.lblPrompt.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblPrompt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPrompt.Location = new System.Drawing.Point(10, 9);
            this.lblPrompt.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(468, 29);
            this.lblPrompt.TabIndex = 0;
            this.lblPrompt.Text = "Fill in the form below to get set up!";
            this.lblPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbxBilling
            // 
            this.gbxBilling.BackColor = System.Drawing.Color.Transparent;
            this.gbxBilling.Controls.Add(this.tbxExpirationDate);
            this.gbxBilling.Controls.Add(this.tbxCVV);
            this.gbxBilling.Controls.Add(this.tbxCardNumber);
            this.gbxBilling.Controls.Add(this.tbxCardName);
            this.gbxBilling.Controls.Add(this.lblCCNumber);
            this.gbxBilling.Controls.Add(this.lblCCName);
            this.gbxBilling.Controls.Add(this.lblCCV);
            this.gbxBilling.Controls.Add(this.lblExpirationDate);
            this.gbxBilling.Location = new System.Drawing.Point(10, 478);
            this.gbxBilling.Name = "gbxBilling";
            this.gbxBilling.Size = new System.Drawing.Size(468, 182);
            this.gbxBilling.TabIndex = 5;
            this.gbxBilling.TabStop = false;
            this.gbxBilling.Text = "Billing Information";
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblConfirmPassword.Location = new System.Drawing.Point(8, 144);
            this.lblConfirmPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(137, 26);
            this.lblConfirmPassword.TabIndex = 6;
            this.lblConfirmPassword.Text = "Confirm Password:";
            this.lblConfirmPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblPassword
            // 
            this.lblPassword.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPassword.Location = new System.Drawing.Point(9, 105);
            this.lblPassword.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(137, 26);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password:";
            this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUsername
            // 
            this.lblUsername.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsername.Location = new System.Drawing.Point(9, 27);
            this.lblUsername.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(137, 26);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Username:";
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblEmail
            // 
            this.lblEmail.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEmail.Location = new System.Drawing.Point(9, 66);
            this.lblEmail.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(137, 26);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "Email:";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCCNumber
            // 
            this.lblCCNumber.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCCNumber.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCCNumber.Location = new System.Drawing.Point(9, 65);
            this.lblCCNumber.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCCNumber.Name = "lblCCNumber";
            this.lblCCNumber.Size = new System.Drawing.Size(137, 26);
            this.lblCCNumber.TabIndex = 8;
            this.lblCCNumber.Text = "Card Number:";
            this.lblCCNumber.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCCName
            // 
            this.lblCCName.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCCName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCCName.Location = new System.Drawing.Point(9, 26);
            this.lblCCName.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCCName.Name = "lblCCName";
            this.lblCCName.Size = new System.Drawing.Size(137, 26);
            this.lblCCName.TabIndex = 7;
            this.lblCCName.Text = "Card Name:";
            this.lblCCName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblCCV
            // 
            this.lblCCV.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblCCV.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCCV.Location = new System.Drawing.Point(9, 104);
            this.lblCCV.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCCV.Name = "lblCCV";
            this.lblCCV.Size = new System.Drawing.Size(137, 26);
            this.lblCCV.TabIndex = 9;
            this.lblCCV.Text = "CVV:";
            this.lblCCV.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblExpirationDate
            // 
            this.lblExpirationDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblExpirationDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblExpirationDate.Location = new System.Drawing.Point(8, 143);
            this.lblExpirationDate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblExpirationDate.Name = "lblExpirationDate";
            this.lblExpirationDate.Size = new System.Drawing.Size(137, 26);
            this.lblExpirationDate.TabIndex = 10;
            this.lblExpirationDate.Text = "Expiration date:";
            this.lblExpirationDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCardName
            // 
            this.tbxCardName.Location = new System.Drawing.Point(154, 27);
            this.tbxCardName.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCardName.MaxLength = 60;
            this.tbxCardName.Name = "tbxCardName";
            this.tbxCardName.Size = new System.Drawing.Size(297, 26);
            this.tbxCardName.TabIndex = 8;
            // 
            // tbxCardNumber
            // 
            this.tbxCardNumber.Location = new System.Drawing.Point(154, 66);
            this.tbxCardNumber.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCardNumber.MaxLength = 60;
            this.tbxCardNumber.Name = "tbxCardNumber";
            this.tbxCardNumber.Size = new System.Drawing.Size(297, 26);
            this.tbxCardNumber.TabIndex = 11;
            // 
            // tbxCVV
            // 
            this.tbxCVV.Location = new System.Drawing.Point(154, 105);
            this.tbxCVV.Margin = new System.Windows.Forms.Padding(4);
            this.tbxCVV.MaxLength = 60;
            this.tbxCVV.Name = "tbxCVV";
            this.tbxCVV.Size = new System.Drawing.Size(297, 26);
            this.tbxCVV.TabIndex = 12;
            // 
            // tbxExpirationDate
            // 
            this.tbxExpirationDate.Location = new System.Drawing.Point(154, 143);
            this.tbxExpirationDate.Margin = new System.Windows.Forms.Padding(4);
            this.tbxExpirationDate.MaxLength = 60;
            this.tbxExpirationDate.Name = "tbxExpirationDate";
            this.tbxExpirationDate.Size = new System.Drawing.Size(297, 26);
            this.tbxExpirationDate.TabIndex = 13;
            // 
            // frmSignup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(489, 721);
            this.Controls.Add(this.gbxBilling);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.gbxOnlineInformation);
            this.Controls.Add(this.gbxUserInformation);
            this.Controls.Add(this.lblPrompt);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmSignup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts Admin | Sign Up!";
            this.gbxOnlineInformation.ResumeLayout(false);
            this.gbxOnlineInformation.PerformLayout();
            this.gbxUserInformation.ResumeLayout(false);
            this.gbxUserInformation.PerformLayout();
            this.gbxBilling.ResumeLayout(false);
            this.gbxBilling.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.GroupBox gbxOnlineInformation;
        private System.Windows.Forms.TextBox tbxEmail;
        private System.Windows.Forms.TextBox tbxUsername;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.TextBox tbxConfirmPassword;
        private System.Windows.Forms.TextBox tbxAddress;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox tbxState;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.TextBox tbxCity;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.TextBox tbxLastName;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.GroupBox gbxUserInformation;
        private System.Windows.Forms.TextBox tbxFirstName;
        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.GroupBox gbxBilling;
        private System.Windows.Forms.TextBox tbxExpirationDate;
        private System.Windows.Forms.TextBox tbxCVV;
        private System.Windows.Forms.TextBox tbxCardNumber;
        private System.Windows.Forms.TextBox tbxCardName;
        private System.Windows.Forms.Label lblCCNumber;
        private System.Windows.Forms.Label lblCCName;
        private System.Windows.Forms.Label lblCCV;
        private System.Windows.Forms.Label lblExpirationDate;
    }
}
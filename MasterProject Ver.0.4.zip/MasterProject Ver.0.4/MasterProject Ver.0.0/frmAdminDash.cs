﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkeletonProjJesse
{
    public partial class frmAdminDash : Form
    {
        public frmAdminDash()
        {
            InitializeComponent();
        }

        private void mnuBillingInformationTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmBillingInformation form = new frmBillingInformation();
            form.ShowDialog();
        }

        private void mnuCustomersTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmCustomersTable form = new frmCustomersTable();
            form.ShowDialog();
        }

        private void mnuDeliveryTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmDeliveryTable form = new frmDeliveryTable();
            form.ShowDialog();
        }

        private void mnuOnlineUsersTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmOnlineUsersTable form = new frmOnlineUsersTable();
            form.ShowDialog();
        }

        private void mnuProductsTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmProductsTable form = new frmProductsTable();
            form.ShowDialog();
        }

        private void mnuResupplyTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmResupplyTable form = new frmResupplyTable();
            form.ShowDialog();
        }

        private void mnuShipmentsTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmShipmentsTable form = new frmShipmentsTable();
            form.ShowDialog();
        }

        private void mnuStaffTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmStaffTable form = new frmStaffTable();
            form.ShowDialog();
        }

        private void mnuTransactionsTable_Click(object sender, EventArgs e)
        {
            //Open modal form for the respective menu element
            frmTransactionsTable form = new frmTransactionsTable();
            form.ShowDialog();
        }

        private void mnuResupplyStock_Click(object sender, EventArgs e)
        {
            //Open the products form, but change the layout to make it more fitting for admin
            frmProducts form = new frmProducts();
            form.ShowDialog();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void frmAdminDash_FormClosing(object sender, FormClosingEventArgs e)
        {
            //Clear the UserInfo class when the user returns to Login Screen
            UserInfo.ClearData();
        }

        private void mnuAbout_Click(object sender, EventArgs e)
        {
            //Open the about form
            frmAbout form = new frmAbout();
            form.ShowDialog();      
        }
    }
}

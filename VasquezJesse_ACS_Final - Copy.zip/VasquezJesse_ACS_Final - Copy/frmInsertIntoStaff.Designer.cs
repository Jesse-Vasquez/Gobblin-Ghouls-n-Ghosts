﻿namespace VasquezJesse_ACS_Final
{
    partial class frmInsertIntoStaff
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInsertIntoStaff));
            this.tbxStaffID = new System.Windows.Forms.TextBox();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.tbxStaffRole = new System.Windows.Forms.TextBox();
            this.lblStaffRole = new System.Windows.Forms.Label();
            this.tbxStaffFirstName = new System.Windows.Forms.TextBox();
            this.lblStaffFirstName = new System.Windows.Forms.Label();
            this.tbxStaffLastName = new System.Windows.Forms.TextBox();
            this.lblStaffLastName = new System.Windows.Forms.Label();
            this.tbxStaffDateJoined = new System.Windows.Forms.TextBox();
            this.lblStaffDateJoined = new System.Windows.Forms.Label();
            this.tbxCustomerID = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxStaffID
            // 
            this.tbxStaffID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxStaffID.Location = new System.Drawing.Point(189, 37);
            this.tbxStaffID.MaxLength = 5;
            this.tbxStaffID.Name = "tbxStaffID";
            this.tbxStaffID.Size = new System.Drawing.Size(98, 26);
            this.tbxStaffID.TabIndex = 2;
            // 
            // lblStaffID
            // 
            this.lblStaffID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblStaffID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffID.Location = new System.Drawing.Point(8, 37);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(175, 26);
            this.lblStaffID.TabIndex = 1;
            this.lblStaffID.Text = "Staff ID:";
            this.lblStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxStaffRole
            // 
            this.tbxStaffRole.Location = new System.Drawing.Point(189, 69);
            this.tbxStaffRole.Name = "tbxStaffRole";
            this.tbxStaffRole.Size = new System.Drawing.Size(204, 26);
            this.tbxStaffRole.TabIndex = 4;
            // 
            // lblStaffRole
            // 
            this.lblStaffRole.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblStaffRole.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffRole.Location = new System.Drawing.Point(8, 69);
            this.lblStaffRole.Name = "lblStaffRole";
            this.lblStaffRole.Size = new System.Drawing.Size(175, 26);
            this.lblStaffRole.TabIndex = 3;
            this.lblStaffRole.Text = "Staff Role:";
            this.lblStaffRole.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxStaffFirstName
            // 
            this.tbxStaffFirstName.Location = new System.Drawing.Point(189, 101);
            this.tbxStaffFirstName.Name = "tbxStaffFirstName";
            this.tbxStaffFirstName.Size = new System.Drawing.Size(204, 26);
            this.tbxStaffFirstName.TabIndex = 6;
            // 
            // lblStaffFirstName
            // 
            this.lblStaffFirstName.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblStaffFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffFirstName.Location = new System.Drawing.Point(8, 101);
            this.lblStaffFirstName.Name = "lblStaffFirstName";
            this.lblStaffFirstName.Size = new System.Drawing.Size(175, 26);
            this.lblStaffFirstName.TabIndex = 5;
            this.lblStaffFirstName.Text = "Staff First Name:";
            this.lblStaffFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxStaffLastName
            // 
            this.tbxStaffLastName.Location = new System.Drawing.Point(189, 133);
            this.tbxStaffLastName.Name = "tbxStaffLastName";
            this.tbxStaffLastName.Size = new System.Drawing.Size(204, 26);
            this.tbxStaffLastName.TabIndex = 8;
            // 
            // lblStaffLastName
            // 
            this.lblStaffLastName.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblStaffLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffLastName.Location = new System.Drawing.Point(8, 133);
            this.lblStaffLastName.Name = "lblStaffLastName";
            this.lblStaffLastName.Size = new System.Drawing.Size(175, 26);
            this.lblStaffLastName.TabIndex = 7;
            this.lblStaffLastName.Text = "Staff Last Name:";
            this.lblStaffLastName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxStaffDateJoined
            // 
            this.tbxStaffDateJoined.Location = new System.Drawing.Point(189, 165);
            this.tbxStaffDateJoined.Name = "tbxStaffDateJoined";
            this.tbxStaffDateJoined.Size = new System.Drawing.Size(202, 26);
            this.tbxStaffDateJoined.TabIndex = 10;
            // 
            // lblStaffDateJoined
            // 
            this.lblStaffDateJoined.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblStaffDateJoined.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffDateJoined.Location = new System.Drawing.Point(8, 165);
            this.lblStaffDateJoined.Name = "lblStaffDateJoined";
            this.lblStaffDateJoined.Size = new System.Drawing.Size(175, 26);
            this.lblStaffDateJoined.TabIndex = 9;
            this.lblStaffDateJoined.Text = "Date Joined (mm/dd/yyyy):";
            this.lblStaffDateJoined.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCustomerID
            // 
            this.tbxCustomerID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxCustomerID.Location = new System.Drawing.Point(189, 197);
            this.tbxCustomerID.Name = "tbxCustomerID";
            this.tbxCustomerID.Size = new System.Drawing.Size(98, 26);
            this.tbxCustomerID.TabIndex = 12;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCustomerID.Location = new System.Drawing.Point(8, 197);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(175, 26);
            this.lblCustomerID.TabIndex = 11;
            this.lblCustomerID.Text = "Customer ID:";
            this.lblCustomerID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(403, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(180, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(180, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(180, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(180, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(292, 231);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 16;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(206, 231);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 15;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(120, 231);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 14;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(34, 231);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 13;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // frmInsertIntoStaff
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(403, 277);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.tbxCustomerID);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.tbxStaffDateJoined);
            this.Controls.Add(this.lblStaffDateJoined);
            this.Controls.Add(this.tbxStaffLastName);
            this.Controls.Add(this.lblStaffLastName);
            this.Controls.Add(this.tbxStaffFirstName);
            this.Controls.Add(this.lblStaffFirstName);
            this.Controls.Add(this.tbxStaffRole);
            this.Controls.Add(this.lblStaffRole);
            this.Controls.Add(this.tbxStaffID);
            this.Controls.Add(this.lblStaffID);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmInsertIntoStaff";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Admin | Insert Into Staff";
            this.Load += new System.EventHandler(this.frmInsertIntoStaff_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxStaffID;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.TextBox tbxStaffRole;
        private System.Windows.Forms.Label lblStaffRole;
        private System.Windows.Forms.TextBox tbxStaffFirstName;
        private System.Windows.Forms.Label lblStaffFirstName;
        private System.Windows.Forms.TextBox tbxStaffLastName;
        private System.Windows.Forms.Label lblStaffLastName;
        private System.Windows.Forms.TextBox tbxStaffDateJoined;
        private System.Windows.Forms.Label lblStaffDateJoined;
        private System.Windows.Forms.TextBox tbxCustomerID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
    }
}
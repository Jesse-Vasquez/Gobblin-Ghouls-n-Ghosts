﻿namespace VasquezJesse_ACS_Final
{
    partial class frmInsertIntoProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInsertIntoProducts));
            this.lblProductID = new System.Windows.Forms.Label();
            this.lblProductName = new System.Windows.Forms.Label();
            this.lblProductDescription = new System.Windows.Forms.Label();
            this.lblProductType = new System.Windows.Forms.Label();
            this.lblProductCost = new System.Windows.Forms.Label();
            this.tbxProductID = new System.Windows.Forms.TextBox();
            this.tbxProductName = new System.Windows.Forms.TextBox();
            this.tbxProductDescription = new System.Windows.Forms.TextBox();
            this.tbxProductCost = new System.Windows.Forms.TextBox();
            this.lblProductImage = new System.Windows.Forms.Label();
            this.btnBrowseImage = new System.Windows.Forms.Button();
            this.tbxProductType = new System.Windows.Forms.TextBox();
            this.tbxProductManufactor = new System.Windows.Forms.TextBox();
            this.lblProductManufactor = new System.Windows.Forms.Label();
            this.pbxProductImage = new System.Windows.Forms.PictureBox();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProductImage)).BeginInit();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblProductID
            // 
            this.lblProductID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductID.Location = new System.Drawing.Point(8, 41);
            this.lblProductID.Name = "lblProductID";
            this.lblProductID.Size = new System.Drawing.Size(149, 26);
            this.lblProductID.TabIndex = 1;
            this.lblProductID.Text = "Product ID:";
            this.lblProductID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProductName
            // 
            this.lblProductName.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductName.Location = new System.Drawing.Point(8, 73);
            this.lblProductName.Name = "lblProductName";
            this.lblProductName.Size = new System.Drawing.Size(149, 26);
            this.lblProductName.TabIndex = 3;
            this.lblProductName.Text = "Product Name:";
            this.lblProductName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProductDescription
            // 
            this.lblProductDescription.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductDescription.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductDescription.Location = new System.Drawing.Point(8, 105);
            this.lblProductDescription.Name = "lblProductDescription";
            this.lblProductDescription.Size = new System.Drawing.Size(149, 26);
            this.lblProductDescription.TabIndex = 5;
            this.lblProductDescription.Text = "Product Description:";
            this.lblProductDescription.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProductType
            // 
            this.lblProductType.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductType.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductType.Location = new System.Drawing.Point(8, 264);
            this.lblProductType.Name = "lblProductType";
            this.lblProductType.Size = new System.Drawing.Size(149, 26);
            this.lblProductType.TabIndex = 7;
            this.lblProductType.Text = "Product Type:";
            this.lblProductType.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblProductCost
            // 
            this.lblProductCost.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductCost.Location = new System.Drawing.Point(8, 296);
            this.lblProductCost.Name = "lblProductCost";
            this.lblProductCost.Size = new System.Drawing.Size(149, 26);
            this.lblProductCost.TabIndex = 9;
            this.lblProductCost.Text = "Product Cost:";
            this.lblProductCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxProductID
            // 
            this.tbxProductID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxProductID.Location = new System.Drawing.Point(164, 41);
            this.tbxProductID.MaxLength = 7;
            this.tbxProductID.Name = "tbxProductID";
            this.tbxProductID.Size = new System.Drawing.Size(282, 26);
            this.tbxProductID.TabIndex = 2;
            // 
            // tbxProductName
            // 
            this.tbxProductName.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxProductName.Location = new System.Drawing.Point(164, 73);
            this.tbxProductName.MaxLength = 100;
            this.tbxProductName.Name = "tbxProductName";
            this.tbxProductName.Size = new System.Drawing.Size(282, 25);
            this.tbxProductName.TabIndex = 4;
            // 
            // tbxProductDescription
            // 
            this.tbxProductDescription.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxProductDescription.Location = new System.Drawing.Point(164, 105);
            this.tbxProductDescription.MaxLength = 500;
            this.tbxProductDescription.Multiline = true;
            this.tbxProductDescription.Name = "tbxProductDescription";
            this.tbxProductDescription.Size = new System.Drawing.Size(282, 153);
            this.tbxProductDescription.TabIndex = 6;
            // 
            // tbxProductCost
            // 
            this.tbxProductCost.Location = new System.Drawing.Point(164, 296);
            this.tbxProductCost.Name = "tbxProductCost";
            this.tbxProductCost.Size = new System.Drawing.Size(282, 26);
            this.tbxProductCost.TabIndex = 10;
            // 
            // lblProductImage
            // 
            this.lblProductImage.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductImage.Location = new System.Drawing.Point(8, 362);
            this.lblProductImage.Name = "lblProductImage";
            this.lblProductImage.Size = new System.Drawing.Size(118, 26);
            this.lblProductImage.TabIndex = 13;
            this.lblProductImage.Text = "Product Image:";
            this.lblProductImage.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // btnBrowseImage
            // 
            this.btnBrowseImage.Location = new System.Drawing.Point(48, 391);
            this.btnBrowseImage.Name = "btnBrowseImage";
            this.btnBrowseImage.Size = new System.Drawing.Size(78, 51);
            this.btnBrowseImage.TabIndex = 14;
            this.btnBrowseImage.Text = "&Browse Image";
            this.btnBrowseImage.UseVisualStyleBackColor = true;
            this.btnBrowseImage.Click += new System.EventHandler(this.btnBrowseImage_Click);
            // 
            // tbxProductType
            // 
            this.tbxProductType.Location = new System.Drawing.Point(164, 264);
            this.tbxProductType.MaxLength = 30;
            this.tbxProductType.Name = "tbxProductType";
            this.tbxProductType.Size = new System.Drawing.Size(282, 26);
            this.tbxProductType.TabIndex = 8;
            // 
            // tbxProductManufactor
            // 
            this.tbxProductManufactor.Location = new System.Drawing.Point(164, 328);
            this.tbxProductManufactor.MaxLength = 50;
            this.tbxProductManufactor.Name = "tbxProductManufactor";
            this.tbxProductManufactor.Size = new System.Drawing.Size(282, 26);
            this.tbxProductManufactor.TabIndex = 12;
            // 
            // lblProductManufactor
            // 
            this.lblProductManufactor.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblProductManufactor.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblProductManufactor.Location = new System.Drawing.Point(8, 328);
            this.lblProductManufactor.Name = "lblProductManufactor";
            this.lblProductManufactor.Size = new System.Drawing.Size(149, 26);
            this.lblProductManufactor.TabIndex = 11;
            this.lblProductManufactor.Text = "Product Manufacturer:";
            this.lblProductManufactor.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pbxProductImage
            // 
            this.pbxProductImage.BackColor = System.Drawing.SystemColors.Control;
            this.pbxProductImage.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxProductImage.Location = new System.Drawing.Point(132, 362);
            this.pbxProductImage.Name = "pbxProductImage";
            this.pbxProductImage.Size = new System.Drawing.Size(314, 205);
            this.pbxProductImage.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProductImage.TabIndex = 10;
            this.pbxProductImage.TabStop = false;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(454, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(180, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(180, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(180, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(180, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(318, 573);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 18;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(232, 573);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 17;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(146, 573);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 16;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(60, 573);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 15;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // frmInsertIntoProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(454, 616);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.tbxProductManufactor);
            this.Controls.Add(this.lblProductManufactor);
            this.Controls.Add(this.btnBrowseImage);
            this.Controls.Add(this.lblProductImage);
            this.Controls.Add(this.pbxProductImage);
            this.Controls.Add(this.tbxProductCost);
            this.Controls.Add(this.tbxProductType);
            this.Controls.Add(this.tbxProductDescription);
            this.Controls.Add(this.tbxProductName);
            this.Controls.Add(this.tbxProductID);
            this.Controls.Add(this.lblProductCost);
            this.Controls.Add(this.lblProductType);
            this.Controls.Add(this.lblProductDescription);
            this.Controls.Add(this.lblProductName);
            this.Controls.Add(this.lblProductID);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmInsertIntoProducts";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Admin | Insert Into Products";
            this.Load += new System.EventHandler(this.frmInsertIntoProducts_Load);
            ((System.ComponentModel.ISupportInitialize)(this.pbxProductImage)).EndInit();
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblProductID;
        private System.Windows.Forms.Label lblProductName;
        private System.Windows.Forms.Label lblProductDescription;
        private System.Windows.Forms.Label lblProductType;
        private System.Windows.Forms.Label lblProductCost;
        private System.Windows.Forms.TextBox tbxProductID;
        private System.Windows.Forms.TextBox tbxProductName;
        private System.Windows.Forms.TextBox tbxProductDescription;
        private System.Windows.Forms.TextBox tbxProductCost;
        private System.Windows.Forms.PictureBox pbxProductImage;
        private System.Windows.Forms.Label lblProductImage;
        private System.Windows.Forms.Button btnBrowseImage;
        private System.Windows.Forms.TextBox tbxProductType;
        private System.Windows.Forms.TextBox tbxProductManufactor;
        private System.Windows.Forms.Label lblProductManufactor;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
    }
}
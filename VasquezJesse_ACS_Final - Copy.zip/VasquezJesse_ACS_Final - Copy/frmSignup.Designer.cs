﻿namespace VasquezJesse_ACS_Final
{
    partial class frmSignup
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmSignup));
            this.lblPrompt = new System.Windows.Forms.Label();
            this.gbxUserInformation = new System.Windows.Forms.GroupBox();
            this.tbxAddress = new System.Windows.Forms.TextBox();
            this.lblState = new System.Windows.Forms.Label();
            this.lblAddress = new System.Windows.Forms.Label();
            this.tbxState = new System.Windows.Forms.TextBox();
            this.lblCity = new System.Windows.Forms.Label();
            this.tbxCity = new System.Windows.Forms.TextBox();
            this.lblLastName = new System.Windows.Forms.Label();
            this.tbxLastName = new System.Windows.Forms.TextBox();
            this.lblFirstName = new System.Windows.Forms.Label();
            this.tbxFirstName = new System.Windows.Forms.TextBox();
            this.gbxOnlineInformation = new System.Windows.Forms.GroupBox();
            this.tbxEmail = new System.Windows.Forms.TextBox();
            this.lblEmail = new System.Windows.Forms.Label();
            this.tbxUsername = new System.Windows.Forms.TextBox();
            this.lblUsername = new System.Windows.Forms.Label();
            this.tbxPassword = new System.Windows.Forms.TextBox();
            this.lblPassword = new System.Windows.Forms.Label();
            this.lblConfirmPassword = new System.Windows.Forms.Label();
            this.tbxConfirmPassword = new System.Windows.Forms.TextBox();
            this.btnConfirm = new System.Windows.Forms.Button();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbxUserInformation.SuspendLayout();
            this.gbxOnlineInformation.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblPrompt
            // 
            this.lblPrompt.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblPrompt.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPrompt.Location = new System.Drawing.Point(11, 8);
            this.lblPrompt.Name = "lblPrompt";
            this.lblPrompt.Size = new System.Drawing.Size(398, 25);
            this.lblPrompt.TabIndex = 0;
            this.lblPrompt.Text = "Fill in the form below to get set up!";
            this.lblPrompt.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // gbxUserInformation
            // 
            this.gbxUserInformation.Controls.Add(this.tbxAddress);
            this.gbxUserInformation.Controls.Add(this.lblState);
            this.gbxUserInformation.Controls.Add(this.lblAddress);
            this.gbxUserInformation.Controls.Add(this.tbxState);
            this.gbxUserInformation.Controls.Add(this.lblCity);
            this.gbxUserInformation.Controls.Add(this.tbxCity);
            this.gbxUserInformation.Controls.Add(this.lblLastName);
            this.gbxUserInformation.Controls.Add(this.tbxLastName);
            this.gbxUserInformation.Controls.Add(this.lblFirstName);
            this.gbxUserInformation.Controls.Add(this.tbxFirstName);
            this.gbxUserInformation.Location = new System.Drawing.Point(32, 36);
            this.gbxUserInformation.Name = "gbxUserInformation";
            this.gbxUserInformation.Size = new System.Drawing.Size(355, 202);
            this.gbxUserInformation.TabIndex = 1;
            this.gbxUserInformation.TabStop = false;
            this.gbxUserInformation.Text = "User Information";
            // 
            // tbxAddress
            // 
            this.tbxAddress.Location = new System.Drawing.Point(96, 158);
            this.tbxAddress.MaxLength = 80;
            this.tbxAddress.Name = "tbxAddress";
            this.tbxAddress.Size = new System.Drawing.Size(243, 26);
            this.tbxAddress.TabIndex = 9;
            // 
            // lblState
            // 
            this.lblState.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblState.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblState.Location = new System.Drawing.Point(6, 124);
            this.lblState.Name = "lblState";
            this.lblState.Size = new System.Drawing.Size(84, 26);
            this.lblState.TabIndex = 6;
            this.lblState.Text = "State:";
            this.lblState.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblAddress
            // 
            this.lblAddress.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblAddress.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblAddress.Location = new System.Drawing.Point(6, 158);
            this.lblAddress.Name = "lblAddress";
            this.lblAddress.Size = new System.Drawing.Size(84, 26);
            this.lblAddress.TabIndex = 8;
            this.lblAddress.Text = "Address:";
            this.lblAddress.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxState
            // 
            this.tbxState.Location = new System.Drawing.Point(96, 124);
            this.tbxState.MaxLength = 2;
            this.tbxState.Name = "tbxState";
            this.tbxState.Size = new System.Drawing.Size(44, 26);
            this.tbxState.TabIndex = 7;
            this.tbxState.TextAlign = System.Windows.Forms.HorizontalAlignment.Center;
            // 
            // lblCity
            // 
            this.lblCity.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblCity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCity.Location = new System.Drawing.Point(6, 90);
            this.lblCity.Name = "lblCity";
            this.lblCity.Size = new System.Drawing.Size(84, 26);
            this.lblCity.TabIndex = 4;
            this.lblCity.Text = "City:";
            this.lblCity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCity
            // 
            this.tbxCity.Location = new System.Drawing.Point(96, 90);
            this.tbxCity.MaxLength = 50;
            this.tbxCity.Name = "tbxCity";
            this.tbxCity.Size = new System.Drawing.Size(243, 26);
            this.tbxCity.TabIndex = 5;
            // 
            // lblLastName
            // 
            this.lblLastName.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblLastName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblLastName.Location = new System.Drawing.Point(6, 56);
            this.lblLastName.Name = "lblLastName";
            this.lblLastName.Size = new System.Drawing.Size(84, 26);
            this.lblLastName.TabIndex = 2;
            this.lblLastName.Text = "Last Name:";
            this.lblLastName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxLastName
            // 
            this.tbxLastName.Location = new System.Drawing.Point(96, 56);
            this.tbxLastName.MaxLength = 40;
            this.tbxLastName.Name = "tbxLastName";
            this.tbxLastName.Size = new System.Drawing.Size(243, 26);
            this.tbxLastName.TabIndex = 3;
            // 
            // lblFirstName
            // 
            this.lblFirstName.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblFirstName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFirstName.Location = new System.Drawing.Point(6, 22);
            this.lblFirstName.Name = "lblFirstName";
            this.lblFirstName.Size = new System.Drawing.Size(84, 26);
            this.lblFirstName.TabIndex = 0;
            this.lblFirstName.Text = "First Name:";
            this.lblFirstName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxFirstName
            // 
            this.tbxFirstName.Location = new System.Drawing.Point(96, 22);
            this.tbxFirstName.MaxLength = 40;
            this.tbxFirstName.Name = "tbxFirstName";
            this.tbxFirstName.Size = new System.Drawing.Size(243, 26);
            this.tbxFirstName.TabIndex = 1;
            // 
            // gbxOnlineInformation
            // 
            this.gbxOnlineInformation.Controls.Add(this.tbxEmail);
            this.gbxOnlineInformation.Controls.Add(this.lblEmail);
            this.gbxOnlineInformation.Controls.Add(this.tbxUsername);
            this.gbxOnlineInformation.Controls.Add(this.lblUsername);
            this.gbxOnlineInformation.Controls.Add(this.tbxPassword);
            this.gbxOnlineInformation.Controls.Add(this.lblPassword);
            this.gbxOnlineInformation.Controls.Add(this.lblConfirmPassword);
            this.gbxOnlineInformation.Controls.Add(this.tbxConfirmPassword);
            this.gbxOnlineInformation.Location = new System.Drawing.Point(11, 244);
            this.gbxOnlineInformation.Name = "gbxOnlineInformation";
            this.gbxOnlineInformation.Size = new System.Drawing.Size(398, 162);
            this.gbxOnlineInformation.TabIndex = 2;
            this.gbxOnlineInformation.TabStop = false;
            this.gbxOnlineInformation.Text = "Online Information";
            // 
            // tbxEmail
            // 
            this.tbxEmail.Location = new System.Drawing.Point(146, 58);
            this.tbxEmail.MaxLength = 60;
            this.tbxEmail.Name = "tbxEmail";
            this.tbxEmail.Size = new System.Drawing.Size(243, 26);
            this.tbxEmail.TabIndex = 3;
            // 
            // lblEmail
            // 
            this.lblEmail.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblEmail.Location = new System.Drawing.Point(6, 57);
            this.lblEmail.Name = "lblEmail";
            this.lblEmail.Size = new System.Drawing.Size(134, 26);
            this.lblEmail.TabIndex = 2;
            this.lblEmail.Text = "Email:";
            this.lblEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxUsername
            // 
            this.tbxUsername.Location = new System.Drawing.Point(146, 26);
            this.tbxUsername.MaxLength = 60;
            this.tbxUsername.Name = "tbxUsername";
            this.tbxUsername.Size = new System.Drawing.Size(243, 26);
            this.tbxUsername.TabIndex = 1;
            // 
            // lblUsername
            // 
            this.lblUsername.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblUsername.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUsername.Location = new System.Drawing.Point(6, 25);
            this.lblUsername.Name = "lblUsername";
            this.lblUsername.Size = new System.Drawing.Size(134, 26);
            this.lblUsername.TabIndex = 0;
            this.lblUsername.Text = "Username:";
            this.lblUsername.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxPassword
            // 
            this.tbxPassword.Location = new System.Drawing.Point(146, 94);
            this.tbxPassword.MaxLength = 60;
            this.tbxPassword.Name = "tbxPassword";
            this.tbxPassword.Size = new System.Drawing.Size(243, 26);
            this.tbxPassword.TabIndex = 5;
            // 
            // lblPassword
            // 
            this.lblPassword.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblPassword.Location = new System.Drawing.Point(6, 93);
            this.lblPassword.Name = "lblPassword";
            this.lblPassword.Size = new System.Drawing.Size(134, 26);
            this.lblPassword.TabIndex = 4;
            this.lblPassword.Text = "Password:";
            this.lblPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblConfirmPassword
            // 
            this.lblConfirmPassword.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblConfirmPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblConfirmPassword.Location = new System.Drawing.Point(6, 127);
            this.lblConfirmPassword.Name = "lblConfirmPassword";
            this.lblConfirmPassword.Size = new System.Drawing.Size(134, 26);
            this.lblConfirmPassword.TabIndex = 6;
            this.lblConfirmPassword.Text = "Confirm Password:";
            this.lblConfirmPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxConfirmPassword
            // 
            this.tbxConfirmPassword.Location = new System.Drawing.Point(146, 127);
            this.tbxConfirmPassword.MaxLength = 60;
            this.tbxConfirmPassword.Name = "tbxConfirmPassword";
            this.tbxConfirmPassword.Size = new System.Drawing.Size(243, 26);
            this.tbxConfirmPassword.TabIndex = 7;
            // 
            // btnConfirm
            // 
            this.btnConfirm.Location = new System.Drawing.Point(124, 416);
            this.btnConfirm.Name = "btnConfirm";
            this.btnConfirm.Size = new System.Drawing.Size(75, 39);
            this.btnConfirm.TabIndex = 3;
            this.btnConfirm.Text = "&Confirm";
            this.btnConfirm.UseVisualStyleBackColor = true;
            this.btnConfirm.Click += new System.EventHandler(this.btnConfirm_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(219, 416);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 39);
            this.btnCancel.TabIndex = 4;
            this.btnCancel.Text = "Ca&ncel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // frmSignup
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(420, 463);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.btnConfirm);
            this.Controls.Add(this.gbxOnlineInformation);
            this.Controls.Add(this.gbxUserInformation);
            this.Controls.Add(this.lblPrompt);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmSignup";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Game and Merch Store | Sign Up!";
            this.gbxUserInformation.ResumeLayout(false);
            this.gbxUserInformation.PerformLayout();
            this.gbxOnlineInformation.ResumeLayout(false);
            this.gbxOnlineInformation.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Label lblPrompt;
        private System.Windows.Forms.GroupBox gbxUserInformation;
        private System.Windows.Forms.GroupBox gbxOnlineInformation;
        private System.Windows.Forms.Label lblFirstName;
        private System.Windows.Forms.Label lblLastName;
        private System.Windows.Forms.Label lblCity;
        private System.Windows.Forms.Label lblState;
        private System.Windows.Forms.Label lblAddress;
        private System.Windows.Forms.TextBox tbxFirstName;
        private System.Windows.Forms.TextBox tbxLastName;
        private System.Windows.Forms.TextBox tbxCity;
        private System.Windows.Forms.TextBox tbxState;
        private System.Windows.Forms.TextBox tbxAddress;
        private System.Windows.Forms.TextBox tbxUsername;
        private System.Windows.Forms.Label lblUsername;
        private System.Windows.Forms.TextBox tbxPassword;
        private System.Windows.Forms.Label lblPassword;
        private System.Windows.Forms.Label lblConfirmPassword;
        private System.Windows.Forms.TextBox tbxConfirmPassword;
        private System.Windows.Forms.TextBox tbxEmail;
        private System.Windows.Forms.Label lblEmail;
        private System.Windows.Forms.Button btnConfirm;
        private System.Windows.Forms.Button btnCancel;
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;
namespace SkeletonProjJesse
{
    class ProgOps
    {
        //Connection string
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2330fa21;User ID=group6fa212330;Password=6134295;";
        //Build a connection to database
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);
        //Add the command object
        private static SqlCommand _sqlDatabaseCommand;
        //Add the data adapter
        private static SqlDataAdapter _daDatabase = new SqlDataAdapter();
        //String for the USE statement
        const string BASE_QUERY = "USE inew2330fa21;";

        //DataTable Objects for all tables     
        private static DataTable _dtProductsTable = new DataTable();

        //Getters for the data tables
        public static DataTable DTProductsTable
        {
            get { return _dtProductsTable; }
        }

        //method to open database
        public static void OpenDatabase()
        {
            //open the connection to database if it already isn't
            if(_cntDatabase.State != ConnectionState.Open)
                _cntDatabase.Open();
            //message stating that connection to database was succesful
            //MessageBox.Show("Hello and welcome! Please log in if you're a returning user or sign up! You can also continue and browse as a guest!", "Gobblin' Ghouls and Ghosts! | Hello!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MessageBox.Show("Connection to database has been established!", "Database Connection Opened", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //method to close database and dispose of the connection object
        public static void CloseDisposeDatabase()
        {
            //close connection
            _cntDatabase.Close();
            //message stating that connection to database was succesful
            //MessageBox.Show("Come back soon!", "Prodigy's Products and Merch Store | Farewell!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MessageBox.Show("Database connection has been closed and disposed successfully!", "Database Connection Closed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //dispose of the connection object and command, adapter and table objects
            _cntDatabase.Dispose();

            //Check if the command is null because this may not have been initialized if the program is opened and closed
            if(_sqlDatabaseCommand != null)
                _sqlDatabaseCommand.Dispose();

            _daDatabase.Dispose();
            _dtProductsTable.Dispose();
        }

        public static void EstablishDatabase(string sqlStatement, DataTable resultsTable)
        {
            try
            {
                //Build SQL statement
                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + sqlStatement, _cntDatabase);
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                _daDatabase.Fill(resultsTable);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error in establishing the database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void DisposeDatabase()
        {
            //Dispose of the objects for reuse
            _sqlDatabaseCommand.Dispose();
            _daDatabase.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using CrystalDecisions.CrystalReports.Engine;

namespace SkeletonProjJesse
{
    public partial class frmCustomersTable : Form
    {
        //To flip through the records
        CurrencyManager manager;

        //To keep track of which record we were at last
        int lastLocation = 0;

        public frmCustomersTable()
        {
            InitializeComponent();
        }

        private void frmCustomersTable_Load(object sender, EventArgs e)
        {
            //By default, it will be in insert mode
            AppState("Insert");
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void mnuInsert_Click(object sender, EventArgs e)
        {
            //Call the AppState function and passing it what the user wants to do
            AppState("Insert");
        }

        private void mnuDelete_Click(object sender, EventArgs e)
        {
            //Display the database to the text boxes
            ProgOps.DisplayCustomersTable(tbxCustomerID, tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress);
            manager = (CurrencyManager)this.BindingContext[ProgOps.DTCustomersTable];

            //Call the AppState function and passing it what the user wants to do
            AppState("Delete");
        }

        private void mnuEdit_Click(object sender, EventArgs e)
        {
            List<string> columnNames = new List<string> { "CustomerID", "CustomerLastName", "CustomerFirstName", "CustomerCity", "CustomerState", "CustomerAddress" };
            List<TextBox> textBoxes = new List<TextBox> { tbxCustomerID, tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress };
            //Display the contents of the database to the text boxes
            //ProgOps.DisplayTable(columnNames, textBoxes, "Customers", ProgOps.DTCustomersTable);
            ProgOps.DisplayCustomersTable(tbxCustomerID, tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress);
            manager = (CurrencyManager)this.BindingContext[ProgOps.DTCustomersTable];
            //Call the AppState function and passing it what the user wants to do
            AppState("Edit");
        }

        private void mnuClearAll_Click(object sender, EventArgs e)
        {
            //Clear all text boxes
            tbxCustomerAddress.Text = "";
            tbxCustomerCity.Text = "";
            tbxCustomerFirstName.Text = "";
            tbxCustomerLastName.Text = "";
            tbxCustomerState.Text = "";
        }

        public void AppState(string state)
        {
            //No matter what mode it is now in, focus on the first text box
            //(CustomID is the first, but it is read only, so focus on FirstName)
            tbxCustomerFirstName.Focus();

            switch (state)
            {
                case "Insert": //Insert mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = true;
                        btnFirst.Enabled = false;
                        btnLast.Enabled = false;
                        btnPrevious.Enabled = false;
                        btnNext.Enabled = false;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Insert Into Customers";
                        mnuAction.Text = "&Save Record";
                        tbxCustomerID.Text = "";
                        tbxCustomerAddress.Text = "";
                        tbxCustomerCity.Text = "";
                        tbxCustomerFirstName.Text = "";
                        tbxCustomerLastName.Text = "";
                        tbxCustomerState.Text = "";

                        //Set the textBox properties
                        tbxCustomerID.Enabled = false;
                        tbxCustomerAddress.ReadOnly = false;
                        tbxCustomerCity.ReadOnly = false;
                        tbxCustomerFirstName.ReadOnly = false;
                        tbxCustomerLastName.ReadOnly = false;
                        tbxCustomerState.ReadOnly = false;
                        break;
                    }
                case "Delete": //Delete mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Delete From Customers";
                        mnuAction.Text = "&Delete Record";

                        //Set the textBox properties
                        tbxCustomerID.Enabled = true;
                        tbxCustomerAddress.ReadOnly = true;
                        tbxCustomerCity.ReadOnly = true;
                        tbxCustomerFirstName.ReadOnly = true;
                        tbxCustomerLastName.ReadOnly = true;
                        tbxCustomerState.ReadOnly = true;

                        break;
                    }
                case "Edit": //Edit mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Edit Customers";
                        mnuAction.Text = "&Edit Record";

                        //Set the textBox properties
                        tbxCustomerID.Enabled = true;
                        tbxCustomerAddress.ReadOnly = false;
                        tbxCustomerCity.ReadOnly = false;
                        tbxCustomerFirstName.ReadOnly = false;
                        tbxCustomerLastName.ReadOnly = false;
                        tbxCustomerState.ReadOnly = false;
                        break;
                    }
                default:
                    break;
            }
        }

        private void mnuAction_Click(object sender, EventArgs e)
        {
            //The action button changes text depending on what mode the user is in, so switch on the text
            //The text property still contains the accelerator key, so replace it with an empty string value
            switch (mnuAction.Text.Replace("&", ""))
            {
                case "Save Record":
                    {
                        //Check to see if all the text boxes have content, if they don't
                        if (tbxCustomerAddress.Text.Trim().Equals(String.Empty) || tbxCustomerCity.Text.Trim().Equals(String.Empty) || tbxCustomerFirstName.Text.Trim().Equals(String.Empty) || tbxCustomerLastName.Text.Trim().Equals(String.Empty) || tbxCustomerState.Text.Trim().Equals(String.Empty))
                        {
                            //Send error message
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            try
                            {
                                //Show confirmation before performing the insert
                                if (MessageBox.Show("Record will now be added, confirm?", "Insert Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    //ProgOps handles the actual insert, pass the textBoxes
                                    //ProgOps.InsertIntoCustomers(tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress);                                
                                    List<string> columnNames = new List<string> { "CustomerFirstName", "CustomerLastName", "CustomerCity", "CustomerState", "CustomerAddress" };
                                    List<string> columnValues = new List<string> { tbxCustomerFirstName.Text, tbxCustomerLastName.Text, tbxCustomerCity.Text, tbxCustomerState.Text, tbxCustomerAddress.Text };

                                    ProgOps.InsertIntoTable(columnNames, columnValues, "Customers");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "Error inserting record!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        break;
                    }
                case "Delete Record":
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            ProgOps.DeleteFromTable(int.Parse(tbxCustomerID.Text), "CustomerID", "Customers");
                            manager.RemoveAt(manager.Position);
                        }
                        break;
                    }
                case "Edit Record":
                    {
                        if (tbxCustomerAddress.Text.Trim().Equals(String.Empty) || tbxCustomerCity.Text.Trim().Equals(String.Empty) || tbxCustomerFirstName.Text.Trim().Equals(String.Empty) || tbxCustomerLastName.Text.Trim().Equals(String.Empty) || tbxCustomerState.Text.Trim().Equals(String.Empty))
                        {
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            if (MessageBox.Show("Record will now be update, confirm?", "Edit Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                List<string> columnNames = new List<string> { "CustomerLastName", "CustomerFirstName", "CustomerCity", "CustomerState", "CustomerAddress" };
                                List<string> columnValues = new List<string> { tbxCustomerLastName.Text, tbxCustomerFirstName.Text, tbxCustomerCity.Text, tbxCustomerState.Text, tbxCustomerAddress.Text };

                                ProgOps.UpdateTable(int.Parse(tbxCustomerID.Text), "CustomerID", columnNames, columnValues, "Customers");
                                                              
                                ProgOps.DisplayCustomersTable(tbxCustomerID, tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress);
                                manager = (CurrencyManager)this.BindingContext[ProgOps.DTCustomersTable];
                                manager.Position = lastLocation;
                            }
                        }
                        //manager.EndCurrentEdit();
                        break;
                    }
            }
        }

        #region Currencymanager Functions
        private void btnFirst_Click(object sender, EventArgs e)
        {
            manager.Position = 0;
            lastLocation = manager.Position;
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (manager.Position == 0)
            {
                SystemSounds.Beep.Play();
            }

            manager.Position--;
            lastLocation = manager.Position;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (manager.Position == manager.Count - 1)
            {
                SystemSounds.Beep.Play();
            }
            //MessageBox.Show(manager.Bindings[1].PropertyName.ToString());
            //MessageBox.Show(manager.Count.ToString());
            manager.Position++;
            lastLocation = manager.Position;

        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            manager.Position = manager.Count - 1;
            lastLocation = manager.Position;
        }
        #endregion

        private void mnuPrintData_Click(object sender, EventArgs e)
        {
            //This is used just for shorter code
            string path = Application.StartupPath;

            //Create an object of the frmViewer so we can use crvViewer (Set to public in form)
            frmViewer viewer = new frmViewer();

            //Create CrystalReport 
            ReportDocument customersReport = new ReportDocument();

            //Soft coding, to get exact file location
            //Removing the last nine characters from the string and appending the specific report in the folder
            customersReport.Load(path.Remove(path.Length - 9, 9) + @"Crystal Reports\crptCustomers.rpt");

            //Hardcode the login and password
            customersReport.SetDatabaseLogon("group6fa212330", "6134295");

            viewer.crvViewer.ReportSource = customersReport;

            //Show form with the crvViewer on it
            viewer.crvViewer.Refresh();

            viewer.Show();
        }
    }
}

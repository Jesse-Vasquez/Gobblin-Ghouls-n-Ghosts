﻿namespace VasquezJesse_ACS_Final
{
    partial class frmProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProducts));
            this.dgvOutput = new System.Windows.Forms.DataGridView();
            this.lblCart = new System.Windows.Forms.Label();
            this.lblTotalItems = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.lbxCart = new System.Windows.Forms.ListBox();
            this.btnRemove = new System.Windows.Forms.Button();
            this.gbxOrderSummary = new System.Windows.Forms.GroupBox();
            this.lblOutputTotalCost = new System.Windows.Forms.Label();
            this.lblOutputTotalItems = new System.Windows.Forms.Label();
            this.cbxPickup = new System.Windows.Forms.CheckBox();
            this.btnConfirmOrder = new System.Windows.Forms.Button();
            this.gbxFilter = new System.Windows.Forms.GroupBox();
            this.tbxQuantity = new System.Windows.Forms.TextBox();
            this.lblFilterItems = new System.Windows.Forms.Label();
            this.cbxFilterItems = new System.Windows.Forms.ComboBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutput)).BeginInit();
            this.gbxOrderSummary.SuspendLayout();
            this.gbxFilter.SuspendLayout();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // dgvOutput
            // 
            this.dgvOutput.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvOutput.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvOutput.BackgroundColor = System.Drawing.Color.Gray;
            this.dgvOutput.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgvOutput.Location = new System.Drawing.Point(12, 36);
            this.dgvOutput.Name = "dgvOutput";
            this.dgvOutput.RowTemplate.DefaultCellStyle.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvOutput.RowTemplate.ReadOnly = true;
            this.dgvOutput.Size = new System.Drawing.Size(1214, 553);
            this.dgvOutput.TabIndex = 1;
            this.dgvOutput.CellContentClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOutput_CellContentClick);
            this.dgvOutput.CellContentDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOutput_CellContentDoubleClick);
            this.dgvOutput.CellDoubleClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgvOutput_CellDoubleClick);
            // 
            // lblCart
            // 
            this.lblCart.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblCart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCart.Location = new System.Drawing.Point(12, 592);
            this.lblCart.Name = "lblCart";
            this.lblCart.Size = new System.Drawing.Size(72, 30);
            this.lblCart.TabIndex = 2;
            this.lblCart.Text = "Cart";
            this.lblCart.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblTotalItems
            // 
            this.lblTotalItems.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalItems.Location = new System.Drawing.Point(6, 37);
            this.lblTotalItems.Name = "lblTotalItems";
            this.lblTotalItems.Size = new System.Drawing.Size(97, 27);
            this.lblTotalItems.TabIndex = 0;
            this.lblTotalItems.Text = "Total Items";
            this.lblTotalItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalCost.Location = new System.Drawing.Point(6, 76);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(97, 27);
            this.lblTotalCost.TabIndex = 2;
            this.lblTotalCost.Text = "Total Cost";
            this.lblTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lbxCart
            // 
            this.lbxCart.BackColor = System.Drawing.Color.PaleGreen;
            this.lbxCart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbxCart.FormattingEnabled = true;
            this.lbxCart.ItemHeight = 19;
            this.lbxCart.Location = new System.Drawing.Point(12, 620);
            this.lbxCart.Name = "lbxCart";
            this.lbxCart.Size = new System.Drawing.Size(547, 173);
            this.lbxCart.TabIndex = 3;
            // 
            // btnRemove
            // 
            this.btnRemove.Location = new System.Drawing.Point(565, 746);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(82, 49);
            this.btnRemove.TabIndex = 4;
            this.btnRemove.Text = "&Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            this.btnRemove.Click += new System.EventHandler(this.btnRemove_Click);
            // 
            // gbxOrderSummary
            // 
            this.gbxOrderSummary.Controls.Add(this.lblOutputTotalCost);
            this.gbxOrderSummary.Controls.Add(this.lblOutputTotalItems);
            this.gbxOrderSummary.Controls.Add(this.cbxPickup);
            this.gbxOrderSummary.Controls.Add(this.btnConfirmOrder);
            this.gbxOrderSummary.Controls.Add(this.lblTotalItems);
            this.gbxOrderSummary.Controls.Add(this.lblTotalCost);
            this.gbxOrderSummary.Location = new System.Drawing.Point(982, 595);
            this.gbxOrderSummary.Name = "gbxOrderSummary";
            this.gbxOrderSummary.Size = new System.Drawing.Size(244, 200);
            this.gbxOrderSummary.TabIndex = 6;
            this.gbxOrderSummary.TabStop = false;
            this.gbxOrderSummary.Text = "Order Summary";
            // 
            // lblOutputTotalCost
            // 
            this.lblOutputTotalCost.BackColor = System.Drawing.Color.White;
            this.lblOutputTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutputTotalCost.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblOutputTotalCost.Location = new System.Drawing.Point(109, 76);
            this.lblOutputTotalCost.Name = "lblOutputTotalCost";
            this.lblOutputTotalCost.Size = new System.Drawing.Size(129, 27);
            this.lblOutputTotalCost.TabIndex = 3;
            this.lblOutputTotalCost.Text = "$0";
            this.lblOutputTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblOutputTotalItems
            // 
            this.lblOutputTotalItems.BackColor = System.Drawing.Color.White;
            this.lblOutputTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutputTotalItems.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblOutputTotalItems.Location = new System.Drawing.Point(109, 37);
            this.lblOutputTotalItems.Name = "lblOutputTotalItems";
            this.lblOutputTotalItems.Size = new System.Drawing.Size(51, 27);
            this.lblOutputTotalItems.TabIndex = 1;
            this.lblOutputTotalItems.Text = "0";
            this.lblOutputTotalItems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxPickup
            // 
            this.cbxPickup.AutoSize = true;
            this.cbxPickup.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.cbxPickup.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbxPickup.Location = new System.Drawing.Point(6, 115);
            this.cbxPickup.Name = "cbxPickup";
            this.cbxPickup.Size = new System.Drawing.Size(132, 23);
            this.cbxPickup.TabIndex = 4;
            this.cbxPickup.Text = "In-Store Pickup?";
            this.cbxPickup.UseVisualStyleBackColor = false;
            // 
            // btnConfirmOrder
            // 
            this.btnConfirmOrder.Location = new System.Drawing.Point(156, 145);
            this.btnConfirmOrder.Name = "btnConfirmOrder";
            this.btnConfirmOrder.Size = new System.Drawing.Size(82, 49);
            this.btnConfirmOrder.TabIndex = 5;
            this.btnConfirmOrder.Text = "&Confirm Order";
            this.btnConfirmOrder.UseVisualStyleBackColor = true;
            this.btnConfirmOrder.Click += new System.EventHandler(this.btnConfirmOrder_Click);
            // 
            // gbxFilter
            // 
            this.gbxFilter.Controls.Add(this.tbxQuantity);
            this.gbxFilter.Controls.Add(this.lblFilterItems);
            this.gbxFilter.Controls.Add(this.cbxFilterItems);
            this.gbxFilter.Controls.Add(this.lblQuantity);
            this.gbxFilter.Location = new System.Drawing.Point(706, 595);
            this.gbxFilter.Name = "gbxFilter";
            this.gbxFilter.Size = new System.Drawing.Size(244, 200);
            this.gbxFilter.TabIndex = 5;
            this.gbxFilter.TabStop = false;
            this.gbxFilter.Text = "Order Filtering and Settings";
            // 
            // tbxQuantity
            // 
            this.tbxQuantity.Location = new System.Drawing.Point(112, 37);
            this.tbxQuantity.Name = "tbxQuantity";
            this.tbxQuantity.Size = new System.Drawing.Size(76, 26);
            this.tbxQuantity.TabIndex = 1;
            this.tbxQuantity.Text = "1";
            // 
            // lblFilterItems
            // 
            this.lblFilterItems.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblFilterItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFilterItems.Location = new System.Drawing.Point(8, 69);
            this.lblFilterItems.Name = "lblFilterItems";
            this.lblFilterItems.Size = new System.Drawing.Size(96, 27);
            this.lblFilterItems.TabIndex = 2;
            this.lblFilterItems.Text = "Filter Items:";
            this.lblFilterItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // cbxFilterItems
            // 
            this.cbxFilterItems.FormattingEnabled = true;
            this.cbxFilterItems.Items.AddRange(new object[] {
            "All",
            "Video Games",
            "Consoles",
            "Trading Cards"});
            this.cbxFilterItems.Location = new System.Drawing.Point(112, 69);
            this.cbxFilterItems.MaxDropDownItems = 10;
            this.cbxFilterItems.Name = "cbxFilterItems";
            this.cbxFilterItems.Size = new System.Drawing.Size(104, 27);
            this.cbxFilterItems.TabIndex = 3;
            this.cbxFilterItems.Text = "Filter";
            this.cbxFilterItems.SelectedIndexChanged += new System.EventHandler(this.cbxFilterItems_SelectedIndexChanged);
            // 
            // lblQuantity
            // 
            this.lblQuantity.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblQuantity.Location = new System.Drawing.Point(8, 37);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(96, 27);
            this.lblQuantity.TabIndex = 0;
            this.lblQuantity.Text = "Quantity:";
            this.lblQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(1238, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "menuStrip1";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(56, 23);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // frmProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(1238, 806);
            this.Controls.Add(this.gbxFilter);
            this.Controls.Add(this.gbxOrderSummary);
            this.Controls.Add(this.btnRemove);
            this.Controls.Add(this.lbxCart);
            this.Controls.Add(this.lblCart);
            this.Controls.Add(this.dgvOutput);
            this.Controls.Add(this.mnuMain);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnuMain;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmProducts";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Game and Merch Store |";
            this.Load += new System.EventHandler(this.frmGames_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgvOutput)).EndInit();
            this.gbxOrderSummary.ResumeLayout(false);
            this.gbxOrderSummary.PerformLayout();
            this.gbxFilter.ResumeLayout(false);
            this.gbxFilter.PerformLayout();
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.DataGridView dgvOutput;
        private System.Windows.Forms.Label lblCart;
        private System.Windows.Forms.Label lblTotalItems;
        private System.Windows.Forms.Label lblTotalCost;
        private System.Windows.Forms.ListBox lbxCart;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.GroupBox gbxOrderSummary;
        private System.Windows.Forms.Button btnConfirmOrder;
        private System.Windows.Forms.CheckBox cbxPickup;
        private System.Windows.Forms.Label lblOutputTotalItems;
        private System.Windows.Forms.Label lblOutputTotalCost;
        private System.Windows.Forms.GroupBox gbxFilter;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.Label lblFilterItems;
        private System.Windows.Forms.ComboBox cbxFilterItems;
        private System.Windows.Forms.TextBox tbxQuantity;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
    }
}
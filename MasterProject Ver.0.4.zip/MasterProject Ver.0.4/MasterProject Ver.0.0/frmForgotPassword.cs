﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net;
using System.Configuration;
using System.Net.Mail;
namespace SkeletonProjJesse
{
    public partial class frmForgotPassword : Form
    {
        public frmForgotPassword()
        {
            InitializeComponent();
        }

        private void frmForgotPassword_Load(object sender, EventArgs e)
        {

        }

        private void btnClose_Click(object sender, EventArgs e)
        {
            //close the form
            this.Close();
        }

        private void btnConfirm_Click(object sender, EventArgs e)
        {
            if(tbxConfirmPassword.Text.Trim().Equals(String.Empty) || tbxNewPassword.Text.Trim().Equals(String.Empty) || tbxEmailAddress.Text.Trim().Equals(String.Empty))
            {
                MessageBox.Show("One or more field are empty!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (tbxNewPassword.Text.Trim() != tbxConfirmPassword.Text.Trim())
                    MessageBox.Show("Passwords do not match!", "Password Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                else
                {
                    try
                    {
                        //First, check to see if the email the user entered is in the database
                        if (ProgOps.IsEmailInDatabase(tbxEmailAddress.Text))
                            MessageBox.Show("Sorry, but the email " + tbxEmailAddress.Text + " is not in our records, please try again!", "Email not found!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        else
                        {
                            //If the function call is successful, close the form
                            if (ProgOps.ChangePassword(tbxEmailAddress.Text, tbxNewPassword.Text))
                            {
                                //Configuration manager uses keys from App.config
                                try
                                {
                                    //All ConfigurationManager stuff are set as keys in App.config
                                    using (MailMessage mail = new MailMessage(new MailAddress(ConfigurationManager.AppSettings["FromEmail"], ConfigurationManager.AppSettings["DisplayName"]), new MailAddress(tbxEmailAddress.Text)))
                                    {

                                        //Write the subject and body (The body is HTML because it's more customizable)
                                        mail.Subject = "Email verified!";
                                        mail.Body = "<p><strong>ROAR! Hope we didn't scare you, " + UserInfo.firstName + ",</strong></p>" +
                                                    "<p> But we just want to inform you that you have successfully changed your password to " + tbxNewPassword.Text + " </p>" +
                                                    "<p><strong> Have a Spooktacular day...</strong></p>" +
                                                    "<p><strong> Sincerely,</strong></p>" +
                                                    "<p><strong> &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; &nbsp; The Gobblin&apos; Ghouls and Ghosts Team&nbsp;</strong></p>";

                                        //Attachment that loads the company logo
                                        Attachment attachment;
                                        attachment = new Attachment(@"Logo.png");
                                        mail.Attachments.Add(attachment);

                                        //Set the variable for HTML body
                                        mail.IsBodyHtml = true;

                                        //Smtp client to set things for email
                                        SmtpClient client = new SmtpClient();

                                        client.Host = ConfigurationManager.AppSettings["Host"];
                                        client.EnableSsl = true;
                                        NetworkCredential credentials = new NetworkCredential(ConfigurationManager.AppSettings["FromEmail"], ConfigurationManager.AppSettings["Password"]);
                                        client.UseDefaultCredentials = true;
                                        client.Credentials = credentials;
                                        client.Port = int.Parse(ConfigurationManager.AppSettings["Port"]);
                                        client.Send(mail);

                                        //Show message box showing it went well
                                        MessageBox.Show("Thank you! Please check your email for confirmation!", "Gobblin Ghouls and Ghosts! | Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                        //Close the form after all that
                                        this.Close();

                                    }
                                }
                                catch (Exception ex)
                                {
                                    MessageBox.Show(ex.Message, "Error in confirming email!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                                }
                            }
                                
                        }
                    }
                    catch (Exception ex)
                    {
                        MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VasquezJesse_ACS_Final
{
    public partial class frmProducts : Form
    {
        //Form level declaration of the total cost
        decimal totalCost = 0;
        int totalItems = 0;

        //Parallel arrays for cart management
        List<decimal> itemCosts = new List<decimal>();
        List<string> itemNames = new List<string>();
        //decimal[] itemCosts;
        //string[] itemNames;
        public frmProducts()
        {
            InitializeComponent();
        }

        private void frmGames_Load(object sender, EventArgs e)
        {
            if (UserInfo.formEntering == "Games")
            {
                cbxFilterItems.Items.Clear();
                cbxFilterItems.Items.Add("All");
                cbxFilterItems.Items.Add("Video Games");
                cbxFilterItems.Items.Add("Consoles");
                cbxFilterItems.Items.Add("Trading Cards");
            }
            else if (UserInfo.formEntering == "Apparel")
            {
                cbxFilterItems.Items.Clear();
                cbxFilterItems.Items.Add("All");
                cbxFilterItems.Items.Add("Shirts");
                cbxFilterItems.Items.Add("Shoes");
                cbxFilterItems.Items.Add("Hoodies");
            }
            else if (UserInfo.formEntering == "Trinkets")
            {
                cbxFilterItems.Items.Clear();
                cbxFilterItems.Items.Add("All");
                cbxFilterItems.Items.Add("Funko POPs!");
                cbxFilterItems.Items.Add("Amiibos");
                cbxFilterItems.Items.Add("Posters");
            }
            else if (UserInfo.formEntering == "All")
            {
                cbxFilterItems.Items.Clear();
                cbxFilterItems.Items.Add("All");
                cbxFilterItems.Items.Add("Video Games");
                cbxFilterItems.Items.Add("Consoles");
                cbxFilterItems.Items.Add("Trading Cards");
                cbxFilterItems.Items.Add("Shirts");
                cbxFilterItems.Items.Add("Shoes");
                cbxFilterItems.Items.Add("Hoodies");
                cbxFilterItems.Items.Add("Funko POPs!");
                cbxFilterItems.Items.Add("Amiibos");
                cbxFilterItems.Items.Add("Posters");
            }

            dgvOutput.AutoSizeRowsMode = DataGridViewAutoSizeRowsMode.DisplayedCells;


            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();
            string sqlStatement = "";

            if (UserInfo.formEntering == "Games")
            {
                this.Text += " Gaming! | ";
                sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Video Game' OR ProductType = 'Console' OR ProductType = 'Trading Cards'";
            }
            else if (UserInfo.formEntering == "Apparel")
            {
                this.Text += " Apparel! | ";
                sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Shirt' OR ProductType = 'Shoes' OR ProductType = 'Hoodie'";
            }
            else if (UserInfo.formEntering == "Trinkets")
            {
                this.Text += " Trinkets! | ";
                sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Funko POP!' OR ProductType = 'Amiibo' OR ProductType = 'Poster'";
            }
            else if (UserInfo.formEntering == "All")
            {
                this.Text += " All Products! | ";
                sqlStatement = "SELECT * FROM Products";
            }
            this.Text += UserInfo.firstName + " " + UserInfo.lastName;

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvOutput.DataSource = resultsTable;

                dgvOutput.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();
        }

        private void dgvOutput_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }

        private void dgvOutput_CellContentDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            //MessageBox.Show(dgvOutput[e.ColumnIndex, e.RowIndex].OwningColumn.ToString());

            //if(dgvOutput[e.ColumnIndex, e.RowIndex].OwningColumn.ToString() == "ProductID" || dgvOutput[e.ColumnIndex, e.RowIndex].OwningColumn.ToString() == "ProductImage")
            //{
            //    MessageBox.Show("Cell clicked!");
            //}

            //if (e.ColumnIndex != -1 && e.RowIndex != -1)
            //{
            //    if (dgvOutput.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null)
            //    {
            //        MessageBox.Show(dgvOutput.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString());
            //    }
            //}
            //MessageBox.Show(dgvOutput.CurrentCell.OwningColumn.HeaderText);
        }

        private void dgvOutput_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {

                //Variable to hold the cost of the product's selected row
                //Purely for display purposes but is also functional
                //Decimal is used because it is the C# equivalent to money
                decimal cost = Convert.ToDecimal(dgvOutput.CurrentRow.Cells[dgvOutput.Columns[4].Index].Value);
                string item = dgvOutput.CurrentRow.Cells[dgvOutput.Columns[1].Index].Value.ToString();
                int quantity;

                if (e.ColumnIndex != -1 && e.RowIndex != -1)
                {
                    if (int.TryParse(tbxQuantity.Text.Trim(), out quantity) && quantity > 0)
                    {
                        if (dgvOutput.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null && dgvOutput[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductImage" || dgvOutput[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductID" || dgvOutput[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductName")
                        {
                            DialogResult dialogResult = MessageBox.Show("You have selected " + item +
                                "\nThe cost is " + cost.ToString("C2") +
                                "\nQuantity: " + quantity +
                                "\nAdjusted cost: " + (cost * quantity).ToString("C2") +
                                "\nAdd to cart?", "Product Selection", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                            if (dialogResult == DialogResult.Yes)
                            {
                                MessageBox.Show("Item(s) added to cart!\nRemove your order by selecting it in the list box and pressing the Remove button as you wish!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                for (int x = 0; x < quantity; x++)
                                {
                                    itemCosts.Add(cost);
                                    itemNames.Add(item);

                                    totalItems += 1;
                                    totalCost += cost;

                                    lbxCart.Items.Add(item + "\t" + cost.ToString("C2"));

                                }

                                lblOutputTotalItems.Text = totalItems.ToString();
                                lblOutputTotalCost.Text = totalCost.ToString("C2");


                            }
                            else
                            {
                                return;
                            }

                            //MessageBox.Show(dgvOutput.Rows[e.RowIndex].Cells[e.ColumnIndex].Value.ToString()); 
                            //MessageBox.Show(dgvOutput.CurrentCell.OwningRow.ToString());
                            //MessageBox.Show(dgvOutput.CurrentRow.Cells[0].Value.ToString());

                            //MessageBox.Show(dgvOutput.CurrentRow.Cells[dgvOutput.Columns[4].Index].Value.ToString());

                            //cost += Convert.ToDecimal(dgvOutput.CurrentRow.Cells[dgvOutput.Columns[4].Index].Value);
                            //MessageBox.Show(cost.ToString("c2"));
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter only a number that is greater than 0 into the Quantity box!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch(Exception ex)
            {
                MessageBox.Show("The cell you've selected is invalid!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            //MessageBox.Show(dgvOutput.CurrentCell.OwningColumn.HeaderText);
        }

        private void btnConfirmOrder_Click(object sender, EventArgs e)
        {
            if (!UserInfo.isLoggedIn)
            {
                DialogResult dialogResult = MessageBox.Show("So sorry, but only logged in users can place orders online.\nWould you like to create an account?", "Sign up?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    frmSignup frmSignup = new frmSignup();
                    frmSignup.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                if (totalCost == 0)
                {
                    MessageBox.Show("You must have at least one item in your cart to confirm your order.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Your order of " + totalItems.ToString() + " item(s) totalling " + totalCost.ToString("C2") + " will now be placed.\nConfirm?", "Confirm Purchase", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        if (cbxPickup.Checked)
                        {
                            string transactionType = "";
                            if (totalItems > 1)
                                transactionType = "Bulk Purchase";
                            else
                                transactionType = "Single Item Purchase";

                            ProgOps.RecordTransaction(transactionType, totalCost, "In-Store");
                            MessageBox.Show("You have within the next 48 hours to pick up your items.\nHave a nice day!", "Thank you for your purchase, " + UserInfo.firstName + "!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lbxCart.Items.Clear();
                            totalCost = 0;
                            totalItems = 0;
                            lblOutputTotalCost.Text = totalCost.ToString("C2");
                            lblOutputTotalItems.Text = totalItems.ToString();

                        }
                        else
                        {
                            string transactionType = "";
                            if (totalItems > 1)
                                transactionType = "Bulk Purchase";
                            else
                                transactionType = "Single Item Purchase";

                            ProgOps.RecordTransaction(transactionType, totalCost, "Delivery");
                            MessageBox.Show("The items will be delivered to you address " + UserInfo.address + " in " + UserInfo.city + ", " + UserInfo.state + " in 3 - 7 business days.\nHave a nice day!", "Thank you for your purchase, " + UserInfo.firstName + "!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lbxCart.Items.Clear();
                            totalCost = 0;
                            totalItems = 0;
                            lblOutputTotalCost.Text = totalCost.ToString("C2");
                            lblOutputTotalItems.Text = totalItems.ToString();
                        }
                    }
                }
            }
            //MessageBox.Show(totalCost.ToString("C2"));
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            int index = lbxCart.SelectedIndex;

            if (lbxCart.SelectedIndex != -1)
            {
                lbxCart.Items.RemoveAt(index);

                totalItems -= 1;
                totalCost -= itemCosts[index];

                lblOutputTotalItems.Text = totalItems.ToString();
                lblOutputTotalCost.Text = totalCost.ToString("C2");

                itemCosts.RemoveAt(index);
                itemNames.RemoveAt(index);
            }
            else
            {
                MessageBox.Show("You must select an item to remove before removing!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);

            }

        }

        private void cbxFilterItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sqlStatement = "";

            switch (cbxFilterItems.Items[cbxFilterItems.SelectedIndex].ToString())
            {
                case "All":
                    {
                        if(UserInfo.formEntering == "Games")
                            sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Video Game' OR ProductType = 'Console' OR ProductType = 'Trading Cards'";
                        else if(UserInfo.formEntering == "Apparel")
                            sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Shirt' OR ProductType = 'Shoes' OR ProductType = 'Hoodie'";
                        else if (UserInfo.formEntering == "Trinkets")
                            sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Funko POP!' OR ProductType = 'Amiibo' OR ProductType = 'Poster'";

                        break;
                    }
                case "Video Games":
                    {

                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Video Game'";

                        break;
                    }
                case "Consoles":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Console'";
                        break;
                    }
                case "Trading Cards":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Trading Cards'";
                        break;
                    }
                case "Shirts":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Shirt'";
                        break;
                    }
                case "Shoes":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Shoes'";
                        break;
                    }
                case "Hoodies":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Hoodie'";
                        break;
                    }
                case "Funko POPs!":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Funko POP!'";
                        break;
                    }
                case "Amiibos":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Amiibo'";
                        break;
                    }
                case "Posters":
                    {
                        sqlStatement = "SELECT * FROM Products WHERE ProductType = 'Poster'";
                        break;
                    }
            }

            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvOutput.DataSource = resultsTable;

                dgvOutput.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}

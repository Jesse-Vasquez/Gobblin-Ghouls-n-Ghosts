﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VasquezJesse_ACS_Final
{
    public partial class frmMain : Form
    {
        public frmMain()
        {
            InitializeComponent();
        }

        private void btnContinue_Click(object sender, EventArgs e)
        {
            if (tbxUsername.Text.Trim().Equals("") && tbxPassword.Text.Trim().Equals(""))
            {
                DialogResult dialogResult = MessageBox.Show("You entered nothing into the boxes, continue and browse as a guest?", "Browse as guest?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    MessageBox.Show("Welcome, " + UserInfo.firstName + "!", "Prodigy's Products | Welcome!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    frmNavigator frmNavigator = new frmNavigator();
                    frmNavigator.ShowDialog();
                }
                else
                {
                    return;
                }
            }
            else
            {
                if (ProgOps.CheckLogin(tbxUsername, tbxPassword))
                {
                    UserInfo.isLoggedIn = true;
                    MessageBox.Show("Welcome, " + UserInfo.firstName + "!", "Prodigy's Products | Welcome!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                    frmNavigator frmNavigator = new frmNavigator();
                    frmNavigator.ShowDialog();
                }
                else
                {
                    MessageBox.Show("Username or Password is incorrect!", "Incorrect PW or Username!", MessageBoxButtons.OK, MessageBoxIcon.Warning);
                }
            }
        }

        private void btnExit_Click(object sender, EventArgs e)
        {
            //Close the application
            Application.Exit();
        }

        private void frmMain_Load(object sender, EventArgs e)
        {
            //Open database and point to help file
            ProgOps.OpenDatabase();
            //Point to help file
            hlpMain.HelpNamespace = Application.StartupPath + "\\CSFinalHelp.chm";
        }

        private void tbxUsername_TextChanged(object sender, EventArgs e)
        {
            if(tbxUsername.Text.Trim().Equals("") && tbxPassword.Text.Trim().Equals(""))
            {
                btnContinue.Text = "&Continue";
            }
            else
            {
                btnContinue.Text = "&Login";
            }
        }

        private void frmMain_FormClosing(object sender, FormClosingEventArgs e)
        {
            ProgOps.CloseDisposeDatabase();
        }

        private void btnSignUp_Click(object sender, EventArgs e)
        {
            frmSignup frmSignup = new frmSignup();
            frmSignup.ShowDialog();
        }

        private void mnuHelp_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, hlpMain.HelpNamespace);
        }
    }
}

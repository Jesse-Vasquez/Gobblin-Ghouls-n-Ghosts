﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.IO;

namespace SkeletonProjJesse
{
    class ProgOps
    {
        //Connection string
        private const string CONNECT_STRING = @"Server=cstnt.tstc.edu;Database=inew2330fa21;User ID=group6fa212330;Password=6134295;";
        //Build a connection to database
        private static SqlConnection _cntDatabase = new SqlConnection(CONNECT_STRING);
        //Add the command object
        private static SqlCommand _sqlDatabaseCommand;
        //Add the data adapter
        private static SqlDataAdapter _daDatabase = new SqlDataAdapter();
        //String for the USE statement
        const string BASE_QUERY = "USE inew2330fa21;";

        //To read the database items
        private static SqlDataReader _drReader;

        //DataTable Objects for all tables     
        private static DataTable _dtProductsTable = new DataTable();

        //Getters for the data tables
        public static DataTable DTProductsTable
        {
            get { return _dtProductsTable; }
        }

        //method to open database
        public static void OpenDatabase()
        {
            //open the connection to database if it already isn't
            if(_cntDatabase.State != ConnectionState.Open)
                _cntDatabase.Open();
            //message stating that connection to database was succesful
            //MessageBox.Show("Hello and welcome! Please log in if you're a returning user or sign up! You can also continue and browse as a guest!", "Gobblin' Ghouls and Ghosts! | Hello!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MessageBox.Show("Connection to database has been established!", "Database Connection Opened", MessageBoxButtons.OK, MessageBoxIcon.Information);
        }

        //method to close database and dispose of the connection object
        public static void CloseDisposeDatabase()
        {
            //close connection
            _cntDatabase.Close();
            //message stating that connection to database was succesful
            //MessageBox.Show("Come back soon!", "Prodigy's Products and Merch Store | Farewell!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            MessageBox.Show("Database connection has been closed and disposed successfully!", "Database Connection Closed", MessageBoxButtons.OK, MessageBoxIcon.Information);
            //dispose of the connection object and command, adapter and table objects
            _cntDatabase.Dispose();

            //Check if the command is null because this may not have been initialized if the program is opened and closed
            if(_sqlDatabaseCommand != null)
                _sqlDatabaseCommand.Dispose();

            _daDatabase.Dispose();
            _dtProductsTable.Dispose();
        }

        public static void EstablishDatabase(string sqlStatement, DataTable resultsTable)
        {
            try
            {
                //Build SQL statement
                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + sqlStatement, _cntDatabase);
                _daDatabase.SelectCommand = _sqlDatabaseCommand;
                _daDatabase.Fill(resultsTable);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                MessageBox.Show(ex.Message, "Error in establishing the database", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static void CreateNewUser(TextBox tbxFirstName, TextBox tbxLastName, TextBox tbxCity, TextBox tbxState, TextBox tbxAddress, TextBox tbxUsername, TextBox tbxPassword, TextBox tbxEmail)
        {
            try
            {
                //open the connection to database if it already isn't
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                //Build SQL statement
                string sqlStatement = BASE_QUERY + "INSERT INTO Customers(CustomerLastName, CustomerFirstName, CustomerCity, CustomerState, CustomerAddress) VALUES(@LastName, @FirstName, @City, @State, @Address)";

                _sqlDatabaseCommand = new SqlCommand(sqlStatement, _cntDatabase);
                _sqlDatabaseCommand.Parameters.AddWithValue("@LastName", tbxLastName.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@FirstName", tbxFirstName.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@City", tbxCity.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@State", tbxState.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Address", tbxAddress.Text);
                _sqlDatabaseCommand.ExecuteNonQuery();

                string productID = String.Empty;

                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + "SELECT TOP(1)CustomerID FROM Customers ORDER BY CustomerID DESC", _cntDatabase);
                _drReader = _sqlDatabaseCommand.ExecuteReader();

                if (_drReader.Read())
                {
                    productID = _drReader.GetValue(0).ToString();
                }

                _drReader.Close();

                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + "INSERT INTO OnlineUsers(UserName, UserPassword, UserEmail, CustomerID) VALUES(@Username, @Password, @Email, @ID)", _cntDatabase);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Username", tbxUsername.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Password", tbxPassword.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@Email", tbxEmail.Text);
                _sqlDatabaseCommand.Parameters.AddWithValue("@ID", productID);
                _sqlDatabaseCommand.ExecuteNonQuery();

                MessageBox.Show("Account created. Thank you for signing up with us!", "Prodigy's Products Game and Merch Store | Thank you!", MessageBoxButtons.OK, MessageBoxIcon.Information);
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                if (_drReader != null)
                    _drReader.Close();
                MessageBox.Show(ex.Message, "Error in creating account!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        public static bool CheckLogin(TextBox tbxUsername, TextBox tbxPassword)
        {
            try
            {
                //makes sure the connection is established
                if (_cntDatabase.State != ConnectionState.Open)
                    _cntDatabase.Open();

                _sqlDatabaseCommand = new SqlCommand(BASE_QUERY + "IF (SELECT CustomerID FROM OnlineUsers WHERE UserScreenName = @Username) IS NULL " +
                    "SELECT * FROM OnlineUsers AS OU JOIN Staff AS S ON OU.StaffID = S.StaffID " +
                    "WHERE OU.UserScreenName = @Username " +
                    "ELSE " +
                    "SELECT * FROM OnlineUsers AS OU JOIN Customers AS C ON OU.CustomerID = C.CustomerID " +
                    "WHERE OU.UserScreenName = @Username", _cntDatabase);

                _sqlDatabaseCommand.Parameters.AddWithValue("@Username", tbxUsername.Text);

                _drReader = _sqlDatabaseCommand.ExecuteReader();

                string username = "", password = "";

                if (_drReader.Read())
                {
                    username = _drReader.GetValue(1).ToString();
                    password = _drReader.GetValue(2).ToString();

                    if (_drReader.GetName(7).ToString() == "StaffID")
                    {
                        UserInfo.StaffID = _drReader["StaffID"].ToString();
                        UserInfo.lastName = _drReader["StaffLastName"].ToString();
                        UserInfo.firstName = _drReader["StaffFirstName"].ToString();
                        UserInfo.hasAdminPermission = true;
                    }
                    else
                    {
                        UserInfo.ID = Convert.ToInt32(_drReader["CustomerID"]);
                        UserInfo.lastName = _drReader["CustomerLastName"].ToString();
                        UserInfo.firstName = _drReader["CustomerFirstName"].ToString();
                        UserInfo.city = _drReader["CustomerCity"].ToString();
                        UserInfo.state = _drReader["CustomerState"].ToString();
                        UserInfo.address = _drReader["CustomerAddress"].ToString();
                        UserInfo.hasAdminPermission = false;
                    }
                }

                _drReader.Close();

                if (tbxPassword.Text == password && tbxUsername.Text == username)
                    return true;
                else 
                    return false;
            }
            catch (Exception ex)
            {
                //Show error if something went wrong
                if (_drReader != null)
                    _drReader.Close();
                MessageBox.Show(ex.Message, "Error checking log in!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return false;
            }
        }
        
        public static void DisposeDatabase()
        {
            //Dispose of the objects for reuse
            _sqlDatabaseCommand.Dispose();
            _daDatabase.Dispose();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace VasquezJesse_ACS_Final
{
    public partial class frmNavigator : Form
    {
        public frmNavigator()
        {
            InitializeComponent();
        }

        private void frmNavigator_Load(object sender, EventArgs e)
        {
            //Point to help file
            hlpMain.HelpNamespace = Application.StartupPath + "\\CSFinalHelp.chm";

            if (UserInfo.isLoggedIn)
            {
                this.Text += " | " + UserInfo.firstName + " " + UserInfo.lastName;
                mnuClose.Text = "&Log Out";
            }
            else
            {
                this.Text += " | " + UserInfo.firstName;
                mnuClose.Text = "&Close";

            }

            if (!UserInfo.hasAdminPermission)
            {
                mnuAdmins.Enabled = false;
                mnuProducts.Enabled = true;
            }
            else
            {
                mnuAdmins.Enabled = true;
                mnuProducts.Enabled = false;
            }
        }

        private void mnuAdmins_Click(object sender, EventArgs e)
        {
            //MessageBox.Show("Only Administrators can access this!", "Admins only!", MessageBoxButtons.OK, MessageBoxIcon.Error);
        }

        private void mnuGames_Click(object sender, EventArgs e)
        {
            UserInfo.formEntering = "Games";
            frmProducts frmProducts = new frmProducts();
            frmProducts.ShowDialog();

        }

        private void mnuApparel_Click(object sender, EventArgs e)
        {
            UserInfo.formEntering = "Apparel";
            frmProducts frmProducts = new frmProducts();
            frmProducts.ShowDialog();
        }

        private void mnuTrinkets_Click(object sender, EventArgs e)
        {
            UserInfo.formEntering = "Trinkets";
            frmProducts frmProducts = new frmProducts();
            frmProducts.ShowDialog();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            DialogResult dialogResult;
            //Show message before closing
            if (UserInfo.isLoggedIn)
            {
                dialogResult = MessageBox.Show("Log out and close this form?", "Log Out?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            }
            else
            {
                dialogResult = MessageBox.Show("Close this form and return to log in screen?", "Close form?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
            }

            if (dialogResult == DialogResult.Yes)
            {
                //Close the form
                UserInfo.ClearData();
                this.Close();
            }
        }

        private void mnuCustomersTable_Click(object sender, EventArgs e)
        {
            frmInsertIntoCustomers frmInsertIntoCustomers = new frmInsertIntoCustomers();
            frmInsertIntoCustomers.ShowDialog();
        }

        private void mnuOnlineUsers_Click(object sender, EventArgs e)
        {
            frmInsertIntoOnlineUsers frmInsertIntoOnlineUsers = new frmInsertIntoOnlineUsers();
            frmInsertIntoOnlineUsers.ShowDialog();
        }

        private void mnuProductsTable_Click(object sender, EventArgs e)
        {
            frmInsertIntoProducts frmInsertIntoProducts = new frmInsertIntoProducts();
            frmInsertIntoProducts.ShowDialog();
        }

        private void mnuShipmentsTable_Click(object sender, EventArgs e)
        {
            frmInsertIntoShipments frmInsertIntoShipments = new frmInsertIntoShipments();
            frmInsertIntoShipments.ShowDialog();
        }

        private void mnuStaffTable_Click(object sender, EventArgs e)
        {
            frmInsertIntoStaff frmInsertIntoStaff = new frmInsertIntoStaff();
            frmInsertIntoStaff.ShowDialog();
        }

        private void mnuTransactionsTable_Click(object sender, EventArgs e)
        {
            frmInsertIntoTransactions frmInsertIntoTransactions = new frmInsertIntoTransactions();
            frmInsertIntoTransactions.ShowDialog();
        }

        private void mnuExit_Click(object sender, EventArgs e)
        {
            //Exit the application
            Application.Exit();
        }

        private void mnuHelp_Click(object sender, EventArgs e)
        {
            Help.ShowHelp(this, hlpMain.HelpNamespace);
        }

        private void mnuAbout_Click(object sender, EventArgs e)
        {
            frmAbout frmAbout = new frmAbout();
            frmAbout.Show();
        }

        private void mnuAllProducts_Click(object sender, EventArgs e)
        {
            UserInfo.formEntering = "All";
            frmProducts frmProducts = new frmProducts();
            frmProducts.ShowDialog();
        }
    }
}

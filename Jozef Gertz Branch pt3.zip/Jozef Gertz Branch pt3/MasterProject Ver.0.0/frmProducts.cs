﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace SkeletonProjJesse
{
    public partial class frmProducts : Form
    {
        //Form level declaration of the total cost
        decimal totalCost = 0;
        int totalItems = 0;

        //Parallel arrays for cart management
        List<decimal> itemCosts = new List<decimal>();
        List<string> itemNames = new List<string>();

        public frmProducts()
        {
            InitializeComponent();
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();
            string sqlStatement = "SELECT * FROM group6fa212330.Products";

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();

            this.Text += UserInfo.firstName + " " + UserInfo.lastName;

            //dgvProducts.Columns["ProductDescription"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;


        }
  

        private void btnCheckout_Click(object sender, EventArgs e)
        {
            if (!UserInfo.isLoggedIn)
            {
                DialogResult dialogResult = MessageBox.Show("So sorry, but only logged in users can place orders online.\nWould you like to create an account?", "Sign up?", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                if (dialogResult == DialogResult.Yes)
                {
                    frmSignup frmSignup = new frmSignup();
                    frmSignup.ShowDialog();
                    this.Close();
                }
            }
            else
            {
                if (totalCost == 0)
                {
                    MessageBox.Show("You must have at least one item in your cart to confirm your order.", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                }
                else
                {
                    DialogResult dialogResult = MessageBox.Show("Your order of " + totalItems.ToString() + " item(s) totalling " + totalCost.ToString("C2") + " will now be placed.\nConfirm?", "Confirm Purchase", MessageBoxButtons.YesNo, MessageBoxIcon.Question);
                    if (dialogResult == DialogResult.Yes)
                    {
                        if (cbxPickup.Checked)
                        {
                            string transactionType = "";
                            if (totalItems > 1)
                                transactionType = "Bulk Purchase";
                            else
                                transactionType = "Single Item Purchase";

                            ProgOps.RecordTransaction(transactionType, totalCost, "In-Store");
                            MessageBox.Show("You have within the next 3 hours to pick up your items.\nHave a nice day!", "Thank you for your purchase, " + UserInfo.firstName + "!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lbxCart.Items.Clear();
                            totalCost = 0;
                            totalItems = 0;
                            lblOutputTotalCost.Text = totalCost.ToString("C2");
                            lblOutputTotalItems.Text = totalItems.ToString();

                        }
                        else
                        {
                            string transactionType = "";
                            if (totalItems > 1)
                                transactionType = "Bulk Purchase";
                            else
                                transactionType = "Single Item Purchase";

                            ProgOps.RecordTransaction(transactionType, totalCost, "Delivery");
                            MessageBox.Show("Your order will be delivered to you address " + UserInfo.address + " in " + UserInfo.city + ", " + UserInfo.state + " in the next 60-90 minutes!.\nHave a nice day!", "Thank you for your purchase, " + UserInfo.firstName + "!", MessageBoxButtons.OK, MessageBoxIcon.Information);
                            lbxCart.Items.Clear();
                            totalCost = 0;
                            totalItems = 0;
                            lblOutputTotalCost.Text = totalCost.ToString("C2");
                            lblOutputTotalItems.Text = totalItems.ToString();
                        }
                    }
                }
            }
        }

        private void cbxFilterItems_SelectedIndexChanged(object sender, EventArgs e)
        {
            string sqlStatement = "";

            switch (cbxFilterItems.Items[cbxFilterItems.SelectedIndex].ToString())
            {
                case "All":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products";

                        break;
                    }
                case "Appetizers":
                    {

                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Appetizers'";

                        break;
                    }
                case "Entrees":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Entrees'";
                        break;
                    }
                case "Desserts":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Desserts'";
                        break;
                    }
                case "Kiddy":
                    {
                        sqlStatement = "SELECT * FROM group6fa212330.Products WHERE ProductType = 'Kiddy'";
                        break;
                    }
            }

            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();
        }

        private void dgvProducts_CellDoubleClick(object sender, DataGridViewCellEventArgs e)
        {
            try
            {
                //Variable to hold the cost of the product's selected row
                //Purely for display purposes but is also functional
                //Decimal is used because it is the C# equivalent to money
                decimal cost = Convert.ToDecimal(dgvProducts.CurrentRow.Cells[dgvProducts.Columns[4].Index].Value);
                string item = dgvProducts.CurrentRow.Cells[dgvProducts.Columns[1].Index].Value.ToString();
                int quantity;

                MessageBox.Show("TEST");
                if (e.ColumnIndex != -1 && e.RowIndex != -1)
                {
                    if (int.TryParse(tbxQuantity.Text.Trim(), out quantity) && quantity > 0)
                    {
                        if (dgvProducts.Rows[e.RowIndex].Cells[e.ColumnIndex].Value != null && dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductImage" || dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductID" || dgvProducts[e.ColumnIndex, e.RowIndex].OwningColumn.HeaderText.ToString() == "ProductName")
                        {
                            DialogResult dialogResult = MessageBox.Show("You have selected " + item +
                                "\nThe cost is " + cost.ToString("C2") +
                                "\nQuantity: " + quantity +
                                "\nAdjusted cost: " + (cost * quantity).ToString("C2") +
                                "\nAdd to cart?", "Product Selection", MessageBoxButtons.YesNo, MessageBoxIcon.Question);

                            if (dialogResult == DialogResult.Yes)
                            {
                                MessageBox.Show("Item(s) added to cart!\nRemove your order by selecting it in the list box and pressing the Remove button as you wish!", "Success!", MessageBoxButtons.OK, MessageBoxIcon.Information);

                                for (int x = 0; x < quantity; x++)
                                {
                                    itemCosts.Add(cost);
                                    itemNames.Add(item);

                                    totalItems += 1;
                                    totalCost += cost;

                                    lbxCart.Items.Add(item + "\t" + cost.ToString("C2"));

                                }

                                lblOutputTotalItems.Text = totalItems.ToString();
                                lblOutputTotalCost.Text = totalCost.ToString("C2");


                            }
                            else
                            {
                                return;
                            }
                        }
                    }
                    else
                    {
                        MessageBox.Show("Please enter only a number that is greater than 0 into the Quantity box!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("The cell you've selected is invalid!", "ERROR!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        private void btnRemove_Click(object sender, EventArgs e)
        {
            //Take the index where the user has selected and store it in a variable
            int index = lbxCart.SelectedIndex;

            //Make sure has selected an index
            if (lbxCart.SelectedIndex != -1)
            {
                //Remove from the list box
                lbxCart.Items.RemoveAt(index);

                //Update the two variables
                totalItems -= 1;
                totalCost -= itemCosts[index];

                //Update the labels
                lblOutputTotalItems.Text = totalItems.ToString();
                lblOutputTotalCost.Text = totalCost.ToString("C2");

                //Update the lists
                itemCosts.RemoveAt(index);
                itemNames.RemoveAt(index);
            }
            else
            {
                MessageBox.Show("You must select an item to remove before removing!", "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }
    }
}


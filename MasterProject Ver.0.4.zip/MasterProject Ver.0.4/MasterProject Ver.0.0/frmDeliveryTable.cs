﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using CrystalDecisions.CrystalReports.Engine;

namespace SkeletonProjJesse
{
    public partial class frmDeliveryTable : Form
    {
        //To flip through the records
        CurrencyManager manager;

        //To keep track of which record we were at last
        int lastLocation = 0;

        public frmDeliveryTable()
        {
            InitializeComponent();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void frmDeliveryTable_Load(object sender, EventArgs e)
        {
            //By default, it will be in insert mode
            AppState("Insert");
        }

        public void AppState(string state)
        {
            //No matter what mode it is now in, focus on the first text box
            //(DeliveryID is the first, but it is read only, so focus on ShippedDate)
            tbxDeliveryShippedDate.Focus();

            switch (state)
            {
                case "Insert": //Insert mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = true;
                        btnFirst.Enabled = false;
                        btnLast.Enabled = false;
                        btnPrevious.Enabled = false;
                        btnNext.Enabled = false;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Insert Into Customers";
                        mnuAction.Text = "&Save Record";
                        tbxDeliveryID.Text = "";
                        tbxDeliveryShippedDate.Text = "";
                        tbxDeliveryDeliveredDate.Text = "";
                        tbxTransactionID.Text = "";

                        //Set the textBox properties
                        tbxDeliveryID.Enabled = false;
                        tbxDeliveryShippedDate.ReadOnly = false;
                        tbxDeliveryDeliveredDate.ReadOnly = false;
                        tbxTransactionID.ReadOnly = false;
                        break;
                    }
                case "Delete": //Delete mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Delete From Customers";
                        mnuAction.Text = "&Delete Record";

                        //Set the textBox properties
                        tbxDeliveryID.Enabled = true;
                        tbxDeliveryShippedDate.ReadOnly = true;
                        tbxDeliveryDeliveredDate.ReadOnly = true;
                        tbxTransactionID.ReadOnly = true;
                        break;
                    }
                case "Edit": //Edit mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Edit Customers";
                        mnuAction.Text = "&Edit Record";

                        //Set the textBox properties
                        tbxDeliveryID.Enabled = true;
                        tbxDeliveryShippedDate.ReadOnly = false;
                        tbxDeliveryDeliveredDate.ReadOnly = false;
                        tbxTransactionID.ReadOnly = false;
                        break;
                    }
                default:
                    break;
            }
        }

        private void mnuInsert_Click(object sender, EventArgs e)
        {
            //Call the AppState function and passing it what the user wants to do
            AppState("Insert");
        }

        private void mnuDelete_Click(object sender, EventArgs e)
        {
            //Display the database to the text boxes
            ProgOps.DisplayDeliveriesTable(tbxDeliveryID, tbxDeliveryShippedDate, tbxDeliveryDeliveredDate, tbxTransactionID);
            manager = (CurrencyManager)this.BindingContext[ProgOps.DTDeliveriesTable];

            //Call the AppState function and passing it what the user wants to do
            AppState("Delete");
        }

        private void mnuEdit_Click(object sender, EventArgs e)
        {
            List<string> columnNames = new List<string> { "DeliveryID", "DeliveryShippedDate", "DeliveryDeliveredDate", "TransactionID" };
            List<TextBox> textBoxes = new List<TextBox> { tbxDeliveryID, tbxDeliveryShippedDate, tbxDeliveryDeliveredDate, tbxTransactionID };
            
            //Display the contents of the database to the text boxes
            ProgOps.DisplayDeliveriesTable(tbxDeliveryID, tbxDeliveryShippedDate, tbxDeliveryDeliveredDate, tbxTransactionID);
            manager = (CurrencyManager)this.BindingContext[ProgOps.DTDeliveriesTable];
            //Call the AppState function and passing it what the user wants to do
            AppState("Edit");
        }

        private void mnuClearAll_Click(object sender, EventArgs e)
        {
            //Clear all text boxes
            tbxDeliveryDeliveredDate.Text = "";
            tbxDeliveryShippedDate.Text = "";
            tbxTransactionID.Text = "";
        }

        private void mnuAction_Click(object sender, EventArgs e)
        {
            //The action button changes text depending on what mode the user is in, so switch on the text
            //The text property still contains the accelerator key, so replace it with an empty string value
            switch (mnuAction.Text.Replace("&", ""))
            {
                case "Save Record":
                    {
                        //Check to see if all the text boxes have content, if they don't
                        if (tbxDeliveryDeliveredDate.Text.Trim().Equals(String.Empty) || tbxDeliveryShippedDate.Text.Trim().Equals(String.Empty) || tbxTransactionID.Text.Trim().Equals(String.Empty))
                        {
                            //Send error message
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            try
                            {
                                //Show confirmation before performing the insert
                                if (MessageBox.Show("Record will now be added, confirm?", "Insert Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                                {
                                    //ProgOps handles the actual insert, pass the textBoxes
                                    //ProgOps.InsertIntoCustomers(tbxCustomerLastName, tbxCustomerFirstName, tbxCustomerCity, tbxCustomerState, tbxCustomerAddress);                                
                                    List<string> columnNames = new List<string> { "DeliveryShippedDate", "DeliveryDeliveredDate", "TransactionID" };
                                    List<string> columnValues = new List<string> { tbxDeliveryShippedDate.Text, tbxDeliveryDeliveredDate.Text, tbxTransactionID.Text };

                                    ProgOps.InsertIntoTable(columnNames, columnValues, "Deliveries");
                                }
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "Error inserting record!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        break;
                    }
                case "Delete Record":
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            ProgOps.DeleteFromTable(int.Parse(tbxDeliveryID.Text), "DeliveryID", "Deliveries");
                            manager.RemoveAt(manager.Position);
                        }
                        break;
                    }
                case "Edit Record":
                    {
                        if (tbxDeliveryDeliveredDate.Text.Trim().Equals(String.Empty) || tbxDeliveryShippedDate.Text.Trim().Equals(String.Empty) || tbxTransactionID.Text.Trim().Equals(String.Empty))
                        {
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            if (MessageBox.Show("Record will now be update, confirm?", "Edit Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {
                                List<string> columnNames = new List<string> { "DeliveryShippedDate", "DeliveryDeliveredDate", "TransactionID" };
                                List<string> columnValues = new List<string> { tbxDeliveryShippedDate.Text, tbxDeliveryDeliveredDate.Text, tbxTransactionID.Text };

                                ProgOps.UpdateTable(int.Parse(tbxDeliveryID.Text), "DeliveryID", columnNames, columnValues, "Deliveries");


                                ProgOps.DisplayDeliveriesTable(tbxDeliveryID, tbxDeliveryShippedDate, tbxDeliveryDeliveredDate, tbxTransactionID);
                                manager = (CurrencyManager)this.BindingContext[ProgOps.DTDeliveriesTable];
                                manager.Position = lastLocation;
                            }
                        }
                        //manager.EndCurrentEdit();
                        break;
                    }
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            manager.Position = 0;
            lastLocation = manager.Position;
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (manager.Position == 0)
            {
                SystemSounds.Beep.Play();
            }

            manager.Position--;
            lastLocation = manager.Position;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (manager.Position == manager.Count - 1)
            {
                SystemSounds.Beep.Play();
            }
            manager.Position++;
            lastLocation = manager.Position;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            manager.Position = manager.Count - 1;
            lastLocation = manager.Position;
        }

        private void mnuPrintData_Click(object sender, EventArgs e)
        {
            //This is used just for shorter code
            string path = Application.StartupPath;

            //Create an object of the frmViewer so we can use crvViewer (Set to public in form)
            frmViewer viewer = new frmViewer();

            //Create CrystalReport 
            ReportDocument customersReport = new ReportDocument();

            //Soft coding, to get exact file location
            //Removing the last nine characters from the string and appending the specific report in the folder
            customersReport.Load(path.Remove(path.Length - 9, 9) + @"Crystal Reports\crptDeliveries.rpt");

            viewer.crvViewer.ReportSource = customersReport;

            //Show form with the crvViewer on it
            viewer.crvViewer.Refresh();

            viewer.Show();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace SkeletonProjJesse
{
    public partial class frmCustomersTable : Form
    {
        public frmCustomersTable()
        {
            InitializeComponent();
        }

        private void frmCustomersTable_Load(object sender, EventArgs e)
        {

        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }
    }
}

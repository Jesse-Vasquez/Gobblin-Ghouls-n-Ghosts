﻿namespace SkeletonProjJesse
{
    partial class frmDeliveryTable
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmDeliveryTable));
            this.tbxTransactionID = new System.Windows.Forms.TextBox();
            this.lblTransactionID = new System.Windows.Forms.Label();
            this.tbxDeliveryDeliveredDate = new System.Windows.Forms.TextBox();
            this.tbxDeliveryShippedDate = new System.Windows.Forms.TextBox();
            this.tbxDeliveryID = new System.Windows.Forms.TextBox();
            this.lblDeliveryDeliveredDate = new System.Windows.Forms.Label();
            this.lblDeliveryShippedDate = new System.Windows.Forms.Label();
            this.lblDeliveryID = new System.Windows.Forms.Label();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuPrintData = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxTransactionID
            // 
            this.tbxTransactionID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxTransactionID.Location = new System.Drawing.Point(177, 134);
            this.tbxTransactionID.MaxLength = 300000;
            this.tbxTransactionID.Name = "tbxTransactionID";
            this.tbxTransactionID.Size = new System.Drawing.Size(156, 26);
            this.tbxTransactionID.TabIndex = 8;
            // 
            // lblTransactionID
            // 
            this.lblTransactionID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblTransactionID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTransactionID.Location = new System.Drawing.Point(12, 134);
            this.lblTransactionID.Name = "lblTransactionID";
            this.lblTransactionID.Size = new System.Drawing.Size(159, 26);
            this.lblTransactionID.TabIndex = 7;
            this.lblTransactionID.Text = "Transaction ID:";
            this.lblTransactionID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxDeliveryDeliveredDate
            // 
            this.tbxDeliveryDeliveredDate.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDeliveryDeliveredDate.Location = new System.Drawing.Point(177, 102);
            this.tbxDeliveryDeliveredDate.MaxLength = 500;
            this.tbxDeliveryDeliveredDate.Multiline = true;
            this.tbxDeliveryDeliveredDate.Name = "tbxDeliveryDeliveredDate";
            this.tbxDeliveryDeliveredDate.Size = new System.Drawing.Size(282, 26);
            this.tbxDeliveryDeliveredDate.TabIndex = 6;
            // 
            // tbxDeliveryShippedDate
            // 
            this.tbxDeliveryShippedDate.Font = new System.Drawing.Font("Times New Roman", 11.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxDeliveryShippedDate.Location = new System.Drawing.Point(177, 70);
            this.tbxDeliveryShippedDate.MaxLength = 500;
            this.tbxDeliveryShippedDate.Name = "tbxDeliveryShippedDate";
            this.tbxDeliveryShippedDate.Size = new System.Drawing.Size(282, 25);
            this.tbxDeliveryShippedDate.TabIndex = 4;
            // 
            // tbxDeliveryID
            // 
            this.tbxDeliveryID.BackColor = System.Drawing.Color.PaleGreen;
            this.tbxDeliveryID.Location = new System.Drawing.Point(177, 38);
            this.tbxDeliveryID.MaxLength = 300000;
            this.tbxDeliveryID.Name = "tbxDeliveryID";
            this.tbxDeliveryID.Size = new System.Drawing.Size(98, 26);
            this.tbxDeliveryID.TabIndex = 2;
            // 
            // lblDeliveryDeliveredDate
            // 
            this.lblDeliveryDeliveredDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblDeliveryDeliveredDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDeliveryDeliveredDate.Location = new System.Drawing.Point(12, 102);
            this.lblDeliveryDeliveredDate.Name = "lblDeliveryDeliveredDate";
            this.lblDeliveryDeliveredDate.Size = new System.Drawing.Size(159, 26);
            this.lblDeliveryDeliveredDate.TabIndex = 5;
            this.lblDeliveryDeliveredDate.Text = "Delivery Delivered Date:";
            this.lblDeliveryDeliveredDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDeliveryShippedDate
            // 
            this.lblDeliveryShippedDate.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblDeliveryShippedDate.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDeliveryShippedDate.Location = new System.Drawing.Point(12, 70);
            this.lblDeliveryShippedDate.Name = "lblDeliveryShippedDate";
            this.lblDeliveryShippedDate.Size = new System.Drawing.Size(159, 26);
            this.lblDeliveryShippedDate.TabIndex = 3;
            this.lblDeliveryShippedDate.Text = "Delivery Shipped Date:";
            this.lblDeliveryShippedDate.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblDeliveryID
            // 
            this.lblDeliveryID.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblDeliveryID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblDeliveryID.Location = new System.Drawing.Point(12, 38);
            this.lblDeliveryID.Name = "lblDeliveryID";
            this.lblDeliveryID.Size = new System.Drawing.Size(159, 26);
            this.lblDeliveryID.TabIndex = 1;
            this.lblDeliveryID.Text = "Delivery ID:";
            this.lblDeliveryID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(117, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(117, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(117, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(139, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose,
            this.mnuPrintData});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuPrintData
            // 
            this.mnuPrintData.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuPrintData.Name = "mnuPrintData";
            this.mnuPrintData.Size = new System.Drawing.Size(139, 24);
            this.mnuPrintData.Text = "&Print Data";
            this.mnuPrintData.Click += new System.EventHandler(this.mnuPrintData_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(326, 173);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 12;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(240, 173);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 11;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(68, 173);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 9;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(154, 173);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 10;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(470, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // frmDeliveryTable
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Center;
            this.ClientSize = new System.Drawing.Size(470, 220);
            this.Controls.Add(this.tbxTransactionID);
            this.Controls.Add(this.lblTransactionID);
            this.Controls.Add(this.tbxDeliveryDeliveredDate);
            this.Controls.Add(this.tbxDeliveryShippedDate);
            this.Controls.Add(this.tbxDeliveryID);
            this.Controls.Add(this.lblDeliveryDeliveredDate);
            this.Controls.Add(this.lblDeliveryShippedDate);
            this.Controls.Add(this.lblDeliveryID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.mnuMain);
            this.DoubleBuffered = true;
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmDeliveryTable";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts Admin | Delivery";
            this.Load += new System.EventHandler(this.frmDeliveryTable_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.TextBox tbxTransactionID;
        private System.Windows.Forms.Label lblTransactionID;
        private System.Windows.Forms.TextBox tbxDeliveryDeliveredDate;
        private System.Windows.Forms.TextBox tbxDeliveryShippedDate;
        private System.Windows.Forms.TextBox tbxDeliveryID;
        private System.Windows.Forms.Label lblDeliveryDeliveredDate;
        private System.Windows.Forms.Label lblDeliveryShippedDate;
        private System.Windows.Forms.Label lblDeliveryID;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuPrintData;
    }
}
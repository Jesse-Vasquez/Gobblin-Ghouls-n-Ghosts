﻿namespace VasquezJesse_ACS_Final
{
    partial class frmNavigator
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmNavigator));
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuExit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProducts = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuGames = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuApparel = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTrinkets = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAdmins = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCustomersTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOnlineUsers = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProductsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShipmentsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStaffTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTransactionsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProgramInformation = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuHelp = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.lblOperatedBy = new System.Windows.Forms.Label();
            this.lblInAssociationWith = new System.Windows.Forms.Label();
            this.lblSlogan = new System.Windows.Forms.Label();
            this.pbxGamesLogo = new System.Windows.Forms.PictureBox();
            this.pbxProdigysProducts = new System.Windows.Forms.PictureBox();
            this.hlpMain = new System.Windows.Forms.HelpProvider();
            this.mnuAllProducts = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGamesLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProdigysProducts)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuProducts,
            this.mnuAdmins,
            this.mnuProgramInformation});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(681, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose,
            this.mnuExit});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(180, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuExit
            // 
            this.mnuExit.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuExit.Name = "mnuExit";
            this.mnuExit.Size = new System.Drawing.Size(180, 24);
            this.mnuExit.Text = "E&xit";
            this.mnuExit.Click += new System.EventHandler(this.mnuExit_Click);
            // 
            // mnuProducts
            // 
            this.mnuProducts.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuProducts.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuGames,
            this.mnuApparel,
            this.mnuTrinkets,
            this.mnuAllProducts});
            this.mnuProducts.Name = "mnuProducts";
            this.mnuProducts.Size = new System.Drawing.Size(85, 23);
            this.mnuProducts.Text = "&Products!!";
            // 
            // mnuGames
            // 
            this.mnuGames.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuGames.Name = "mnuGames";
            this.mnuGames.Size = new System.Drawing.Size(180, 24);
            this.mnuGames.Text = "&Games";
            this.mnuGames.Click += new System.EventHandler(this.mnuGames_Click);
            // 
            // mnuApparel
            // 
            this.mnuApparel.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuApparel.Name = "mnuApparel";
            this.mnuApparel.Size = new System.Drawing.Size(180, 24);
            this.mnuApparel.Text = "&Apparel";
            this.mnuApparel.Click += new System.EventHandler(this.mnuApparel_Click);
            // 
            // mnuTrinkets
            // 
            this.mnuTrinkets.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuTrinkets.Name = "mnuTrinkets";
            this.mnuTrinkets.Size = new System.Drawing.Size(180, 24);
            this.mnuTrinkets.Text = "&Trinkets";
            this.mnuTrinkets.Click += new System.EventHandler(this.mnuTrinkets_Click);
            // 
            // mnuAdmins
            // 
            this.mnuAdmins.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuAdmins.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuCustomersTable,
            this.mnuOnlineUsers,
            this.mnuProductsTable,
            this.mnuShipmentsTable,
            this.mnuStaffTable,
            this.mnuTransactionsTable});
            this.mnuAdmins.Name = "mnuAdmins";
            this.mnuAdmins.Size = new System.Drawing.Size(67, 23);
            this.mnuAdmins.Text = "A&dmins";
            this.mnuAdmins.Click += new System.EventHandler(this.mnuAdmins_Click);
            // 
            // mnuCustomersTable
            // 
            this.mnuCustomersTable.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuCustomersTable.Name = "mnuCustomersTable";
            this.mnuCustomersTable.Size = new System.Drawing.Size(190, 24);
            this.mnuCustomersTable.Text = "&Customers Table";
            this.mnuCustomersTable.Click += new System.EventHandler(this.mnuCustomersTable_Click);
            // 
            // mnuOnlineUsers
            // 
            this.mnuOnlineUsers.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuOnlineUsers.Name = "mnuOnlineUsers";
            this.mnuOnlineUsers.Size = new System.Drawing.Size(190, 24);
            this.mnuOnlineUsers.Text = "&OnlineUsers Table";
            this.mnuOnlineUsers.Click += new System.EventHandler(this.mnuOnlineUsers_Click);
            // 
            // mnuProductsTable
            // 
            this.mnuProductsTable.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuProductsTable.Name = "mnuProductsTable";
            this.mnuProductsTable.Size = new System.Drawing.Size(190, 24);
            this.mnuProductsTable.Text = "&Products Table";
            this.mnuProductsTable.Click += new System.EventHandler(this.mnuProductsTable_Click);
            // 
            // mnuShipmentsTable
            // 
            this.mnuShipmentsTable.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuShipmentsTable.Name = "mnuShipmentsTable";
            this.mnuShipmentsTable.Size = new System.Drawing.Size(190, 24);
            this.mnuShipmentsTable.Text = "&Shipments Table";
            this.mnuShipmentsTable.Click += new System.EventHandler(this.mnuShipmentsTable_Click);
            // 
            // mnuStaffTable
            // 
            this.mnuStaffTable.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuStaffTable.Name = "mnuStaffTable";
            this.mnuStaffTable.Size = new System.Drawing.Size(190, 24);
            this.mnuStaffTable.Text = "S&taff Table";
            this.mnuStaffTable.Click += new System.EventHandler(this.mnuStaffTable_Click);
            // 
            // mnuTransactionsTable
            // 
            this.mnuTransactionsTable.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuTransactionsTable.Name = "mnuTransactionsTable";
            this.mnuTransactionsTable.Size = new System.Drawing.Size(190, 24);
            this.mnuTransactionsTable.Text = "&Transactions Table";
            this.mnuTransactionsTable.Click += new System.EventHandler(this.mnuTransactionsTable_Click);
            // 
            // mnuProgramInformation
            // 
            this.mnuProgramInformation.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuProgramInformation.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuHelp,
            this.mnuAbout});
            this.mnuProgramInformation.Name = "mnuProgramInformation";
            this.mnuProgramInformation.Size = new System.Drawing.Size(146, 23);
            this.mnuProgramInformation.Text = "P&rogram Information";
            // 
            // mnuHelp
            // 
            this.mnuHelp.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuHelp.Name = "mnuHelp";
            this.mnuHelp.Size = new System.Drawing.Size(180, 24);
            this.mnuHelp.Text = "&Help";
            this.mnuHelp.Click += new System.EventHandler(this.mnuHelp_Click);
            // 
            // mnuAbout
            // 
            this.mnuAbout.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(180, 24);
            this.mnuAbout.Text = "A&bout";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // lblOperatedBy
            // 
            this.lblOperatedBy.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblOperatedBy.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblOperatedBy.Location = new System.Drawing.Point(13, 82);
            this.lblOperatedBy.Name = "lblOperatedBy";
            this.lblOperatedBy.Size = new System.Drawing.Size(327, 29);
            this.lblOperatedBy.TabIndex = 1;
            this.lblOperatedBy.Text = "Operated By:";
            this.lblOperatedBy.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblInAssociationWith
            // 
            this.lblInAssociationWith.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblInAssociationWith.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblInAssociationWith.Location = new System.Drawing.Point(346, 82);
            this.lblInAssociationWith.Name = "lblInAssociationWith";
            this.lblInAssociationWith.Size = new System.Drawing.Size(323, 29);
            this.lblInAssociationWith.TabIndex = 2;
            this.lblInAssociationWith.Text = "In Association With:";
            this.lblInAssociationWith.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // lblSlogan
            // 
            this.lblSlogan.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblSlogan.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSlogan.Location = new System.Drawing.Point(168, 310);
            this.lblSlogan.Name = "lblSlogan";
            this.lblSlogan.Size = new System.Drawing.Size(346, 29);
            this.lblSlogan.TabIndex = 3;
            this.lblSlogan.Text = "\"Slogan\"";
            this.lblSlogan.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            // 
            // pbxGamesLogo
            // 
            this.pbxGamesLogo.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxGamesLogo.Image = global::VasquezJesse_ACS_Final.Properties.Resources.CompanyLogo;
            this.pbxGamesLogo.Location = new System.Drawing.Point(346, 114);
            this.pbxGamesLogo.Name = "pbxGamesLogo";
            this.pbxGamesLogo.Size = new System.Drawing.Size(323, 190);
            this.pbxGamesLogo.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxGamesLogo.TabIndex = 2;
            this.pbxGamesLogo.TabStop = false;
            // 
            // pbxProdigysProducts
            // 
            this.pbxProdigysProducts.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.pbxProdigysProducts.Image = global::VasquezJesse_ACS_Final.Properties.Resources.FinalStoreLogo;
            this.pbxProdigysProducts.Location = new System.Drawing.Point(13, 114);
            this.pbxProdigysProducts.Name = "pbxProdigysProducts";
            this.pbxProdigysProducts.Size = new System.Drawing.Size(327, 190);
            this.pbxProdigysProducts.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbxProdigysProducts.TabIndex = 1;
            this.pbxProdigysProducts.TabStop = false;
            // 
            // mnuAllProducts
            // 
            this.mnuAllProducts.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuAllProducts.Name = "mnuAllProducts";
            this.mnuAllProducts.Size = new System.Drawing.Size(180, 24);
            this.mnuAllProducts.Text = "&All Products";
            this.mnuAllProducts.Click += new System.EventHandler(this.mnuAllProducts_Click);
            // 
            // frmNavigator
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(681, 348);
            this.Controls.Add(this.lblSlogan);
            this.Controls.Add(this.lblInAssociationWith);
            this.Controls.Add(this.lblOperatedBy);
            this.Controls.Add(this.pbxGamesLogo);
            this.Controls.Add(this.pbxProdigysProducts);
            this.Controls.Add(this.mnuMain);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MainMenuStrip = this.mnuMain;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmNavigator";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Game and Merch Store | Online Menu!";
            this.Load += new System.EventHandler(this.frmNavigator_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxGamesLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxProdigysProducts)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuProducts;
        private System.Windows.Forms.ToolStripMenuItem mnuGames;
        private System.Windows.Forms.ToolStripMenuItem mnuApparel;
        private System.Windows.Forms.ToolStripMenuItem mnuTrinkets;
        private System.Windows.Forms.ToolStripMenuItem mnuAdmins;
        private System.Windows.Forms.ToolStripMenuItem mnuProgramInformation;
        private System.Windows.Forms.ToolStripMenuItem mnuHelp;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
        private System.Windows.Forms.PictureBox pbxProdigysProducts;
        private System.Windows.Forms.PictureBox pbxGamesLogo;
        private System.Windows.Forms.Label lblOperatedBy;
        private System.Windows.Forms.Label lblInAssociationWith;
        private System.Windows.Forms.Label lblSlogan;
        private System.Windows.Forms.ToolStripMenuItem mnuExit;
        private System.Windows.Forms.ToolStripMenuItem mnuCustomersTable;
        private System.Windows.Forms.ToolStripMenuItem mnuOnlineUsers;
        private System.Windows.Forms.ToolStripMenuItem mnuProductsTable;
        private System.Windows.Forms.ToolStripMenuItem mnuShipmentsTable;
        private System.Windows.Forms.ToolStripMenuItem mnuStaffTable;
        private System.Windows.Forms.ToolStripMenuItem mnuTransactionsTable;
        private System.Windows.Forms.HelpProvider hlpMain;
        private System.Windows.Forms.ToolStripMenuItem mnuAllProducts;
    }
}
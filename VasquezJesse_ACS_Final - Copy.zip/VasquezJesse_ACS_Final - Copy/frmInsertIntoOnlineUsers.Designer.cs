﻿namespace VasquezJesse_ACS_Final
{
    partial class frmInsertIntoOnlineUsers
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmInsertIntoOnlineUsers));
            this.tbxUserScreenName = new System.Windows.Forms.TextBox();
            this.lblUserScreenName = new System.Windows.Forms.Label();
            this.lblUserPassword = new System.Windows.Forms.Label();
            this.tbxUserPassword = new System.Windows.Forms.TextBox();
            this.lblUserEmail = new System.Windows.Forms.Label();
            this.tbxUserEmail = new System.Windows.Forms.TextBox();
            this.lblStaffID = new System.Windows.Forms.Label();
            this.tbxStaffID = new System.Windows.Forms.TextBox();
            this.lblCustomerID = new System.Windows.Forms.Label();
            this.tbxCustomerID = new System.Windows.Forms.TextBox();
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuToggleMode = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuInsert = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDelete = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuEdit = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClearAll = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAction = new System.Windows.Forms.ToolStripMenuItem();
            this.btnLast = new System.Windows.Forms.Button();
            this.btnNext = new System.Windows.Forms.Button();
            this.btnPrevious = new System.Windows.Forms.Button();
            this.btnFirst = new System.Windows.Forms.Button();
            this.tbxUserID = new System.Windows.Forms.TextBox();
            this.lblUserID = new System.Windows.Forms.Label();
            this.lblIDDisclaimer = new System.Windows.Forms.Label();
            this.mnuMain.SuspendLayout();
            this.SuspendLayout();
            // 
            // tbxUserScreenName
            // 
            this.tbxUserScreenName.Location = new System.Drawing.Point(147, 71);
            this.tbxUserScreenName.MaxLength = 60;
            this.tbxUserScreenName.Name = "tbxUserScreenName";
            this.tbxUserScreenName.Size = new System.Drawing.Size(282, 26);
            this.tbxUserScreenName.TabIndex = 4;
            // 
            // lblUserScreenName
            // 
            this.lblUserScreenName.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblUserScreenName.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUserScreenName.Location = new System.Drawing.Point(9, 71);
            this.lblUserScreenName.Name = "lblUserScreenName";
            this.lblUserScreenName.Size = new System.Drawing.Size(132, 26);
            this.lblUserScreenName.TabIndex = 3;
            this.lblUserScreenName.Text = "User Screen Name:";
            this.lblUserScreenName.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblUserPassword
            // 
            this.lblUserPassword.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblUserPassword.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUserPassword.Location = new System.Drawing.Point(9, 107);
            this.lblUserPassword.Name = "lblUserPassword";
            this.lblUserPassword.Size = new System.Drawing.Size(132, 26);
            this.lblUserPassword.TabIndex = 5;
            this.lblUserPassword.Text = "User Password:";
            this.lblUserPassword.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxUserPassword
            // 
            this.tbxUserPassword.Location = new System.Drawing.Point(147, 107);
            this.tbxUserPassword.MaxLength = 60;
            this.tbxUserPassword.Name = "tbxUserPassword";
            this.tbxUserPassword.Size = new System.Drawing.Size(282, 26);
            this.tbxUserPassword.TabIndex = 6;
            // 
            // lblUserEmail
            // 
            this.lblUserEmail.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblUserEmail.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUserEmail.Location = new System.Drawing.Point(9, 143);
            this.lblUserEmail.Name = "lblUserEmail";
            this.lblUserEmail.Size = new System.Drawing.Size(132, 26);
            this.lblUserEmail.TabIndex = 7;
            this.lblUserEmail.Text = "User Email:";
            this.lblUserEmail.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxUserEmail
            // 
            this.tbxUserEmail.Location = new System.Drawing.Point(147, 143);
            this.tbxUserEmail.MaxLength = 60;
            this.tbxUserEmail.Name = "tbxUserEmail";
            this.tbxUserEmail.Size = new System.Drawing.Size(282, 26);
            this.tbxUserEmail.TabIndex = 8;
            // 
            // lblStaffID
            // 
            this.lblStaffID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblStaffID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblStaffID.Location = new System.Drawing.Point(9, 179);
            this.lblStaffID.Name = "lblStaffID";
            this.lblStaffID.Size = new System.Drawing.Size(132, 26);
            this.lblStaffID.TabIndex = 9;
            this.lblStaffID.Text = "Staff ID:";
            this.lblStaffID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxStaffID
            // 
            this.tbxStaffID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxStaffID.Location = new System.Drawing.Point(147, 179);
            this.tbxStaffID.MaxLength = 5;
            this.tbxStaffID.Name = "tbxStaffID";
            this.tbxStaffID.Size = new System.Drawing.Size(73, 26);
            this.tbxStaffID.TabIndex = 10;
            // 
            // lblCustomerID
            // 
            this.lblCustomerID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblCustomerID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCustomerID.Location = new System.Drawing.Point(9, 215);
            this.lblCustomerID.Name = "lblCustomerID";
            this.lblCustomerID.Size = new System.Drawing.Size(132, 26);
            this.lblCustomerID.TabIndex = 11;
            this.lblCustomerID.Text = "Customer ID:";
            this.lblCustomerID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // tbxCustomerID
            // 
            this.tbxCustomerID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxCustomerID.Location = new System.Drawing.Point(147, 215);
            this.tbxCustomerID.Name = "tbxCustomerID";
            this.tbxCustomerID.Size = new System.Drawing.Size(73, 26);
            this.tbxCustomerID.TabIndex = 12;
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuToggleMode,
            this.mnuClearAll,
            this.mnuAction});
            this.mnuMain.LayoutStyle = System.Windows.Forms.ToolStripLayoutStyle.HorizontalStackWithOverflow;
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(438, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "mnuMain";
            // 
            // mnuFile
            // 
            this.mnuFile.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "&File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(180, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuToggleMode
            // 
            this.mnuToggleMode.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuToggleMode.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuInsert,
            this.mnuDelete,
            this.mnuEdit});
            this.mnuToggleMode.Name = "mnuToggleMode";
            this.mnuToggleMode.Size = new System.Drawing.Size(102, 23);
            this.mnuToggleMode.Text = "&Toggle Mode";
            // 
            // mnuInsert
            // 
            this.mnuInsert.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuInsert.Name = "mnuInsert";
            this.mnuInsert.Size = new System.Drawing.Size(180, 24);
            this.mnuInsert.Text = "&Insert";
            this.mnuInsert.Click += new System.EventHandler(this.mnuInsert_Click);
            // 
            // mnuDelete
            // 
            this.mnuDelete.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuDelete.Name = "mnuDelete";
            this.mnuDelete.Size = new System.Drawing.Size(180, 24);
            this.mnuDelete.Text = "&Delete";
            this.mnuDelete.Click += new System.EventHandler(this.mnuDelete_Click);
            // 
            // mnuEdit
            // 
            this.mnuEdit.BackColor = System.Drawing.Color.PaleGreen;
            this.mnuEdit.Name = "mnuEdit";
            this.mnuEdit.Size = new System.Drawing.Size(180, 24);
            this.mnuEdit.Text = "&Edit";
            this.mnuEdit.Click += new System.EventHandler(this.mnuEdit_Click);
            // 
            // mnuClearAll
            // 
            this.mnuClearAll.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuClearAll.Name = "mnuClearAll";
            this.mnuClearAll.Size = new System.Drawing.Size(74, 23);
            this.mnuClearAll.Text = "&Clear All";
            this.mnuClearAll.Click += new System.EventHandler(this.mnuClearAll_Click);
            // 
            // mnuAction
            // 
            this.mnuAction.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.mnuAction.Name = "mnuAction";
            this.mnuAction.Size = new System.Drawing.Size(100, 23);
            this.mnuAction.Text = "&Save Record";
            this.mnuAction.Click += new System.EventHandler(this.mnuAction_Click);
            // 
            // btnLast
            // 
            this.btnLast.Location = new System.Drawing.Point(310, 250);
            this.btnLast.Name = "btnLast";
            this.btnLast.Size = new System.Drawing.Size(77, 38);
            this.btnLast.TabIndex = 17;
            this.btnLast.Text = ">|";
            this.btnLast.UseVisualStyleBackColor = true;
            this.btnLast.Click += new System.EventHandler(this.btnLast_Click);
            // 
            // btnNext
            // 
            this.btnNext.Location = new System.Drawing.Point(224, 250);
            this.btnNext.Name = "btnNext";
            this.btnNext.Size = new System.Drawing.Size(77, 38);
            this.btnNext.TabIndex = 16;
            this.btnNext.Text = ">";
            this.btnNext.UseVisualStyleBackColor = true;
            this.btnNext.Click += new System.EventHandler(this.btnNext_Click);
            // 
            // btnPrevious
            // 
            this.btnPrevious.Location = new System.Drawing.Point(138, 250);
            this.btnPrevious.Name = "btnPrevious";
            this.btnPrevious.Size = new System.Drawing.Size(77, 38);
            this.btnPrevious.TabIndex = 15;
            this.btnPrevious.Text = "<";
            this.btnPrevious.UseVisualStyleBackColor = true;
            this.btnPrevious.Click += new System.EventHandler(this.btnPrevious_Click);
            // 
            // btnFirst
            // 
            this.btnFirst.Location = new System.Drawing.Point(52, 250);
            this.btnFirst.Name = "btnFirst";
            this.btnFirst.Size = new System.Drawing.Size(77, 38);
            this.btnFirst.TabIndex = 14;
            this.btnFirst.Text = "|<";
            this.btnFirst.UseVisualStyleBackColor = true;
            this.btnFirst.Click += new System.EventHandler(this.btnFirst_Click);
            // 
            // tbxUserID
            // 
            this.tbxUserID.BackColor = System.Drawing.Color.LightYellow;
            this.tbxUserID.Location = new System.Drawing.Point(147, 35);
            this.tbxUserID.Name = "tbxUserID";
            this.tbxUserID.ReadOnly = true;
            this.tbxUserID.Size = new System.Drawing.Size(73, 26);
            this.tbxUserID.TabIndex = 2;
            // 
            // lblUserID
            // 
            this.lblUserID.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblUserID.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblUserID.Location = new System.Drawing.Point(9, 35);
            this.lblUserID.Name = "lblUserID";
            this.lblUserID.Size = new System.Drawing.Size(132, 26);
            this.lblUserID.TabIndex = 1;
            this.lblUserID.Text = "User ID:";
            this.lblUserID.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblIDDisclaimer
            // 
            this.lblIDDisclaimer.BackColor = System.Drawing.Color.MediumSeaGreen;
            this.lblIDDisclaimer.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblIDDisclaimer.Location = new System.Drawing.Point(226, 179);
            this.lblIDDisclaimer.Name = "lblIDDisclaimer";
            this.lblIDDisclaimer.Size = new System.Drawing.Size(161, 62);
            this.lblIDDisclaimer.TabIndex = 13;
            this.lblIDDisclaimer.Text = "Staff and Customer ID\'s must exist in database prior to insertion here!";
            // 
            // frmInsertIntoOnlineUsers
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(438, 296);
            this.Controls.Add(this.lblIDDisclaimer);
            this.Controls.Add(this.tbxUserID);
            this.Controls.Add(this.lblUserID);
            this.Controls.Add(this.btnLast);
            this.Controls.Add(this.btnNext);
            this.Controls.Add(this.btnPrevious);
            this.Controls.Add(this.btnFirst);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.lblCustomerID);
            this.Controls.Add(this.tbxCustomerID);
            this.Controls.Add(this.lblStaffID);
            this.Controls.Add(this.tbxStaffID);
            this.Controls.Add(this.lblUserEmail);
            this.Controls.Add(this.tbxUserEmail);
            this.Controls.Add(this.lblUserPassword);
            this.Controls.Add(this.tbxUserPassword);
            this.Controls.Add(this.lblUserScreenName);
            this.Controls.Add(this.tbxUserScreenName);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmInsertIntoOnlineUsers";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Prodigy\'s Products Admin | Insert Into Online Users";
            this.Load += new System.EventHandler(this.frmInsertIntoOnlineUsers_Load);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.TextBox tbxUserScreenName;
        private System.Windows.Forms.Label lblUserScreenName;
        private System.Windows.Forms.Label lblUserPassword;
        private System.Windows.Forms.TextBox tbxUserPassword;
        private System.Windows.Forms.Label lblUserEmail;
        private System.Windows.Forms.TextBox tbxUserEmail;
        private System.Windows.Forms.Label lblStaffID;
        private System.Windows.Forms.TextBox tbxStaffID;
        private System.Windows.Forms.Label lblCustomerID;
        private System.Windows.Forms.TextBox tbxCustomerID;
        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuToggleMode;
        private System.Windows.Forms.ToolStripMenuItem mnuInsert;
        private System.Windows.Forms.ToolStripMenuItem mnuDelete;
        private System.Windows.Forms.ToolStripMenuItem mnuEdit;
        private System.Windows.Forms.ToolStripMenuItem mnuClearAll;
        private System.Windows.Forms.ToolStripMenuItem mnuAction;
        private System.Windows.Forms.Button btnLast;
        private System.Windows.Forms.Button btnNext;
        private System.Windows.Forms.Button btnPrevious;
        private System.Windows.Forms.Button btnFirst;
        private System.Windows.Forms.TextBox tbxUserID;
        private System.Windows.Forms.Label lblUserID;
        private System.Windows.Forms.Label lblIDDisclaimer;
    }
}
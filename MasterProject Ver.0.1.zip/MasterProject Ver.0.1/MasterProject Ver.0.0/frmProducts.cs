﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using System.Media;

namespace SkeletonProjJesse
{
    public partial class frmProducts : Form
    {

        public frmProducts()
        {
            InitializeComponent();
        }


        private void btnCancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void frmProducts_Load(object sender, EventArgs e)
        {
            //Create data table for the dataGridView
            DataTable resultsTable = new DataTable();
            string sqlStatement = "SELECT * FROM group6fa212330.Products";

            //Apply SQL
            try
            {
                //Establish command object and data adapter
                ProgOps.EstablishDatabase(sqlStatement, resultsTable);

                //Bind grid to table
                dgvProducts.DataSource = resultsTable;

                dgvProducts.Columns["ProductCost"].DefaultCellStyle.Format = "c2";
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error in SQL!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            ProgOps.DisposeDatabase();
            resultsTable.Dispose();

            this.Text += UserInfo.firstName + " " + UserInfo.lastName;

            //dgvProducts.Columns["ProductDescription"].DefaultCellStyle.WrapMode = DataGridViewTriState.True;


        }

        private void lbxCart_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void lblCart_Click(object sender, EventArgs e)
        {

        }
    }
}

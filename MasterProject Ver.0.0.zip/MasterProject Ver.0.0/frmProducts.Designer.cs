﻿
namespace SkeletonProjJesse
{
    partial class frmProducts
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle3 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle4 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmProducts));
            this.mnuProducts = new System.Windows.Forms.MenuStrip();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.pnlMenuItems = new System.Windows.Forms.Panel();
            this.dgvProducts = new System.Windows.Forms.DataGridView();
            this.btnAdd = new System.Windows.Forms.Button();
            this.lblItems = new System.Windows.Forms.Label();
            this.pnlSettings = new System.Windows.Forms.Panel();
            this.tbxQuantity = new System.Windows.Forms.TextBox();
            this.lblSettings = new System.Windows.Forms.Label();
            this.lblFilterItems = new System.Windows.Forms.Label();
            this.pbxWitch = new System.Windows.Forms.PictureBox();
            this.cbxFilterItems = new System.Windows.Forms.ComboBox();
            this.lblQuantity = new System.Windows.Forms.Label();
            this.pnlCart = new System.Windows.Forms.Panel();
            this.lbxCart = new System.Windows.Forms.ListBox();
            this.btnCheckout = new System.Windows.Forms.Button();
            this.btnRemove = new System.Windows.Forms.Button();
            this.lblCart = new System.Windows.Forms.Label();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbxOrderSummary = new System.Windows.Forms.GroupBox();
            this.lblOutputTotalCost = new System.Windows.Forms.Label();
            this.lblOutputTotalItems = new System.Windows.Forms.Label();
            this.cbxPickup = new System.Windows.Forms.CheckBox();
            this.lblTotalItems = new System.Windows.Forms.Label();
            this.lblTotalCost = new System.Windows.Forms.Label();
            this.mnuProducts.SuspendLayout();
            this.pnlMenuItems.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).BeginInit();
            this.pnlSettings.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWitch)).BeginInit();
            this.pnlCart.SuspendLayout();
            this.gbxOrderSummary.SuspendLayout();
            this.SuspendLayout();
            // 
            // mnuProducts
            // 
            this.mnuProducts.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuProducts.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuProducts.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuProducts.Location = new System.Drawing.Point(0, 0);
            this.mnuProducts.Name = "mnuProducts";
            this.mnuProducts.Size = new System.Drawing.Size(1530, 27);
            this.mnuProducts.TabIndex = 0;
            this.mnuProducts.Text = "menuStrip1";
            // 
            // mnuClose
            // 
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(56, 23);
            this.mnuClose.Text = "Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // pnlMenuItems
            // 
            this.pnlMenuItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.pnlMenuItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlMenuItems.Controls.Add(this.dgvProducts);
            this.pnlMenuItems.Controls.Add(this.btnAdd);
            this.pnlMenuItems.Controls.Add(this.lblItems);
            this.pnlMenuItems.Location = new System.Drawing.Point(8, 37);
            this.pnlMenuItems.Name = "pnlMenuItems";
            this.pnlMenuItems.Size = new System.Drawing.Size(1027, 625);
            this.pnlMenuItems.TabIndex = 1;
            // 
            // dgvProducts
            // 
            this.dgvProducts.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.AllCells;
            this.dgvProducts.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dgvProducts.BackgroundColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.dgvProducts.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProducts.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle1;
            this.dgvProducts.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProducts.DefaultCellStyle = dataGridViewCellStyle2;
            this.dgvProducts.Location = new System.Drawing.Point(6, 42);
            this.dgvProducts.Name = "dgvProducts";
            dataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle3.BackColor = System.Drawing.SystemColors.Control;
            dataGridViewCellStyle3.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle3.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle3.SelectionBackColor = System.Drawing.SystemColors.Highlight;
            dataGridViewCellStyle3.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle3.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dgvProducts.RowHeadersDefaultCellStyle = dataGridViewCellStyle3;
            dataGridViewCellStyle4.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dgvProducts.RowsDefaultCellStyle = dataGridViewCellStyle4;
            this.dgvProducts.Size = new System.Drawing.Size(1009, 538);
            this.dgvProducts.TabIndex = 1;
            this.dgvProducts.TabStop = false;
            // 
            // btnAdd
            // 
            this.btnAdd.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnAdd.Location = new System.Drawing.Point(923, 586);
            this.btnAdd.Name = "btnAdd";
            this.btnAdd.Size = new System.Drawing.Size(92, 32);
            this.btnAdd.TabIndex = 2;
            this.btnAdd.Text = "Add to Cart";
            this.btnAdd.UseVisualStyleBackColor = true;
            // 
            // lblItems
            // 
            this.lblItems.AutoSize = true;
            this.lblItems.BackColor = System.Drawing.Color.Transparent;
            this.lblItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblItems.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblItems.Location = new System.Drawing.Point(6, 5);
            this.lblItems.Name = "lblItems";
            this.lblItems.Padding = new System.Windows.Forms.Padding(5);
            this.lblItems.Size = new System.Drawing.Size(119, 34);
            this.lblItems.TabIndex = 0;
            this.lblItems.Text = "Menu Items";
            // 
            // pnlSettings
            // 
            this.pnlSettings.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.pnlSettings.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlSettings.Controls.Add(this.tbxQuantity);
            this.pnlSettings.Controls.Add(this.lblSettings);
            this.pnlSettings.Controls.Add(this.lblFilterItems);
            this.pnlSettings.Controls.Add(this.pbxWitch);
            this.pnlSettings.Controls.Add(this.cbxFilterItems);
            this.pnlSettings.Controls.Add(this.lblQuantity);
            this.pnlSettings.Location = new System.Drawing.Point(1041, 403);
            this.pnlSettings.Name = "pnlSettings";
            this.pnlSettings.Size = new System.Drawing.Size(479, 259);
            this.pnlSettings.TabIndex = 2;
            // 
            // tbxQuantity
            // 
            this.tbxQuantity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.tbxQuantity.Location = new System.Drawing.Point(113, 52);
            this.tbxQuantity.Name = "tbxQuantity";
            this.tbxQuantity.Size = new System.Drawing.Size(76, 26);
            this.tbxQuantity.TabIndex = 5;
            this.tbxQuantity.Text = "1";
            // 
            // lblSettings
            // 
            this.lblSettings.AutoSize = true;
            this.lblSettings.BackColor = System.Drawing.Color.Transparent;
            this.lblSettings.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblSettings.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblSettings.Location = new System.Drawing.Point(9, 5);
            this.lblSettings.Name = "lblSettings";
            this.lblSettings.Padding = new System.Windows.Forms.Padding(5);
            this.lblSettings.Size = new System.Drawing.Size(87, 34);
            this.lblSettings.TabIndex = 0;
            this.lblSettings.Text = "Settings";
            // 
            // lblFilterItems
            // 
            this.lblFilterItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblFilterItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblFilterItems.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblFilterItems.Location = new System.Drawing.Point(9, 84);
            this.lblFilterItems.Name = "lblFilterItems";
            this.lblFilterItems.Size = new System.Drawing.Size(96, 27);
            this.lblFilterItems.TabIndex = 6;
            this.lblFilterItems.Text = "Filter Items:";
            this.lblFilterItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pbxWitch
            // 
            this.pbxWitch.BackColor = System.Drawing.Color.Transparent;
            this.pbxWitch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxWitch.BackgroundImage")));
            this.pbxWitch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxWitch.Location = new System.Drawing.Point(332, 133);
            this.pbxWitch.Name = "pbxWitch";
            this.pbxWitch.Size = new System.Drawing.Size(138, 119);
            this.pbxWitch.TabIndex = 1;
            this.pbxWitch.TabStop = false;
            // 
            // cbxFilterItems
            // 
            this.cbxFilterItems.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.cbxFilterItems.FormattingEnabled = true;
            this.cbxFilterItems.Items.AddRange(new object[] {
            "All",
            "Appetizers",
            "Desserts",
            "Kiddy",
            "Entrees"});
            this.cbxFilterItems.Location = new System.Drawing.Point(113, 84);
            this.cbxFilterItems.MaxDropDownItems = 10;
            this.cbxFilterItems.Name = "cbxFilterItems";
            this.cbxFilterItems.Size = new System.Drawing.Size(104, 27);
            this.cbxFilterItems.TabIndex = 7;
            this.cbxFilterItems.Text = "Filter";
            this.cbxFilterItems.SelectedIndexChanged += new System.EventHandler(this.cbxFilterItems_SelectedIndexChanged);
            // 
            // lblQuantity
            // 
            this.lblQuantity.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblQuantity.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblQuantity.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblQuantity.Location = new System.Drawing.Point(9, 52);
            this.lblQuantity.Name = "lblQuantity";
            this.lblQuantity.Size = new System.Drawing.Size(96, 27);
            this.lblQuantity.TabIndex = 4;
            this.lblQuantity.Text = "Quantity:";
            this.lblQuantity.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // pnlCart
            // 
            this.pnlCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.pnlCart.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.pnlCart.Controls.Add(this.gbxOrderSummary);
            this.pnlCart.Controls.Add(this.lbxCart);
            this.pnlCart.Controls.Add(this.btnCheckout);
            this.pnlCart.Controls.Add(this.btnRemove);
            this.pnlCart.Controls.Add(this.lblCart);
            this.pnlCart.Controls.Add(this.btnCancel);
            this.pnlCart.Location = new System.Drawing.Point(1041, 37);
            this.pnlCart.Name = "pnlCart";
            this.pnlCart.Size = new System.Drawing.Size(479, 360);
            this.pnlCart.TabIndex = 3;
            // 
            // lbxCart
            // 
            this.lbxCart.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lbxCart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lbxCart.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbxCart.FormattingEnabled = true;
            this.lbxCart.ItemHeight = 19;
            this.lbxCart.Location = new System.Drawing.Point(9, 48);
            this.lbxCart.Name = "lbxCart";
            this.lbxCart.Size = new System.Drawing.Size(208, 268);
            this.lbxCart.TabIndex = 4;
            this.lbxCart.SelectedIndexChanged += new System.EventHandler(this.lbxCart_SelectedIndexChanged);
            // 
            // btnCheckout
            // 
            this.btnCheckout.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCheckout.Location = new System.Drawing.Point(293, 321);
            this.btnCheckout.Name = "btnCheckout";
            this.btnCheckout.Size = new System.Drawing.Size(84, 32);
            this.btnCheckout.TabIndex = 2;
            this.btnCheckout.Text = "Checkout";
            this.btnCheckout.UseVisualStyleBackColor = true;
            this.btnCheckout.Click += new System.EventHandler(this.btnCheckout_Click);
            // 
            // btnRemove
            // 
            this.btnRemove.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnRemove.Location = new System.Drawing.Point(9, 321);
            this.btnRemove.Name = "btnRemove";
            this.btnRemove.Size = new System.Drawing.Size(84, 32);
            this.btnRemove.TabIndex = 1;
            this.btnRemove.Text = "Remove";
            this.btnRemove.UseVisualStyleBackColor = true;
            // 
            // lblCart
            // 
            this.lblCart.AutoSize = true;
            this.lblCart.BackColor = System.Drawing.Color.Transparent;
            this.lblCart.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblCart.Font = new System.Drawing.Font("Times New Roman", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblCart.Location = new System.Drawing.Point(9, 11);
            this.lblCart.Name = "lblCart";
            this.lblCart.Padding = new System.Windows.Forms.Padding(5);
            this.lblCart.Size = new System.Drawing.Size(104, 34);
            this.lblCart.TabIndex = 0;
            this.lblCart.Text = "Your Cart";
            this.lblCart.Click += new System.EventHandler(this.lblCart_Click);
            // 
            // btnCancel
            // 
            this.btnCancel.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.btnCancel.Location = new System.Drawing.Point(383, 321);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(84, 32);
            this.btnCancel.TabIndex = 3;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // gbxOrderSummary
            // 
            this.gbxOrderSummary.Controls.Add(this.lblOutputTotalCost);
            this.gbxOrderSummary.Controls.Add(this.lblOutputTotalItems);
            this.gbxOrderSummary.Controls.Add(this.cbxPickup);
            this.gbxOrderSummary.Controls.Add(this.lblTotalItems);
            this.gbxOrderSummary.Controls.Add(this.lblTotalCost);
            this.gbxOrderSummary.Location = new System.Drawing.Point(223, 115);
            this.gbxOrderSummary.Name = "gbxOrderSummary";
            this.gbxOrderSummary.Size = new System.Drawing.Size(244, 201);
            this.gbxOrderSummary.TabIndex = 7;
            this.gbxOrderSummary.TabStop = false;
            this.gbxOrderSummary.Text = "Order Summary";
            this.gbxOrderSummary.Enter += new System.EventHandler(this.gbxOrderSummary_Enter);
            // 
            // lblOutputTotalCost
            // 
            this.lblOutputTotalCost.BackColor = System.Drawing.Color.White;
            this.lblOutputTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutputTotalCost.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblOutputTotalCost.Location = new System.Drawing.Point(109, 76);
            this.lblOutputTotalCost.Name = "lblOutputTotalCost";
            this.lblOutputTotalCost.Size = new System.Drawing.Size(129, 27);
            this.lblOutputTotalCost.TabIndex = 3;
            this.lblOutputTotalCost.Text = "$0";
            this.lblOutputTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // lblOutputTotalItems
            // 
            this.lblOutputTotalItems.BackColor = System.Drawing.Color.White;
            this.lblOutputTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D;
            this.lblOutputTotalItems.ForeColor = System.Drawing.SystemColors.ControlText;
            this.lblOutputTotalItems.Location = new System.Drawing.Point(109, 37);
            this.lblOutputTotalItems.Name = "lblOutputTotalItems";
            this.lblOutputTotalItems.Size = new System.Drawing.Size(51, 27);
            this.lblOutputTotalItems.TabIndex = 1;
            this.lblOutputTotalItems.Text = "0";
            this.lblOutputTotalItems.TextAlign = System.Drawing.ContentAlignment.MiddleLeft;
            // 
            // cbxPickup
            // 
            this.cbxPickup.AutoSize = true;
            this.cbxPickup.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.cbxPickup.CheckAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.cbxPickup.Location = new System.Drawing.Point(6, 115);
            this.cbxPickup.Name = "cbxPickup";
            this.cbxPickup.Size = new System.Drawing.Size(65, 17);
            this.cbxPickup.TabIndex = 4;
            this.cbxPickup.Text = "Dine-in?";
            this.cbxPickup.UseVisualStyleBackColor = false;
            // 
            // lblTotalItems
            // 
            this.lblTotalItems.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblTotalItems.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalItems.Location = new System.Drawing.Point(6, 37);
            this.lblTotalItems.Name = "lblTotalItems";
            this.lblTotalItems.Size = new System.Drawing.Size(97, 27);
            this.lblTotalItems.TabIndex = 0;
            this.lblTotalItems.Text = "Total Items";
            this.lblTotalItems.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // lblTotalCost
            // 
            this.lblTotalCost.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.lblTotalCost.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle;
            this.lblTotalCost.Location = new System.Drawing.Point(6, 76);
            this.lblTotalCost.Name = "lblTotalCost";
            this.lblTotalCost.Size = new System.Drawing.Size(97, 27);
            this.lblTotalCost.TabIndex = 2;
            this.lblTotalCost.Text = "Total Cost";
            this.lblTotalCost.TextAlign = System.Drawing.ContentAlignment.MiddleRight;
            // 
            // frmProducts
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("$this.BackgroundImage")));
            this.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.ClientSize = new System.Drawing.Size(1530, 674);
            this.Controls.Add(this.pnlCart);
            this.Controls.Add(this.pnlSettings);
            this.Controls.Add(this.pnlMenuItems);
            this.Controls.Add(this.mnuProducts);
            this.DoubleBuffered = true;
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D;
            this.MaximizeBox = false;
            this.Name = "frmProducts";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts! | Products | ";
            this.Load += new System.EventHandler(this.frmProducts_Load);
            this.mnuProducts.ResumeLayout(false);
            this.mnuProducts.PerformLayout();
            this.pnlMenuItems.ResumeLayout(false);
            this.pnlMenuItems.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dgvProducts)).EndInit();
            this.pnlSettings.ResumeLayout(false);
            this.pnlSettings.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWitch)).EndInit();
            this.pnlCart.ResumeLayout(false);
            this.pnlCart.PerformLayout();
            this.gbxOrderSummary.ResumeLayout(false);
            this.gbxOrderSummary.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuProducts;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.Panel pnlMenuItems;
        private System.Windows.Forms.Panel pnlSettings;
        private System.Windows.Forms.Panel pnlCart;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.PictureBox pbxWitch;
        private System.Windows.Forms.Label lblSettings;
        private System.Windows.Forms.Label lblItems;
        private System.Windows.Forms.Label lblCart;
        private System.Windows.Forms.Button btnCheckout;
        private System.Windows.Forms.Button btnRemove;
        private System.Windows.Forms.Button btnAdd;
        private System.Windows.Forms.DataGridView dgvProducts;
        private System.Windows.Forms.TextBox tbxQuantity;
        private System.Windows.Forms.Label lblFilterItems;
        private System.Windows.Forms.ComboBox cbxFilterItems;
        private System.Windows.Forms.Label lblQuantity;
        private System.Windows.Forms.ListBox lbxCart;
        private System.Windows.Forms.GroupBox gbxOrderSummary;
        private System.Windows.Forms.Label lblOutputTotalCost;
        private System.Windows.Forms.Label lblOutputTotalItems;
        private System.Windows.Forms.CheckBox cbxPickup;
        private System.Windows.Forms.Label lblTotalItems;
        private System.Windows.Forms.Label lblTotalCost;
    }
}
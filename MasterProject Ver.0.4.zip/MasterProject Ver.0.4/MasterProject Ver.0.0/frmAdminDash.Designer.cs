﻿namespace SkeletonProjJesse
{
    partial class frmAdminDash
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(frmAdminDash));
            this.mnuMain = new System.Windows.Forms.MenuStrip();
            this.mnuFile = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuClose = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuManageDatabase = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuBillingInformationTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuCustomersTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuDeliveryTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuOnlineUsersTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuProductsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuResupplyTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuShipmentsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuStaffTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuTransactionsTable = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuResupplyStock = new System.Windows.Forms.ToolStripMenuItem();
            this.mnuAbout = new System.Windows.Forms.ToolStripMenuItem();
            this.pbxLogo = new System.Windows.Forms.PictureBox();
            this.pbxWitch = new System.Windows.Forms.PictureBox();
            this.pbxPumpkin = new System.Windows.Forms.PictureBox();
            this.mnuMain.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWitch)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPumpkin)).BeginInit();
            this.SuspendLayout();
            // 
            // mnuMain
            // 
            this.mnuMain.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuMain.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.mnuMain.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuFile,
            this.mnuManageDatabase,
            this.mnuResupplyStock,
            this.mnuAbout});
            this.mnuMain.Location = new System.Drawing.Point(0, 0);
            this.mnuMain.Name = "mnuMain";
            this.mnuMain.Size = new System.Drawing.Size(578, 27);
            this.mnuMain.TabIndex = 0;
            this.mnuMain.Text = "menuStrip1";
            // 
            // mnuFile
            // 
            this.mnuFile.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuClose});
            this.mnuFile.Name = "mnuFile";
            this.mnuFile.Size = new System.Drawing.Size(43, 23);
            this.mnuFile.Text = "File";
            // 
            // mnuClose
            // 
            this.mnuClose.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuClose.Name = "mnuClose";
            this.mnuClose.Size = new System.Drawing.Size(113, 24);
            this.mnuClose.Text = "&Close";
            this.mnuClose.Click += new System.EventHandler(this.mnuClose_Click);
            // 
            // mnuManageDatabase
            // 
            this.mnuManageDatabase.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.mnuBillingInformationTable,
            this.mnuCustomersTable,
            this.mnuDeliveryTable,
            this.mnuOnlineUsersTable,
            this.mnuProductsTable,
            this.mnuResupplyTable,
            this.mnuShipmentsTable,
            this.mnuStaffTable,
            this.mnuTransactionsTable});
            this.mnuManageDatabase.Name = "mnuManageDatabase";
            this.mnuManageDatabase.Size = new System.Drawing.Size(131, 23);
            this.mnuManageDatabase.Text = "Manage Database";
            // 
            // mnuBillingInformationTable
            // 
            this.mnuBillingInformationTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuBillingInformationTable.Name = "mnuBillingInformationTable";
            this.mnuBillingInformationTable.Size = new System.Drawing.Size(220, 24);
            this.mnuBillingInformationTable.Text = "BillingInformation Table";
            this.mnuBillingInformationTable.Click += new System.EventHandler(this.mnuBillingInformationTable_Click);
            // 
            // mnuCustomersTable
            // 
            this.mnuCustomersTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuCustomersTable.Name = "mnuCustomersTable";
            this.mnuCustomersTable.Size = new System.Drawing.Size(220, 24);
            this.mnuCustomersTable.Text = "Customers Table";
            this.mnuCustomersTable.Click += new System.EventHandler(this.mnuCustomersTable_Click);
            // 
            // mnuDeliveryTable
            // 
            this.mnuDeliveryTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuDeliveryTable.Name = "mnuDeliveryTable";
            this.mnuDeliveryTable.Size = new System.Drawing.Size(220, 24);
            this.mnuDeliveryTable.Text = "Delivery Table";
            this.mnuDeliveryTable.Click += new System.EventHandler(this.mnuDeliveryTable_Click);
            // 
            // mnuOnlineUsersTable
            // 
            this.mnuOnlineUsersTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuOnlineUsersTable.Name = "mnuOnlineUsersTable";
            this.mnuOnlineUsersTable.Size = new System.Drawing.Size(220, 24);
            this.mnuOnlineUsersTable.Text = "OnlineUsers Table";
            this.mnuOnlineUsersTable.Click += new System.EventHandler(this.mnuOnlineUsersTable_Click);
            // 
            // mnuProductsTable
            // 
            this.mnuProductsTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuProductsTable.Name = "mnuProductsTable";
            this.mnuProductsTable.Size = new System.Drawing.Size(220, 24);
            this.mnuProductsTable.Text = "Products Table";
            this.mnuProductsTable.Click += new System.EventHandler(this.mnuProductsTable_Click);
            // 
            // mnuResupplyTable
            // 
            this.mnuResupplyTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuResupplyTable.Name = "mnuResupplyTable";
            this.mnuResupplyTable.Size = new System.Drawing.Size(220, 24);
            this.mnuResupplyTable.Text = "Resupply Table";
            this.mnuResupplyTable.Click += new System.EventHandler(this.mnuResupplyTable_Click);
            // 
            // mnuShipmentsTable
            // 
            this.mnuShipmentsTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuShipmentsTable.Name = "mnuShipmentsTable";
            this.mnuShipmentsTable.Size = new System.Drawing.Size(220, 24);
            this.mnuShipmentsTable.Text = "Shipments Table";
            this.mnuShipmentsTable.Click += new System.EventHandler(this.mnuShipmentsTable_Click);
            // 
            // mnuStaffTable
            // 
            this.mnuStaffTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuStaffTable.Name = "mnuStaffTable";
            this.mnuStaffTable.Size = new System.Drawing.Size(220, 24);
            this.mnuStaffTable.Text = "Staff Table";
            this.mnuStaffTable.Click += new System.EventHandler(this.mnuStaffTable_Click);
            // 
            // mnuTransactionsTable
            // 
            this.mnuTransactionsTable.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(124)))), ((int)(((byte)(177)))), ((int)(((byte)(46)))));
            this.mnuTransactionsTable.Name = "mnuTransactionsTable";
            this.mnuTransactionsTable.Size = new System.Drawing.Size(220, 24);
            this.mnuTransactionsTable.Text = "Transactions Table";
            this.mnuTransactionsTable.Click += new System.EventHandler(this.mnuTransactionsTable_Click);
            // 
            // mnuResupplyStock
            // 
            this.mnuResupplyStock.Name = "mnuResupplyStock";
            this.mnuResupplyStock.Size = new System.Drawing.Size(117, 23);
            this.mnuResupplyStock.Text = "Resupply Stock";
            this.mnuResupplyStock.Click += new System.EventHandler(this.mnuResupplyStock_Click);
            // 
            // mnuAbout
            // 
            this.mnuAbout.Name = "mnuAbout";
            this.mnuAbout.Size = new System.Drawing.Size(59, 23);
            this.mnuAbout.Text = "About";
            this.mnuAbout.Click += new System.EventHandler(this.mnuAbout_Click);
            // 
            // pbxLogo
            // 
            this.pbxLogo.BackColor = System.Drawing.Color.Transparent;
            this.pbxLogo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxLogo.BackgroundImage")));
            this.pbxLogo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxLogo.Location = new System.Drawing.Point(-53, 19);
            this.pbxLogo.Name = "pbxLogo";
            this.pbxLogo.Size = new System.Drawing.Size(403, 426);
            this.pbxLogo.TabIndex = 5;
            this.pbxLogo.TabStop = false;
            // 
            // pbxWitch
            // 
            this.pbxWitch.BackColor = System.Drawing.Color.Transparent;
            this.pbxWitch.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxWitch.BackgroundImage")));
            this.pbxWitch.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxWitch.Location = new System.Drawing.Point(348, 30);
            this.pbxWitch.Name = "pbxWitch";
            this.pbxWitch.Size = new System.Drawing.Size(224, 234);
            this.pbxWitch.TabIndex = 4;
            this.pbxWitch.TabStop = false;
            // 
            // pbxPumpkin
            // 
            this.pbxPumpkin.BackColor = System.Drawing.Color.Transparent;
            this.pbxPumpkin.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("pbxPumpkin.BackgroundImage")));
            this.pbxPumpkin.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.pbxPumpkin.Location = new System.Drawing.Point(348, 242);
            this.pbxPumpkin.Name = "pbxPumpkin";
            this.pbxPumpkin.Size = new System.Drawing.Size(224, 134);
            this.pbxPumpkin.TabIndex = 24;
            this.pbxPumpkin.TabStop = false;
            // 
            // frmAdminDash
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(9F, 19F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackgroundImage = global::SkeletonProjJesse.Properties.Resources.Background2;
            this.ClientSize = new System.Drawing.Size(578, 379);
            this.Controls.Add(this.pbxPumpkin);
            this.Controls.Add(this.pbxWitch);
            this.Controls.Add(this.mnuMain);
            this.Controls.Add(this.pbxLogo);
            this.Font = new System.Drawing.Font("Times New Roman", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.Margin = new System.Windows.Forms.Padding(4);
            this.MaximizeBox = false;
            this.Name = "frmAdminDash";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Gobblin\' Ghouls and Ghosts! | Admin Dashboard";
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmAdminDash_FormClosing);
            this.mnuMain.ResumeLayout(false);
            this.mnuMain.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pbxLogo)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxWitch)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbxPumpkin)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.MenuStrip mnuMain;
        private System.Windows.Forms.ToolStripMenuItem mnuFile;
        private System.Windows.Forms.ToolStripMenuItem mnuClose;
        private System.Windows.Forms.ToolStripMenuItem mnuManageDatabase;
        private System.Windows.Forms.ToolStripMenuItem mnuBillingInformationTable;
        private System.Windows.Forms.ToolStripMenuItem mnuCustomersTable;
        private System.Windows.Forms.ToolStripMenuItem mnuDeliveryTable;
        private System.Windows.Forms.ToolStripMenuItem mnuOnlineUsersTable;
        private System.Windows.Forms.ToolStripMenuItem mnuProductsTable;
        private System.Windows.Forms.ToolStripMenuItem mnuResupplyTable;
        private System.Windows.Forms.ToolStripMenuItem mnuShipmentsTable;
        private System.Windows.Forms.ToolStripMenuItem mnuStaffTable;
        private System.Windows.Forms.ToolStripMenuItem mnuTransactionsTable;
        private System.Windows.Forms.ToolStripMenuItem mnuAbout;
        private System.Windows.Forms.PictureBox pbxLogo;
        private System.Windows.Forms.PictureBox pbxWitch;
        private System.Windows.Forms.PictureBox pbxPumpkin;
        private System.Windows.Forms.ToolStripMenuItem mnuResupplyStock;
    }
}
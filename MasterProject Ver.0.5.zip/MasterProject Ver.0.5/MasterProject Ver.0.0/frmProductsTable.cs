﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Media;
using CrystalDecisions.CrystalReports.Engine;

namespace SkeletonProjJesse
{
    public partial class frmProductsTable : Form
    {
        //To flip through the records
        CurrencyManager manager;

        //To keep track of which record we were at last
        int lastLocation = 0;

        //Form level picture file declaration
        string imageLocation = "";

        //This variable is to keep track of the staffID
        //The StaffID can be changed so the old ID needs to be kept track of or else it won't know where to Update in the function call
        string oldProductID = "";

        public frmProductsTable()
        {
            InitializeComponent();
        }

        private void mnuClose_Click(object sender, EventArgs e)
        {
            //Close the form
            this.Close();
        }

        private void frmProductsTable_Load(object sender, EventArgs e)
        {
            //By default, it will be in insert mode
            AppState("Insert");
        }

        private void btnBrowseImage_Click(object sender, EventArgs e)
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*";
                dialog.Title = "Select Product Image";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    imageLocation = dialog.FileName.ToString();
                    pbxProductImage.ImageLocation = imageLocation;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error browsing for image!", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
        }

        string GetImagePath()
        {
            try
            {
                OpenFileDialog dialog = new OpenFileDialog();
                dialog.Filter = "JPG Files (*.jpg)|*.jpg|GIF Files (*.gif)|*.gif|All Files (*.*)|*.*";
                dialog.Title = "Select Product Image";
                if (dialog.ShowDialog() == DialogResult.OK)
                {
                    imageLocation = dialog.FileName.ToString();
                    pbxProductImage.ImageLocation = imageLocation;
                }

                return pbxProductImage.ImageLocation;
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message, "Error browsing for image!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                return "";
            }
        }

        private void mnuClearAll_Click(object sender, EventArgs e)
        {
            //Clear all text boxes
            tbxProductID.Text = "";
            tbxProductName.Text = "";
            tbxProductDescription.Text = "";
            tbxProductType.Text = "";
            tbxProductCost.Text = "";
            tbxProductSupplier.Text = "";
            pbxProductImage.Image = null;
        }

        private void mnuInsert_Click(object sender, EventArgs e)
        {
            //Call the AppState function and passing it what the user wants to do
            ProgOps.DTProductsTable.Clear();

            AppState("Insert");
        }

        private void mnuDelete_Click(object sender, EventArgs e)
        {
            //Display the database to the text boxes
            ProgOps.DisplayProductsTable(tbxProductID, tbxProductName, tbxProductDescription, tbxProductType, tbxProductCost, tbxProductSupplier, pbxProductImage, imageLocation);
            ProgOps.UpdateImage(pbxProductImage, tbxProductID.Text);

            manager = (CurrencyManager)this.BindingContext[ProgOps.DTProductsTable];
            oldProductID = tbxProductID.Text;

            //Call the AppState function and passing it what the user wants to do
            AppState("Delete");
        }

        private void mnuEdit_Click(object sender, EventArgs e)
        {
            //Display the contents of the database to the text boxes
            ProgOps.DisplayProductsTable(tbxProductID, tbxProductName, tbxProductDescription, tbxProductType, tbxProductCost, tbxProductSupplier, pbxProductImage, imageLocation);
            ProgOps.UpdateImage(pbxProductImage, tbxProductID.Text);

            manager = (CurrencyManager)this.BindingContext[ProgOps.DTProductsTable];
            oldProductID = tbxProductID.Text;
            //Call the AppState function and passing it what the user wants to do
            AppState("Edit");
        }

        private void mnuAction_Click(object sender, EventArgs e)
        {
            //The action button changes text depending on what mode the user is in, so switch on the text
            //The text property still contains the accelerator key, so replace it with an empty string value
            switch (mnuAction.Text.Replace("&", ""))
            {
                case "Save Record":
                    {
                        if (tbxProductCost.Text.Trim().Equals(String.Empty) || tbxProductDescription.Text.Trim().Equals(String.Empty) || tbxProductSupplier.Text.Trim().Equals(String.Empty) || tbxProductID.Text.Trim().Equals(String.Empty) || tbxProductName.Text.Trim().Equals(String.Empty) || tbxProductType.Text.Trim().Equals(String.Empty) || pbxProductImage == null)
                        {
                            MessageBox.Show("Please make sure all text fields and image have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            try
                            {
                                ProgOps.InsertIntoProducts(tbxProductID, tbxProductName, tbxProductDescription, tbxProductType, tbxProductCost, tbxProductSupplier, imageLocation);
                            }
                            catch (Exception ex)
                            {
                                MessageBox.Show(ex.Message, "Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                            }
                        }
                        break;
                    }
                case "Delete Record":
                    {
                        if (MessageBox.Show("Are you sure you want to delete this record?", "Delete Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                        {
                            ProgOps.DeleteFromTable(tbxProductID.Text, "ProductID", "Products");
                            manager.RemoveAt(manager.Position);
                        }
                        break;
                    }
                case "Edit Record":
                    {
                        if (tbxProductCost.Text.Trim().Equals(String.Empty) || tbxProductDescription.Text.Trim().Equals(String.Empty) || tbxProductSupplier.Text.Trim().Equals(String.Empty) || tbxProductID.Text.Trim().Equals(String.Empty) || tbxProductName.Text.Trim().Equals(String.Empty) || tbxProductType.Text.Trim().Equals(String.Empty) || pbxProductImage == null)
                        {
                            MessageBox.Show("Please make sure all text fields have values in them!", "Input Error!", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        }
                        else
                        {
                            if (MessageBox.Show("Record will now be updated, confirm?", "Edit Record", MessageBoxButtons.YesNo, MessageBoxIcon.Question, MessageBoxDefaultButton.Button2) == DialogResult.Yes)
                            {

                                ProgOps.UpdateProductsTable(oldProductID, tbxProductName, tbxProductDescription, tbxProductType, tbxProductCost, tbxProductSupplier, GetImagePath());
                                oldProductID = tbxProductID.Text;
                            }
                        }
                        break;
                    }
            }
        }

        private void btnFirst_Click(object sender, EventArgs e)
        {
            tbxProductID.Text = oldProductID;
            manager.Position = 0;
            ProgOps.UpdateImage(pbxProductImage, tbxProductID.Text);
            oldProductID = tbxProductID.Text;
        }

        private void btnPrevious_Click(object sender, EventArgs e)
        {
            if (manager.Position == 0)
            {
                SystemSounds.Beep.Play();
            }
            tbxProductID.Text = oldProductID;
            manager.Position--;
            ProgOps.UpdateImage(pbxProductImage, tbxProductID.Text);
            oldProductID = tbxProductID.Text;
        }

        private void btnNext_Click(object sender, EventArgs e)
        {
            if (manager.Position == manager.Count - 1)
            {
                SystemSounds.Beep.Play();
            }
            tbxProductID.Text = oldProductID;
            manager.Position++;
            ProgOps.UpdateImage(pbxProductImage, tbxProductID.Text);
            oldProductID = tbxProductID.Text;
        }

        private void btnLast_Click(object sender, EventArgs e)
        {
            tbxProductID.Text = oldProductID;
            manager.Position = manager.Count - 1;
            ProgOps.UpdateImage(pbxProductImage, tbxProductID.Text);
            oldProductID = tbxProductID.Text;
        }

        public void AppState(string state)
        {
            //No matter what mode it is now in, focus on the first text box
            tbxProductID.Focus();

            switch (state)
            {
                case "Insert": //Insert mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = true;
                        btnFirst.Enabled = false;
                        btnLast.Enabled = false;
                        btnPrevious.Enabled = false;
                        btnNext.Enabled = false;
                        btnBrowseImage.Enabled = true;
                        lblDisclaimer.Visible = false;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Insert Into Products";
                        mnuAction.Text = "&Save Record";
                        tbxProductID.Text = "";
                        tbxProductName.Text = "";
                        tbxProductDescription.Text = "";
                        tbxProductType.Text = "";
                        tbxProductCost.Text = "";
                        tbxProductSupplier.Text = "";

                        //Set the textBox properties
                        tbxProductID.ReadOnly = false;
                        tbxProductName.ReadOnly = false;
                        tbxProductDescription.ReadOnly = false;
                        tbxProductType.ReadOnly = false;
                        tbxProductCost.ReadOnly = false;
                        tbxProductSupplier.ReadOnly = false;

                        //Set picture box to empty image
                        pbxProductImage.Image = null;
                        break;
                    }
                case "Delete": //Delete mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;
                        btnBrowseImage.Enabled = false;
                        lblDisclaimer.Visible = false;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Delete From Products";
                        mnuAction.Text = "&Delete Record";

                        //Set the textBox properties
                        tbxProductID.ReadOnly = true;
                        tbxProductName.ReadOnly = true;
                        tbxProductDescription.ReadOnly = true;
                        tbxProductType.ReadOnly = true;
                        tbxProductCost.ReadOnly = true;
                        tbxProductSupplier.ReadOnly = true;
                        break;
                    }
                case "Edit": //Edit mode
                    {
                        //Set the last location to 0
                        lastLocation = 0;

                        //Set menu and button properties
                        mnuClearAll.Enabled = false;
                        btnFirst.Enabled = true;
                        btnLast.Enabled = true;
                        btnPrevious.Enabled = true;
                        btnNext.Enabled = true;
                        btnBrowseImage.Enabled = false;
                        lblDisclaimer.Visible = true;

                        //Change the text properties on the form
                        this.Text = "Gobblin' Ghouls and Ghosts Admin | Edit Products";
                        mnuAction.Text = "&Edit Record";

                        //Set the textBox properties
                        tbxProductID.ReadOnly = true;
                        tbxProductName.ReadOnly = false;
                        tbxProductDescription.ReadOnly = false;
                        tbxProductType.ReadOnly = false;
                        tbxProductCost.ReadOnly = false;
                        tbxProductSupplier.ReadOnly = false;
                        break;
                    }
                default:
                    break;
            }
        }

        private void mnuPrintData_Click(object sender, EventArgs e)
        {
            //This is used just for shorter code
            string path = Application.StartupPath;

            //Create an object of the frmViewer so we can use crvViewer (Set to public in form)
            frmViewer viewer = new frmViewer();

            //Create CrystalReport 
            ReportDocument customersReport = new ReportDocument();

            //Soft coding, to get exact file location
            //Removing the last nine characters from the string and appending the specific report in the folder
            customersReport.Load(path.Remove(path.Length - 9, 9) + @"Crystal Reports\crptProducts.rpt");

            //After loading the report
            //Hardcode the login and password
            customersReport.SetDatabaseLogon("group6fa212330", "6134295");

            viewer.crvViewer.ReportSource = customersReport;

            //Show form with the crvViewer on it
            viewer.crvViewer.Refresh();

            viewer.Show();
        }
    }
}
